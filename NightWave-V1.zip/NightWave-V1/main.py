"""NightWave - Windows için masaüstü müzik çalar.  Çalıştırma: python main.py"""
import sys
import traceback
from datetime import datetime

from PyQt6.QtCore import QThreadPool
from PyQt6.QtWidgets import QApplication

from core import config
from ui.icons import make_app_icon
from ui.main_window import MainWindow


def _install_excepthook(get_window):
    """Qt, yakalanmamış istisnada uygulamayı sessizce kapatır. Biz bunun yerine kaydedip devam ederiz."""
    def hook(etype, value, tb):
        text = "".join(traceback.format_exception(etype, value, tb))
        sys.stderr.write(text)
        try:
            with open(config.APP_DIR / "error.log", "a", encoding="utf-8") as f:
                f.write(f"\n[{datetime.now():%Y-%m-%d %H:%M:%S}]\n{text}")
        except OSError:
            pass
        win = get_window()
        if win is not None:
            win.set_status(f"⚠ Beklenmeyen hata: {value}  (ayrıntı: {config.APP_DIR / 'error.log'})")
    sys.excepthook = hook


def main():
    # Görev çubuğunda Python yerine kendi simgemizi göstersin
    try:
        import ctypes
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("nightwave.player")
    except Exception:
        pass

    holder = {"win": None}
    _install_excepthook(lambda: holder["win"])

    app = QApplication(sys.argv)
    app.setApplicationName("NightWave")
    QThreadPool.globalInstance().setMaxThreadCount(16)   # ağ işleri çok (ana sayfa raf aramaları + kapaklar)
    app.setStyle("Fusion")                 # QSS için tutarlı bir temel
    app.setQuitOnLastWindowClosed(False)   # pencere gizlenince (tepsi) uygulama kapanmasın
    app.setWindowIcon(make_app_icon())

    holder["win"] = window = MainWindow(config.load())   # tema (QSS) pencere içinde uygulanır
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
