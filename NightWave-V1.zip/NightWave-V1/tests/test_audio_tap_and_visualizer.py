"""AudioTap (tembel bağlanma, tampon işleme) + VisualizerWidget (tüm stiller) + Çalıyor ekranı. Sahte Qt ile."""
import pathlib, sys, tempfile, os, time
HERE = pathlib.Path(__file__).resolve().parent
os.environ["APPDATA"] = tempfile.mkdtemp()
sys.path.insert(0, str(HERE / "fake_qt")); sys.path.insert(0, str(HERE.parent))
import numpy as np
from core.audio_tap import AudioTap
from core.models import Track
from ui.visualizer import VisualizerWidget, STYLES, COLOR_MODES, BAR_CHOICES
from ui.now_playing import NowPlayingView
from core import config
from ui import styles

SR = 44100
def sine(f, n=SR, amp=0.8): return (amp * np.sin(2 * np.pi * f * np.arange(n) / SR)).astype(np.float32)

# ---------------- AudioTap: tembel bağlanma ----------------
class Media:
    def __init__(s): s.calls = []
    def setAudioBufferOutput(s, o): s.calls.append(o)
m = Media(); tap = AudioTap(m)
tap.set_backend(True); assert m.calls == [] and not tap.ok                 # görselleştirici açılmadan ses yoluna dokunulmaz
tap.set_enabled(True); assert len(m.calls) == 1 and m.calls[0] is not None and tap.ok
tap.set_enabled(False); tap.set_enabled(True); assert len(m.calls) == 1    # tekrar bağlanmaz
tap.set_backend(False); assert m.calls[-1] is None and not tap.ok           # ayardan kapatılınca ayrılır
tap.set_enabled(True); assert m.calls[-1] is None and not tap.ok            # kapalıyken bağlanmaz
tap.set_backend(True); assert tap.ok and m.calls[-1] is not None            # tekrar açılınca (görünürken) bağlanır
print("AudioTap tembel bağlanma OK")

# ---------------- AudioTap: tampon işleme ----------------
class Named:                                      # sampleFormat().name
    def __init__(s, n): s.name = n
class Fmt:
    def __init__(s, sf, ch, sr): s._sf, s._ch, s._sr = sf, ch, sr
    def sampleFormat(s): return Named(s._sf)
    def channelCount(s): return s._ch
    def sampleRate(s): return s._sr
class Ptr:
    def __init__(s, b): s.b = b
    def asstring(s, n): return s.b[:n]
class Buf:
    def __init__(s, pcm, sf, ch, start=0, valid=True): s.pcm, s.sf, s.ch, s.start, s.valid = pcm, sf, ch, start, valid
    def isValid(s): return s.valid
    def format(s): return Fmt(s.sf, s.ch, SR)
    def constData(s): return Ptr(s.pcm)
    def byteCount(s): return len(s.pcm)
    def startTime(s): return s.start

t2 = AudioTap(Media()); t2.set_backend(True); t2.set_enabled(True)
stereo = np.repeat((sine(440, 4410) * 32767).astype(np.int16), 2).tobytes()
t2._on_buffer(Buf(stereo, "Int16", 2, 0))
assert t2.has_data() and t2.window(100, 2048)[1] == SR
t2._on_buffer(Buf(b"", "Int16", 2, 0, valid=False))                           # akış sonu tamponu yok sayılır
t3 = AudioTap(Media()); t3.set_backend(True)                                   # görselleştirici kapalı: veri biriktirmez
t3._on_buffer(Buf(stereo, "Int16", 2, 0)); assert not t3.has_data()
t4 = AudioTap(Media()); t4.set_backend(True); t4.set_enabled(True)
for _ in range(25): t4._on_buffer(Buf(b"\x00\x00", "Bilinmeyen", 1))           # kalıcı biçim hatası -> simülasyona düş
assert not t4.ok and t4.error
# iki görselleştirici (Çalıyor ekranı + küçük ekran): biri gizlenince yakalama kapanmamalı
t5 = AudioTap(Media()); t5.set_backend(True)
t5.set_enabled(True); t5.set_enabled(True); assert t5.enabled
t5.set_enabled(False); assert t5.enabled                                       # biri hâlâ görünüyor
t5._on_buffer(Buf(stereo, "Int16", 2, 0)); assert t5.has_data()
t5.set_enabled(False); assert not t5.enabled and not t5.has_data()             # hepsi gizlendi
t5.set_enabled(False); assert not t5.enabled and t5._users == 0                # fazladan gizleme sayaçı negatife düşürmez
t5.set_enabled(True); assert t5.enabled
print("AudioTap tampon işleme OK")

# ---------------- Görselleştirici: tüm stiller/renkler, 60'ar kare ----------------
class Player:
    def __init__(s, tap): s.tap, s.playing, s.pos = tap, True, 500
    def position(s): return s.pos
    def current_track(s): return Track(id="abcdefghijk", title="t", source="youtube")
    @property
    def is_playing(s): return s.playing
pal = styles.get_palette("midnight", "#8B7CFF")
tapv = AudioTap(Media()); tapv.set_backend(True); tapv.set_enabled(True)
tapv._on_buffer(Buf((sine(100) * 32767).astype(np.int16).tobytes(), "Int16", 1, 0))
pl = Player(tapv); viz = VisualizerWidget(pl, pal)
viz.update = lambda: None; viz.width = lambda: 900; viz.height = lambda: 400
kinds = []; viz.kind_changed.connect(kinds.append)
class Painter:                                                                    # sahte QPainter: her çağrıyı kabul eder
    def __getattr__(s, n): return lambda *a, **k: None
def run(frames):
    for _ in range(frames):
        viz._last -= 0.016; viz._tick()
for style, _ in STYLES:
    for cm, _ in COLOR_MODES:
        viz.set_style(style); viz.set_color_mode(cm); run(60)
        assert np.isfinite(viz._levels).all() and viz._levels.min() >= 0 and viz._levels.max() <= 1, (style, cm)
        viz.paintEvent(None) if False else getattr(viz, "_draw_" + style)(Painter(), 900.0, 400.0)
assert kinds and kinds[0] == "real" and viz._levels.max() > 0.3                  # gerçek ses -> çubuklar yükseldi
viz.set_style("circle"); viz._draw_circle(Painter(), 900.0, 400.0)                # kapaksız daire
for n in BAR_CHOICES:                                                             # çubuk sayısı değişince boyutlar tutarlı
    viz.set_bars(n); run(5); assert len(viz._levels) == n == len(viz._peaks) == viz.engine.analyzer.bands
    for style, _ in STYLES: getattr(viz, "_draw_" + style)(Painter(), 900.0, 400.0)
viz.set_gain(250); run(20); hi = float(viz._levels.max()); viz.set_gain(40); run(60); assert float(viz._levels.max()) <= hi
pl.playing = False; run(200); assert viz._levels.max() < 0.01                    # duraklatınca söner
idle_calls = []; viz.update = lambda: idle_calls.append(1); run(20); assert len(idle_calls) <= 1   # sessizken yeniden çizmez
pl.playing = True; viz.engine.tap = None; run(30)                                  # tap yok -> simülasyon
assert kinds[-1] == "sim" and viz._levels.max() > 0.1
print("Görselleştirici stilleri OK")

# ---------------- Çalıyor ekranı ----------------
cfg = config.load(); saved = []
nv = NowPlayingView(pl, cfg, pal, lambda: saved.append(1), lambda: saved.append("fs"))
nv.set_track(Track(id="abcdefghijk", title="Şarkı", artist="Sanatçı", source="youtube"))
nv._on_kind("real"); nv._on_kind("sim"); nv.set_fullscreen(True); nv.apply_palette(pal)
nv._on_gain_released(); assert saved
print("Çalıyor ekranı OK")
