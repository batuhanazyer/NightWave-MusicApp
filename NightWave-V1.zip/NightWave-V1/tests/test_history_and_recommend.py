import sys, time, random, tempfile
from pathlib import Path
import pathlib; sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))
sys.modules.setdefault("yt_dlp", type(sys)("yt_dlp"))      # ağ/yt-dlp gerektirmeden içe aktar
from core.models import Track
from core.history import History
from core import recommend as R

tmp = Path(tempfile.mkdtemp()); h = History(tmp/"h.json")
def yt(i, title, artist="Chan", dur=200): return Track(id=i*11 if len(i)==1 else i, title=title, artist=artist, duration=dur, source="youtube")
A, B, C = yt("a","Tarkan - Simarik"), yt("b","Tarkan - Kuzu Kuzu"), yt("c","Sezen Aksu - Gulumse")

# --- sayım kuralları ---
h.record(A, 200_000, 200_000); h.record(A, 190_000, 200_000)         # 2 çalma
h.record(B, 5_000, 200_000)                                           # atlama
h.record(C, 20_000, 200_000)                                          # arası: sayılmaz
h.record(Track(id="x", title="short", duration=20, source="youtube"), 12_000, 20_000)  # kısa parça: %50 kuralı
h.record(Track(id="local:a", title="l", source="local"), 100_000, 100_000)            # yerel: kaydedilmez
e = {x["track"]["id"]: x for x in h.entries()}
assert e[A.id]["plays"] == 2 and e[B.id]["skips"] == 1 and C.id not in e
assert e["x"]["plays"] == 1 and "local:a" not in e
assert h.toggle_like(C) is True and h.is_liked(C.id) and [t.id for t in h.liked_tracks()] == [C.id]
assert h.toggle_like(C) is False and h.liked_tracks() == []
assert History(tmp/"h.json").total_plays() == 3                       # diske yazıldı, yeniden yüklenir
print("History OK")

# --- sanatçı tahmini ---
assert R.artist_of(Track(id="1", title="Whatever", artist="Tarkan - Topic", source="youtube")) == "Tarkan"
assert R.artist_of(Track(id="1", title="Tarkan - Simarik", artist="Sony Music", source="youtube")) == "Tarkan"
assert R.artist_of(Track(id="1", title="Song", artist="AdeleVEVO", source="youtube")) == "Adele"
assert R.artist_of(Track(id="sp:x", title="Song", artist="Duman, Guest", source="spotify")) == "Duman"

# --- puanlama: yakınlık ve atlama ---
now = time.time()
fresh = {"plays":5,"skips":0,"liked":False,"last":now,"first":now,"liked_at":0}
old   = {**fresh, "last": now-120*86400, "first": now-120*86400}
skipy = {**fresh, "plays":1, "skips":5}
liked = {**fresh, "plays":0, "liked":True, "liked_at":now}
assert R.entry_score(fresh) > R.entry_score(old) > 0
assert R.entry_score(skipy) == 0 and R.entry_score(liked) > R.entry_score({**fresh,"plays":2})
print("Puanlama OK")

# --- tohum seçimi çeşitli olmalı ---
ent = []
for i in range(10):
    t = Track(id=f"id{i:09d}", title=f"Tarkan - S{i}" if i < 6 else f"Duman - S{i}", source="youtube")
    ent.append({"track": t.to_dict(), "plays": 10-i, "skips":0, "liked":False, "last":now, "first":now, "liked_at":0})
rng = random.Random(1)
for _ in range(30):
    seeds = R.pick_seeds(ent, 4, rng); arts = [R.artist_of(s) for s in seeds]
    assert len(arts) == len(set(arts)) and len(seeds) <= 2      # sadece 2 sanatçı var -> en fazla 2 tohum
assert R.enough_data(ent) and not R.enough_data(ent[:2])
assert R.top_artists(ent, 2)[0][0] == "Tarkan"
print("Tohumlar OK")

# --- aday birleştirme ---
def cands(prefix, n, dur=200): return [Track(id=f"{prefix}{i:010d}"[:11], title=f"{prefix} song {i}", duration=dur, source="youtube") for i in range(n)]
s1, s2 = Track(id="seed1000000", title="Tarkan - X", source="youtube"), Track(id="seed2000000", title="Duman - Y", source="youtube")
c1 = cands("p", 5) + [Track(id="bad00000001", title="Best FULL ALBUM 2020", duration=200, source="youtube"),
                      Track(id="long0000001", title="Long one", duration=3600, source="youtube"),
                      Track(id=s2.id, title="seed itself", duration=200, source="youtube")]
c2 = cands("q", 5) + [c1[0]]                                           # tekrar eden aday
known = {cands("p",1)[0].id}                                          # zaten çok dinlenmiş
out, why = R.merge_candidates([(s1, c1), (s2, c2)], known, count=6)
ids = [t.id for t in out]
assert len(ids) == 6 and len(set(ids)) == 6                           # tekrar yok
assert "bad00000001" not in ids and "long0000001" not in ids and s2.id not in ids and cands("p",1)[0].id not in ids
assert why[out[0].id].startswith("Tarkan") and why[out[1].id].startswith("Duman")   # sırayla karışık
print("Birleştirme OK")
