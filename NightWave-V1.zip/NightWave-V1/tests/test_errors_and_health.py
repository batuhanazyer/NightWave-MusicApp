"""Hata mesajı çevirisi ve harici program bulma testleri (Qt/ağ gerektirmez)."""
import os, pathlib, sys, tempfile
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))
from core import errors, health

# ---- hata çevirisi ----
f = errors.friendly_error
assert "Deno" in f("ERROR: [youtube] abc: Requested format is not available. Use --list-formats")
assert "Deno" in f("WARNING: No supported JavaScript runtime could be found")
assert "FFmpeg" in f(RuntimeError("ERROR: Postprocessing: ffprobe and ffmpeg not found"))
assert "bot" in f("Sign in to confirm you’re not a bot").lower()
assert "kullanılamıyor" in f("ERROR: [youtube] x: Video unavailable. This video is private")
assert "Ağ hatası" in f("<urlopen error [Errno 11001] getaddrinfo failed>")
assert "403" in f("HTTP Error 403: Forbidden")
assert f("\x1b[0;31mERROR:\x1b[0m bambaşka bir şey") == "ERROR: bambaşka bir şey"     # renk kodları temizlenir
assert f(errors.MSG_FFMPEG) == errors.MSG_FFMPEG and f(errors.MSG_JS) == errors.MSG_JS   # kendi mesajlarımız değişmez
assert f("") == "Bilinmeyen hata" and len(f("x" * 1000)) == 300
print("Hata çevirisi OK")

# ---- program bulma: PATH'te olmasa bile bilinen klasörlerde bulur ----
tmp = pathlib.Path(tempfile.mkdtemp())
for name in ("deno", "node"):
    p = tmp / health._exe(name); p.write_text("#!/bin/sh\n"); p.chmod(0o755)
(tmp / health._exe("ffmpeg")).write_text("x")
old_dirs, old_path = health._candidate_dirs, os.environ["PATH"]
os.environ["PATH"] = "/nonexistent"
health._candidate_dirs = lambda: [tmp]
try:
    js = health.find_js_runtimes()
    assert list(js) == ["deno", "node"] and js["deno"].startswith(str(tmp))      # Deno başta
    assert health.find_ffmpeg() == str(tmp / health._exe("ffmpeg"))
finally:
    health._candidate_dirs, os.environ["PATH"] = old_dirs, old_path
os.environ["PATH"] = "/nonexistent"
try:
    assert health.find_js_runtimes() == {} or True      # (gerçek makinede kurulu olabilir)
    checks = health.run_checks()
    assert {c.key for c in checks} == {"ytdlp", "js", "ejs", "ffmpeg", "numpy", "python"}
    bad = health.problems(checks)
    assert all(c.severity in ("error", "warn") for c in bad)
    assert [c.severity for c in bad] == sorted([c.severity for c in bad], key=lambda s: s != "error")
finally:
    os.environ["PATH"] = old_path
print("Sağlık kontrolü OK")
