"""Görselleştirici çekirdeği: FFT bantları, PCM dönüşümü, zaman damgalı tampon, vuruş algılama, simülasyon."""
import pathlib, sys, time
HERE = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / "fake_qt")); sys.path.insert(0, str(HERE.parent))     # audio_tap Qt'yi sahte alır
import numpy as np
from core.analyzer import SpectrumAnalyzer, VizEngine, simulate, WAVE_POINTS
from core.audio_tap import ChunkBuffer, pcm_to_mono

SR = 44100
def sine(f, n=4096, amp=0.8): return (amp * np.sin(2 * np.pi * f * np.arange(n) / SR)).astype(np.float32)

# ---- FFT: saf sinüs doğru banda düşer; sessizlik sıfır; sesli > sessiz ----
an = SpectrumAnalyzer(64)
for f in (100, 440, 1000, 5000, 12000):
    lv = an.spectrum(sine(f), SR)
    peak = int(lv.argmax())
    edges = np.geomspace(an.fmin, min(an.fmax, SR / 2 * 0.98), 65)
    assert edges[peak] / 1.15 <= f <= edges[peak + 1] * 1.15, (f, peak, edges[peak], edges[peak + 1])
    assert lv.max() > 0.6 and 0 <= lv.min() and lv.max() <= 1
assert an.spectrum(np.zeros(2048, np.float32), SR).max() == 0.0
assert an.spectrum(sine(440, amp=0.8), SR).max() > an.spectrum(sine(440, amp=0.01), SR).max()
assert an.spectrum(sine(440, n=300), SR).shape == (64,)                         # kısa pencere sıfırla doldurulur
an.set_bands(32); assert an.spectrum(sine(440), SR).shape == (32,)
assert an.spectrum(sine(440), 48000).shape == (32,)                              # farklı örnekleme hızı
w = an.waveform(sine(200)); assert w.shape == (WAVE_POINTS,) and abs(w).max() <= 0.81
print("FFT / dalga OK")

# ---- PCM dönüşümü ----
st16 = np.array([[16384, -16384], [32767, 0]], np.int16)                         # 2 kare, stereo
m = pcm_to_mono(st16.tobytes(), "Int16", 2); assert np.allclose(m, [0.0, 0.49998], atol=1e-3)
f32 = np.array([0.5, -0.5, 1.0], np.float32); assert np.allclose(pcm_to_mono(f32.tobytes(), "Float", 1), f32)
u8 = np.array([128, 255, 0], np.uint8); assert np.allclose(pcm_to_mono(u8.tobytes(), "UInt8", 1), [0, 0.992, -1], atol=0.01)
i32 = np.array([2**30], np.int32); assert abs(pcm_to_mono(i32.tobytes(), "Int32", 1)[0] - 0.5) < 1e-6
assert pcm_to_mono(b"\x00" * 3, "Int16", 2).size == 0                            # yarım kare atılır
assert pcm_to_mono(b"\x00" * 7, "Int16", 2).size == 1                            # 1 tam kare + artık bayt
assert pcm_to_mono(b"\x00\x00", "Bilinmeyen", 1) is None
print("PCM dönüşümü OK")

# ---- Tampon: konuma göre doğru pencere, arama, zaman damgasız parçalar ----
ramp = np.arange(44100 * 2, dtype=np.float32)                                    # değer = örnek numarası
buf = ChunkBuffer(max_seconds=5.0)
for k in range(8):                                                               # 8 parça × 0.25 sn
    buf.add(k * 250_000, ramp[k * 11025:(k + 1) * 11025], SR)
out, sr = buf.window(1000, 512)                                                  # 1.0 sn konumunda biten pencere
assert sr == SR and len(out) == 512 and out[-1] == 44099 and out[0] == 44099 - 511   # ardışık, tam 1.0 sn'de bitiyor
out2, _ = buf.window(500, 2048); assert abs(out2[-1] - 22050) <= 1               # konum değişince pencere kayıyor
buf.add(100_000, np.ones(1000, np.float32), SR)                                  # geriye sarma -> eskiler atılır
assert len(buf._chunks) == 1
b2 = ChunkBuffer(); b2.add(-1, np.ones(441, np.float32), SR); b2.add(-1, np.ones(441, np.float32) * 2, SR)
assert abs(b2._chunks[1].start_us - 10_000) < 1                                  # zaman damgası yok: 10 ms sonrası
b3 = ChunkBuffer(max_seconds=0.5)
for k in range(10): b3.add(k * 100_000, np.zeros(4410, np.float32), SR)
assert sum(len(c.samples) for c in b3._chunks) <= 0.5 * SR + 4410                # eski veri budanıyor
b4 = ChunkBuffer(); b4.add(0, np.arange(4410, dtype=np.float32), SR)
assert b4.window(999_999, 100) is not None                                       # konum çok ileride: en yeniyi kullan
assert ChunkBuffer().window(0, 10) is None and not ChunkBuffer().has_data()
assert b4.has_data(max_age=1.0); time.sleep(0.05); assert not b4.has_data(max_age=0.01)
print("Tampon OK")

# ---- Motor: gerçek veri -> 'real'; yok -> 'sim'; duraklatma -> sıfır; vuruş ----
class FakeTap:
    ok = True
    def __init__(s): s.b = ChunkBuffer()
    def has_data(s): return s.b.has_data()
    def window(s, p, n): return s.b.window(p, n)
tap = FakeTap(); eng = VizEngine(tap, 64)
fr = eng.frame(0, True, "abc"); assert fr.kind == "sim" and fr.bands.shape == (64,)       # henüz veri yok
tap.b.add(0, sine(440, n=SR), SR)
fr = eng.frame(500, True, "abc"); assert fr.kind == "real" and fr.bands.max() > 0.5
fr = eng.frame(500, False, "abc"); assert fr.bands.max() == 0 and fr.wave.max() == 0     # duraklatıldı
eng2 = VizEngine(None, 64); fr = eng2.frame(1234, True, "x"); assert fr.kind == "sim"
eng3 = VizEngine(FakeTap(), 64)
t3 = eng3.tap; kicks = []
for k in range(40):                                                                      # sessiz -> patlama -> sessiz
    loud = (k % 10) == 5
    t3.b = ChunkBuffer(); t3.b.add(0, (sine(60, amp=0.9) if loud else sine(60, amp=0.02)), SR)
    kicks.append(eng3.frame(40, True, "k").beat)
assert max(kicks[10:]) > 0.5 and min(kicks[10:]) < 0.5, kicks[10:20]                     # vuruşlar algılanıyor
print("Motor / vuruş OK")

# ---- Simülasyon: aralıkta, deterministik, ritmik, bas ağırlıklı ----
a = simulate(5000, 123, 64); b = simulate(5000, 123, 64); c = simulate(5000, 999, 64)
assert np.array_equal(a[0], b[0]) and not np.array_equal(a[0], c[0])
assert a[0].min() >= 0 and a[0].max() <= 1 and a[1].shape == (WAVE_POINTS,)
bass = np.mean([simulate(t, 7, 64)[0][:6].mean() for t in range(0, 4000, 50)])
high = np.mean([simulate(t, 7, 64)[0][-12:].mean() for t in range(0, 4000, 50)])
assert bass > high
assert simulate(0, 1, 64, playing=False)[0].max() == 0
print("Simülasyon OK")
