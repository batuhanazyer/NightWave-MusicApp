"""Önbellekten çalma (asıl düzeltme): AudioCache, fetch_audio, Player akışları, yedekleme, ön yükleme."""
import os, pathlib, sys, tempfile, threading, time, types
HERE = pathlib.Path(__file__).resolve().parent
os.environ["APPDATA"] = tempfile.mkdtemp()
sys.path.insert(0, str(HERE / "fake_qt")); sys.path.insert(0, str(HERE.parent))
yd = types.ModuleType("yt_dlp"); yd.YoutubeDL = object
class DownloadCancelled(Exception): pass
yd.utils = types.ModuleType("yt_dlp.utils"); yd.utils.DownloadCancelled = DownloadCancelled
sys.modules["yt_dlp"], sys.modules["yt_dlp.utils"] = yd, yd.utils
from core.cache import AudioCache
from core.models import Track
from core import youtube, health, errors

tmp = pathlib.Path(tempfile.mkdtemp())
def T(i, title="t"): return Track(id=(i * 11)[:11], title=title, artist="A", duration=200, source="youtube", url=f"https://www.youtube.com/watch?v={(i*11)[:11]}")

# ---------------- AudioCache ----------------
c = AudioCache(tmp / "c1", max_mb=1); c.dir.mkdir()
assert c.path_for("abc") is None and AudioCache.base_name("sp:Ab/C") == "sp_Ab_C"
(c.dir / "abc.m4a.part").write_bytes(b"x" * 10)                       # yarım indirme sayılmaz
(c.dir / "abc.f140.m4a").write_bytes(b"x" * 10)                       # birleştirme geçicisi sayılmaz
assert c.path_for("abc") is None
(c.dir / "abc.m4a").write_bytes(b"x" * 10); assert c.path_for("abc").name == "abc.m4a"
assert c.path_for("ab") is None and c.path_for("abcd") is None        # önek karışmaz
# kırpma: 1 MB sınır, en eski önce silinir, keep korunur, taze .part dokunulmaz
for i, name in enumerate(["old", "mid", "new"]):
    p = c.dir / f"{name}.m4a"; p.write_bytes(b"x" * 600_000); os.utime(p, (1000 + i, 1000 + i))
part = c.dir / "dl.m4a.part"; part.write_bytes(b"x" * 100)
removed = c.trim(keep=c.dir / "old.m4a")
assert (c.dir / "old.m4a").exists() and not (c.dir / "mid.m4a").exists() and part.exists(), sorted(p.name for p in c.dir.iterdir())
assert c.size() <= 1024 * 1024 + 700_000 and removed >= 1
assert c.clear() >= 2 and c.size() == 0
c4 = AudioCache(tmp / "c4"); c4.dir.mkdir()
(c4.dir / "abc.m4a").write_bytes(b"x"); (c4.dir / "abc.mp3").write_bytes(b"x")
assert c4.path_for("abc").suffix == ".mp3"                                # ikisi de varsa MP3 seçilir
(c4.dir / "abc.m4a").unlink(); (c4.dir / "abc.m4a").write_bytes(b"x"); (c4.dir / "d.webm.part").write_bytes(b"x")
assert c4.purge_non_mp3() == 1 and not (c4.dir / "abc.m4a").exists() and (c4.dir / "abc.mp3").exists() and (c4.dir / "d.webm.part").exists()
print("AudioCache OK")

# ---------------- fetch_audio (sahte yt-dlp) ----------------
log = {"downloads": 0, "opts": None}
class FakeYDL:
    def __init__(s, **opts): s.opts = opts; log["opts"] = opts
    def __enter__(s): return s
    def __exit__(s, *a): return False
    def extract_info(s, target, download=True):
        log["downloads"] += 1; log["target"] = target
        hook = s.opts["progress_hooks"][0]
        for done in (25, 50, 100):
            hook({"status": "downloading", "downloaded_bytes": done, "total_bytes": 100}); time.sleep(0.01)
        ext = "mp3" if s.opts.get("postprocessors") else "m4a"
        out = s.opts["outtmpl"].replace("%(ext)s", ext).replace("%%", "%")
        pathlib.Path(out).write_bytes(b"audio"); return {}
youtube._make_ydl = lambda js=False, **o: FakeYDL(**o)
health.find_ffmpeg = lambda: None                                   # önce FFmpeg YOK senaryosu
cache = AudioCache(tmp / "c2", max_mb=50)
prog = []
path = youtube.fetch_audio(T("a"), cache, progress=prog.append)
assert path.exists() and path.parent == cache.dir and prog == [25, 50, 99, 100], prog
assert log["opts"]["format"].startswith("bestaudio") and "postprocessors" not in log["opts"]    # FFmpeg gerekmez
assert log["target"].startswith("https://www.youtube.com/watch")
assert youtube.fetch_audio(T("a"), cache) == path and log["downloads"] == 1                      # ikinci istek: indirme yok
sp = Track(id="sp:4uLU6hMCjMI75M1A2tKUQC", title="x", artist="y", source="spotify", query="y - x official audio")
youtube.fetch_audio(sp, cache); assert log["target"] == "ytsearch1:y - x official audio" and cache.path_for(sp.id)  # Spotify: aramayla
# iptal
try: youtube.fetch_audio(T("b"), cache, cancelled=lambda: True); raise SystemExit("iptal çalışmadı")
except RuntimeError as e: assert "İptal" in str(e)
assert cache.path_for(T("b").id) is None
# aynı parça aynı anda iki kez istenirse tek indirme
log["downloads"] = 0; results = []
ths = [threading.Thread(target=lambda: results.append(youtube.fetch_audio(T("c"), cache))) for _ in range(4)]
[t.start() for t in ths]; [t.join() for t in ths]
assert log["downloads"] == 1 and len(set(map(str, results))) == 1 and len(results) == 4, (log, results)
# hata açıklaması: JS yoksa asıl neden söylenir
class Boom(FakeYDL):
    def extract_info(s, *a, **k): raise RuntimeError("ERROR: Requested format is not available")
youtube._make_ydl = lambda js=False, **o: Boom(**o)
health.find_js_runtimes = lambda: {}
try: youtube.fetch_audio(T("d"), cache); raise SystemExit("hata beklenirdi")
except RuntimeError as e: assert "Deno" in str(e)
health.find_js_runtimes = lambda: {"deno": "x"}
try: youtube.fetch_audio(T("d"), cache); raise SystemExit("hata beklenirdi")
except RuntimeError as e: assert "Requested format" in str(e)
youtube._make_ydl = lambda js=False, **o: FakeYDL(**o)
# --- FFmpeg VARKEN: MP3'e çevrilir (İndir düğmesinin ürettiği, çalan biçim) ---
health.find_ffmpeg = lambda: "/x/ffmpeg"
mp = youtube.fetch_audio(T("e"), cache)
assert mp.suffix == ".mp3" and log["opts"]["postprocessors"][0]["preferredcodec"] == "mp3" and log["opts"]["ffmpeg_location"] == "/x"
# dönüştürme çökerse ama ham dosya kaldıysa onu kullan; hiçbir şey kalmadıysa gerçek hatayı ver
class HalfDone(FakeYDL):
    def extract_info(s, target, download=True):
        pathlib.Path(s.opts["outtmpl"].replace("%(ext)s", "m4a").replace("%%", "%")).write_bytes(b"raw")
        raise RuntimeError("ERROR: Postprocessing: ffmpeg crashed")
youtube._make_ydl = lambda js=False, **o: HalfDone(**o)
raw = youtube.fetch_audio(T("f"), cache); assert raw.suffix == ".m4a"
class NothingDone(FakeYDL):
    def extract_info(s, *a, **k): raise RuntimeError("ERROR: Postprocessing: ffmpeg crashed")
youtube._make_ydl = lambda js=False, **o: NothingDone(**o)
health.find_js_runtimes = lambda: {"deno": "x"}
try: youtube.fetch_audio(T("g"), cache); raise SystemExit("hata beklenirdi")
except RuntimeError as e: assert "FFmpeg" in errors.friendly_error(e)
youtube._make_ydl = lambda js=False, **o: FakeYDL(**o); health.find_ffmpeg = lambda: None
print("fetch_audio OK")

# ---------------- Player ----------------
from core.player import Player
p = Player(); p.cache = AudioCache(tmp / "c3", max_mb=50); p.play_mode = "cache"
p.progressive = False                      # bu bölüm: klasik 'önce indir sonra çal' yolu
fetched, played, errors_, statuses = [], [], [], []
real_play_file = p._play_file
p._play_file = lambda path: (played.append(os.path.basename(path)), real_play_file(path))
p.error.connect(errors_.append); p.status_message.connect(statuses.append)
def fake_fetch(track, cache, progress=None, cancelled=None, stage=None):
    fetched.append(track.id)
    if stage: stage("Hazırlanıyor… %40 · 1.2 MB/s")
    cache.dir.mkdir(parents=True, exist_ok=True)
    f = cache.dir / (cache.base_name(track.id) + ".m4a"); f.write_bytes(b"a"); return f
youtube.fetch_audio = fake_fetch
tracks = [T("a"), T("b"), T("c")]
p.prefetch = False
p.set_queue(tracks, 0)
assert fetched == [tracks[0].id] and played == [cache.base_name(tracks[0].id) + ".m4a"], (fetched, played)   # indirip yerelden çaldı
assert any("%40" in s and "MB/s" in s for s in statuses) and statuses[-1] == ""                                              # ilerleme gösterildi, sonra temizlendi
p.play_index(0); assert fetched == [tracks[0].id]                                                            # ikinci kez: indirme yok
# bu arada başka şarkıya geçilirse eski sonuç yok sayılır
played.clear(); late = []
def slow_fetch(track, cache, progress=None, cancelled=None, stage=None):
    if not late:
        late.append(1); p.play_index(1)          # indirme sürerken kullanıcı başka şarkıya tıklar
    return fake_fetch(track, cache)
youtube.fetch_audio = slow_fetch
p.cache.clear(); fetched.clear(); p.play_index(0)
assert played and played[-1].startswith(cache.base_name(tracks[1].id)), played                               # son tıklanan çalıyor
youtube.fetch_audio = fake_fetch
# önbellekteki dosya bozuksa silinir, kullanıcıya söylenir
p.cache.clear(); p.play_index(2); errors_.clear()
assert p._from_cache and p.cache.path_for(tracks[2].id)
p._on_error(object(), "decode error"); assert p.cache.path_for(tracks[2].id) is None and "silindi" in errors_[-1]
# akış modu: çözülemezse önbelleğe düşer
p.play_mode = "stream"; p.cache.clear(); fetched.clear(); played.clear()
def bad_resolve(track, alt=False): raise RuntimeError("n challenge solving failed")
youtube.resolve_stream = bad_resolve
p.play_index(0); assert fetched == [tracks[0].id] and played, (fetched, played)
# akış modu: Qt hata verirse önce yedek format, sonra önbellek
p.cache.clear(); fetched.clear(); played.clear(); alts = []
youtube.resolve_stream = lambda t, alt=False: (alts.append(alt), "https://fake/s.m4a")[1]
p.play_index(0); assert alts == [False] and p._streaming
p._on_error(object(), "network"); assert alts == [False, True]                                                # 1. hata: yedek format
p._on_error(object(), "network"); assert fetched == [tracks[0].id] and played                                 # 2. hata: indirip çal
p._on_error(object(), "x"); assert errors_[-1]                                                                # sonrası: gerçek hata gösterilir
# hata: indirme başarısızsa kullanıcıya iletilir
p.play_mode = "cache"; errors_.clear(); p.cache.clear()
def fail_fetch(*a, **k): raise RuntimeError(errors.MSG_JS)
youtube.fetch_audio = fail_fetch; p.play_index(0); assert errors_ and "Deno" in errors_[-1]
# ön yükleme: sıradaki parça hazırlanır, çalan tekrar indirilmez, karışıkta sıra korunur
youtube.fetch_audio = fake_fetch; p.prefetch = True; p.cache.clear(); fetched.clear(); p._inflight.clear()
p.set_queue(tracks, 0, shuffle=False)
assert fetched == [tracks[0].id, tracks[1].id], fetched
p.next(); assert fetched == [tracks[0].id, tracks[1].id, tracks[2].id], fetched                                 # 1. çalarken 2. hazır, 2.'de 3. hazırlandı
p.cache.clear(); fetched.clear(); p._inflight.clear()
p.set_queue(tracks, 0, shuffle=True); nxt = p.queue[p.order.items[1]].id
assert fetched == [tracks[p.order.items[0]].id, nxt], fetched                                                    # karışık sıradaki gerçek "sonraki"
print("Player önbellek akışları OK")

# =====================================================================================
# İNDİRİRKEN ÇAL (progressive): Player akışları
# =====================================================================================
from core import errors as errmod
p.progressive = True; p.raw_ok = True; p.prefetch = False
urls, played[:] = [], []
p._play_url = lambda u: urls.append(u)                                  # Qt'ye verilen kaynak sayısı
ready_url = "http://127.0.0.1:1/s/aaaaaaaaaaaaaaaa.m4a"; prog_calls = []
def fake_prog(track, cache, on_ready, stage=None, cancelled=None, start_bytes=0):
    prog_calls.append(track.id)
    if stage: stage("Çözümleniyor…")
    on_ready(ready_url)                                                  # yeterli veri indi
    cache.dir.mkdir(parents=True, exist_ok=True)
    f = cache.dir / (cache.base_name(track.id) + ".m4a"); f.write_bytes(b"a"); return f   # indirme tamamlandı
_real_fetch_progressive = youtube.fetch_progressive
youtube.fetch_progressive = fake_prog

p.cache.clear(); statuses.clear(); p.set_queue(tracks, 0)
assert prog_calls == [tracks[0].id] and len(urls) == 1 and played == [], (prog_calls, urls, played)   # tamamı beklenmeden çalmaya başladı
assert p._prog_active and p._prog_url == ready_url and p._cached_path and p._watchdog is not None
assert "Çözümleniyor…" in statuses and statuses[-1] == ""
print("indirirken çal: erken başlama OK")

# eski jetonlu hazır/aşama sinyalleri yok sayılır
n = len(urls); p._ready_sig.emit(ready_url, p._token - 1); assert len(urls) == n
statuses.clear(); p._stage_sig.emit("eski", p._token - 1); assert statuses == []
p._stage_sig.emit("Hazırlanıyor… %10", p._token); assert statuses == []         # zaten çalıyor: durum satırı gürültüsü yok
p._prog_active = False; p._stage_sig.emit("Hazırlanıyor… %10", p._token); assert statuses == ["Hazırlanıyor… %10"]
p._prog_active = True

# Qt indirirken-çal kaynağını çalamazsa: indirme bitmişse yerelden, bitmemişse tamamı inince
played.clear(); p._prog_active, p._cached_path = True, str(p.cache.dir / (p.cache.base_name(tracks[0].id) + ".m4a"))
p._on_error(object(), "decode error"); assert not p._prog_active and len(played) == 1                 # bitmiş: hemen yerelden
p._prog_active, p._cached_path, played[:] = True, None, []
p._on_error(object(), "decode error"); assert p._await_full and played == []                          # bitmemiş: bekle
p._on_cached(str(p.cache.dir / (p.cache.base_name(tracks[0].id) + ".m4a")), p._token); assert len(played) == 1 and not p._await_full
p._prog_active, p._cached_path, played[:] = True, None, []
p._on_position(0); p._watchdog.stop = lambda: None; p._media.position = lambda: 0
p._on_watchdog(); assert p._await_full                                                                # ses hiç gelmedi: zaman aşımı yedeği
print("indirirken çal: yedekler OK")

# Ham ses yerelde de çalınamazsa: MP3'e geç, bir daha ham deneme, ayarlara haber ver
health.find_ffmpeg = lambda: "/x/ffmpeg"; raw_events = []; p.raw_failed.connect(lambda: raw_events.append(1))
def fake_mp3(track, cache, progress=None, cancelled=None, stage=None):
    fetched.append(("mp3", track.id)); cache.dir.mkdir(parents=True, exist_ok=True)
    f = cache.dir / (cache.base_name(track.id) + ".mp3"); f.write_bytes(b"m"); return f
youtube.fetch_audio = fake_mp3; fetched.clear(); played.clear(); p.cache.clear()
raw = p.cache.dir / (p.cache.base_name(tracks[1].id) + ".m4a"); raw.parent.mkdir(parents=True, exist_ok=True); raw.write_bytes(b"raw")
p.set_queue(tracks, 1)                                                                                # ham dosya önbellekte: yerelden çalmayı dener
assert played and played[-1].endswith(".m4a") and p._from_cache
p._on_error(object(), "Cannot decode")
assert p.raw_ok is False and raw_events == [1] and fetched == [("mp3", tracks[1].id)], (p.raw_ok, raw_events, fetched)
assert played[-1].endswith(".mp3")                                                                    # MP3 olarak çalıyor
assert p._local_path(tracks[1]).endswith(".mp3")
(p.cache.dir / (p.cache.base_name(tracks[2].id) + ".m4a")).write_bytes(b"raw")
assert p._local_path(tracks[2]) is None                                                               # raw_ok=False: ham dosyalar yok sayılır
p.raw_ok = True; assert p._local_path(tracks[2]).endswith(".m4a")
print("ham ses -> MP3 yedeği OK")

# FFmpeg yoksa dönüştürme olmaz: bozuk dosya silinir ve kullanıcıya söylenir
health.find_ffmpeg = lambda: None; errors_.clear(); p.cache.clear()
p.set_queue(tracks, 2) if False else None
bad = p.cache.dir / (p.cache.base_name(tracks[0].id) + ".m4a"); bad.parent.mkdir(parents=True, exist_ok=True); bad.write_bytes(b"raw")
p.set_queue(tracks, 0); p._on_error(object(), "x"); assert not bad.exists() and "silindi" in errors_[-1]

# ön yükleme / fare üstüne gelince hazırlama sınırları
youtube.fetch_audio = fake_fetch; p.prefetch = True; p.raw_ok = True; p._inflight.clear(); p.cache.clear(); fetched.clear()
p.prefetch_track(tracks[1]); assert fetched == [tracks[1].id]
p.prefetch_track(tracks[1]); assert fetched == [tracks[1].id]                                        # tekrar yok (önbellekte)
p.prefetch = False; p.cache.clear(); p.prefetch_track(tracks[2]); assert fetched == [tracks[1].id]   # kapalıysa hazırlama yok
p.prefetch = True; p._inflight.update({"x1", "x2", "x3"}); p.prefetch_track(tracks[2]); assert fetched == [tracks[1].id]   # en çok 3 eşzamanlı
p._inflight.clear(); p.prefetch_track(Track(id="local:a", title="l", source="local")); assert fetched == [tracks[1].id]
print("ön yükleme sınırları OK")

# =====================================================================================
# fetch_progressive (gerçek yerel sunucu + sahte yt-dlp)
# =====================================================================================
youtube.fetch_progressive = _real_fetch_progressive          # gerçek işlevi geri yükle
import http.client
from core import progressive as pg
DATA = bytes((i * 11 + 5) % 253 for i in range(700_000))
class ProgYDL(FakeYDL):
    fail_at = None
    def extract_info(s, target, download=True):
        hook = s.opts["progress_hooks"][0]
        out = pathlib.Path(s.opts["outtmpl"].replace("%(ext)s", "m4a").replace("%%", "%")); part = pathlib.Path(str(out) + ".part")
        pos = 0
        while pos < len(DATA):
            if ProgYDL.fail_at is not None and pos >= ProgYDL.fail_at: raise RuntimeError("ERROR: network down")
            with open(part, "ab") as fh: fh.write(DATA[pos:pos + 100_000])
            pos += 100_000; pos = min(pos, len(DATA))
            hook({"status": "downloading", "downloaded_bytes": pos, "total_bytes": len(DATA), "speed": 600_000,
                  "tmpfilename": str(part), "filename": str(out)}); time.sleep(0.05)
        os.replace(part, out); hook({"status": "finished", "filename": str(out)}); return {}
youtube._make_ydl = lambda js=False, **o: ProgYDL(**o)
health.find_js_runtimes = lambda: {"deno": "x"}
pc = AudioCache(tmp / "c5", max_mb=50)

def http_get(url, rng="bytes=0-"):
    u = url.split("://", 1)[1]; host, path = u.split("/", 1)
    c = http.client.HTTPConnection(host, timeout=15); c.request("GET", "/" + path, headers={"Range": rng}); r = c.getresponse()
    try: body = r.read()
    except http.client.IncompleteRead as e: body = e.partial
    c.close(); return r.status, body

got, stages, ready = {}, [], []
def on_ready(url):                                                     # Qt'nin yaptığı gibi: indirme sürerken yerel adresten oku
    ready.append((url, time.time()))
    th = threading.Thread(target=lambda: got.update(zip(("status", "body"), http_get(url)))); th.start(); got["th"] = th
t0 = time.time()
final = youtube.fetch_progressive(T("pa"), pc, on_ready, stage=stages.append, start_bytes=250_000)
got["th"].join()
assert len(ready) == 1 and final.read_bytes() == DATA and final.suffix == ".m4a"
assert ready[0][1] - t0 < (time.time() - t0) - 0.1, "on_ready indirme bitmeden ÖNCE çağrılmalıydı"
assert got["status"] == 206 and got["body"] == DATA                       # Qt'nin okuduğu içerik, inen dosyayla birebir aynı
assert stages[0] == "Çözümleniyor…" and any("%" in x and "KB/s" in x for x in stages), stages
print("fetch_progressive: erken hazır + içerik birebir OK")
ready.clear(); again = youtube.fetch_progressive(T("pa"), pc, on_ready); assert again == final and ready == []          # önbellekte: sunucuya gerek yok
# iptal: Cancelled (sessiz hata türü)
try: youtube.fetch_progressive(T("pb"), pc, on_ready, cancelled=lambda: True); raise SystemExit("iptal edilmedi")
except errmod.Cancelled: pass
# indirme ortasında koparsa: istemci sonsuza beklemez, hata iletilir
ProgYDL.fail_at = 300_000; ready.clear(); got.clear(); t0 = time.time()
try: youtube.fetch_progressive(T("pc"), pc, on_ready, start_bytes=150_000); raise SystemExit("hata beklenirdi")
except RuntimeError as e: assert "network" in str(e) or "Ağ" in errmod.friendly_error(e)
got["th"].join(timeout=10); assert not got["th"].is_alive() and len(got["body"]) < len(DATA) and time.time() - t0 < 12
ProgYDL.fail_at = None
print("fetch_progressive: iptal + kopma OK")

# ---- Cancelled sessiz: ne hata geri çağrısı ne konsol çıktısı ----
from core.workers import run_async
res = []
def cancel_job(): raise errmod.Cancelled("x")
run_async(cancel_job, on_result=lambda r: res.append("result"), on_error=lambda m: res.append("error"))
assert res == []
print("iptal sessiz OK")

# ---- ölçüm metinleri ----
assert youtube._fmt_speed(1_500_000) == "1.4 MB/s" and youtube._fmt_speed(350_000) == "342 KB/s" and youtube._fmt_speed(None) == ""
assert youtube._progress_text(2_000_000, 4_000_000, 2_000_000) == "Hazırlanıyor… %50 · 1.9 MB/s"
assert youtube._progress_text(2_000_000, 4_000_000, 50_000).endswith("· yavaş")                    # yavaş indirme işaretlenir
assert not youtube._progress_text(100_000, 4_000_000, 50_000).endswith("yavaş")                    # çok erken: işaretleme
assert "Deno" in errmod.warning_hint("WARNING: n challenge solving failed") and errmod.warning_hint("normal") == ""
print("ölçüm metinleri OK")
pg.server().shutdown()
