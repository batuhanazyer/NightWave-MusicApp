"""Tema sistemi, özel tema, tema kodu ve baskın renk testleri (Qt gerektirmez)."""
import base64, json, pathlib, re, sys, zlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))
from ui import colors, styles

for k in list(styles.THEMES) + ["auto", "nope"]:
    assert not re.search(r"%[A-Z_]+%", styles.build_qss(k, "#FACC15")), k
custom = {"custom:ab12": {"name": "Benim", "bg": "#101820", "panel": "#182430", "text": "#FFE9D6"},
          "custom:bad": {"name": "x", "bg": "red", "panel": "#000000", "text": "#FFFFFF"}}
assert styles.get_palette("custom:ab12", "#FB923C", custom)["bg"] == "#101820"
assert styles.get_palette("custom:bad", "#FB923C", custom)["bg"] == styles.THEMES["midnight"]["bg"]
code = styles.theme_to_code("Benim", "#101820", "#182430", "#FFE9D6", "#FB923C")
assert styles.theme_from_code(code)["accent"] == "#FB923C"
for bad in ["", "NWT1:", "NWT1:@@", "NWT1:" + base64.urlsafe_b64encode(zlib.compress(
        json.dumps({"bg": "url(x)", "panel": "#000000", "text": "#FFFFFF"}).encode())).decode(),
        "NWT1:" + base64.urlsafe_b64encode(zlib.compress(b"0" * 100000)).decode()]:
    try:
        styles.theme_from_code(bad); raise SystemExit("kabul edilmemeliydi")
    except ValueError:
        pass
c = colors.dominant_from_pixels([(220, 30, 30)] * 60 + [(240, 240, 240)] * 100 + [(20, 20, 20)] * 100)
r, g, b = (int(c[i:i + 2], 16) for i in (1, 3, 5)); assert r > g and r > b
assert colors.dominant_from_pixels([(128, 128, 128)] * 50) is None
print("Temalar ve renk OK")
