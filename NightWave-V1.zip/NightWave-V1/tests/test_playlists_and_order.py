import sys, json, base64, zlib, tempfile
from pathlib import Path
import pathlib; sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))
from core.play_order import PlayOrder
from core.models import Track
from core import playlists as P

# ---- PlayOrder ----
o = PlayOrder(); o.rebuild(5)
assert o.items == [0,1,2,3,4]
assert o.next(4, wrap=False) is None and o.next(4, wrap=True) == 0
assert o.prev(0) == 4 and o.prev(3) == 2
o.shuffle = True; o.rebuild(8, first=3)
assert o.items[0] == 3 and sorted(o.items) == list(range(8))
cur = o.items[-1]
for _ in range(50):                      # tur bitince yeni tur, aynı parça arka arkaya gelmesin
    nxt = o.next(cur, wrap=True)
    assert nxt != cur and sorted(o.items) == list(range(8)); cur = nxt
o.shuffle = False; o.rebuild(3); o.add(3, after=0); assert o.items == [0,3,1,2]
o.add(4); assert o.items == [0,3,1,2,4] and o.from_pos(1) == [1,2,4]
print("PlayOrder OK")

# ---- Paylaşım gidiş-dönüş ----
tmp = Path(tempfile.mkdtemp())
store = P.PlaylistStore(tmp/"pl.json", tmp/"covers")
pl = store.create("Yolculuk ☕", "uzun yol", "#12ab34", "🚗")
yt = Track(id="dQw4w9WgXcQ", title="Song A", artist="Art", duration=213, source="youtube",
           url="https://www.youtube.com/watch?v=dQw4w9WgXcQ", thumbnail="https://i.ytimg.com/vi/x/hq.jpg?sqp=abc", local_path="C:/x.mp3")
sp = Track(id="sp:4uLU6hMCjMI75M1A2tKUQC", title="Song B", artist="B", duration=100, source="spotify",
           thumbnail="https://i.scdn.co/image/abc", query="B - Song B official audio")
loc = Track(id="local:a.mp3", title="Local", source="local", local_path="C:/a.mp3")
assert store.add_tracks(pl.id, [yt, sp, loc, yt]) == 3        # tekrar eklenmez
assert store.tracks(pl.id)[0].local_path == ""                 # cihaza özel yol saklanmaz
code, skipped = P.to_share_code(pl, store.tracks(pl.id))
assert code.startswith("NW1:") and skipped == 1                # yerel parça atlandı
back = P.from_share_code(code)
assert back.name == pl.name and back.color == "#12ab34" and len(back.tracks) == 2 and back.id != pl.id
t0 = Track.from_dict(back.tracks[0])
assert t0.url == "https://www.youtube.com/watch?v=dQw4w9WgXcQ" and t0.local_path == ""
print("Paylaşım kodu OK  (", len(code), "karakter )")

# dosya + M3U
f = tmp/"a.nwpl"; assert P.export_file(pl, store.tracks(pl.id), f) == 1
assert len(P.import_file(f).tracks) == 2
f2 = tmp/"code.txt"; f2.write_text(code); assert len(P.import_file(f2).tracks) == 2
P.export_m3u(pl, store.tracks(pl.id), tmp/"a.m3u8"); assert "#EXTINF:213" in (tmp/"a.m3u8").read_text(encoding="utf-8")
print("Dosya/M3U OK")

# ---- Kötü niyetli girdi ----
evil = {"name": "x"*500, "color": "javascript:alert(1)", "emoji": "A"*50, "tracks": [
    {"id": "dQw4w9WgXcQ", "title": "ok", "source": "youtube", "url": "file:///C:/Windows/win.ini", "thumbnail": "http://169.254.169.254/"},
    {"id": "../../etc/passwd", "title": "bad", "source": "youtube"},
    {"id": "sp:4uLU6hMCjMI75M1A2tKUQC", "title": "sp", "source": "spotify", "thumbnail": "https://evil.example/track.png"},
    {"id": "local:x", "title": "l", "source": "local", "local_path": "C:/secret"},
    "string", None, 5]}
e = P._playlist_from_obj(evil)
assert len(e.tracks) == 2 and len(e.name) == 80 and e.color == "#8B7CFF" and len(e.emoji) <= 8
assert e.tracks[0]["url"] == "https://www.youtube.com/watch?v=dQw4w9WgXcQ"
assert e.tracks[1]["thumbnail"] == ""                          # bilinmeyen host reddedildi
for bad in ["", "NW1:", "NW1:@@@", "NW1:" + base64.urlsafe_b64encode(b"not zlib").decode()]:
    try: P.from_share_code(bad); raise SystemExit("kabul edilmemeliydi: "+bad)
    except ValueError: pass
bomb = base64.urlsafe_b64encode(zlib.compress(b"0"*(6*1024*1024), 9)).decode()
try: P.from_share_code("NW1:"+bomb); raise SystemExit("zip bombası geçti!")
except ValueError as ex: assert "büyük" in str(ex) or "geçersiz" in str(ex)
try: P._playlist_from_obj({"tracks": [{"id":"bad","title":"t","source":"youtube"}]}); raise SystemExit("boş liste geçti")
except ValueError: pass
print("Güvenlik OK")

# sıralama / taşıma / yeniden yükleme
pl2 = store.create("S"); store.add_tracks(pl2.id, [Track(id="aaaaaaaaaaa", title="Zeta", source="youtube"), Track(id="bbbbbbbbbbb", title="Alfa", source="youtube")])
store.move_track(pl2.id, 0, +1); assert [t.title for t in store.tracks(pl2.id)] == ["Alfa","Zeta"]
store.update(pl2.id, sort="title"); store.move_track(pl2.id, 0, +1); assert [t.title for t in store.tracks(pl2.id)] == ["Alfa","Zeta"]
store.update(pl2.id, sort="artist")
s2 = P.PlaylistStore(tmp/"pl.json", tmp/"covers"); assert len(s2.all()) == 2 and s2.get(pl.id).emoji == "🚗"
store.delete(pl2.id); assert len(P.PlaylistStore(tmp/"pl.json", tmp/"covers").all()) == 1
print("Depo OK")
