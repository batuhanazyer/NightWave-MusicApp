"""'İndirirken çal' sunucusu: gerçek yerel soketlerle (Qt/ağ gerektirmez)."""
import http.client, os, pathlib, sys, tempfile, threading, time
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))
from core import progressive as pg

tmp = pathlib.Path(tempfile.mkdtemp())
DATA = bytes((i * 7 + 3) % 251 for i in range(300_000))                    # tanınabilir içerik

def get(url, rng=None, method="GET", timeout=10):
    u = url.split("://", 1)[1]; host, path = u.split("/", 1)
    c = http.client.HTTPConnection(host, timeout=timeout)
    c.request(method, "/" + path, headers={"Range": rng} if rng else {})
    r = c.getresponse(); body = r.read(); hdr = dict(r.getheaders()); c.close()
    return r.status, hdr, body

srv = pg.server()

# ---- tamamlanmış dosya: Range'ler doğru bayt aralığını verir ----
f = tmp / "a.m4a"; f.write_bytes(DATA)
st = pg.Stream(lambda: f, total=len(DATA)); st.done.set(); url = srv.register(st)
assert url.startswith("http://127.0.0.1:") and url.endswith(".m4a")
s, h, b = get(url); assert s == 200 and b == DATA and h["Accept-Ranges"] == "bytes" and h["Content-Type"] == "audio/mp4"
s, h, b = get(url, "bytes=1000-1999"); assert s == 206 and b == DATA[1000:2000] and h["Content-Range"] == f"bytes 1000-1999/{len(DATA)}"
s, h, b = get(url, "bytes=299000-"); assert s == 206 and b == DATA[299000:] and h["Content-Range"] == f"bytes 299000-299999/{len(DATA)}"   # açık uçlu
s, h, b = get(url, "bytes=0-9999999"); assert s == 206 and b == DATA                                   # sonu aşan istek kırpılır
s, h, b = get(url, "bytes=-500"); assert s == 206 and b == DATA[-500:]                                  # son N bayt
s, h, b = get(url, "bytes=300000-"); assert s == 416 and h["Content-Range"] == f"bytes */{len(DATA)}"
s, h, b = get(url, method="HEAD"); assert s == 200 and b == b"" and h["Content-Length"] == str(len(DATA))
print("tam dosya + Range OK")

# ---- büyüyen dosya: sunucu yeni veri gelene kadar bekler, içerik bozulmadan ulaşır ----
part, final = tmp / "g.m4a.part", tmp / "g.m4a"
part.write_bytes(b"")
st = pg.Stream(lambda: pg.existing(part, final), total=len(DATA)); url = srv.register(st)
def writer():
    pos = 0
    while pos < len(DATA):
        with open(part, "ab") as fh: fh.write(DATA[pos:pos + 20_000])
        pos += 20_000; time.sleep(0.03)
    os.replace(part, final)                                            # yt-dlp bitince .part'ı yeniden adlandırır
    st.done.set()
t0 = time.time(); th = threading.Thread(target=writer); th.start()
s, h, b = get(url, "bytes=0-")
th.join(); assert s == 206 and b == DATA, (s, len(b))                  # yeniden adlandırma sırasında bile eksiksiz
assert time.time() - t0 > 0.25                                         # gerçekten bekledi (dosya yavaş büyüdü)
print("büyüyen dosya + yeniden adlandırma OK")

# ---- ilk baytlar dosya tamamlanmadan gelir (asıl amaç: erken başlama) ----
part2, final2 = tmp / "h.m4a.part", tmp / "h.m4a"; part2.write_bytes(DATA[:50_000])
st2 = pg.Stream(lambda: pg.existing(part2, final2), total=len(DATA)); url2 = srv.register(st2)
u = url2.split("://", 1)[1]; host, path = u.split("/", 1)
c = http.client.HTTPConnection(host, timeout=10); c.request("GET", "/" + path, headers={"Range": "bytes=0-"}); r = c.getresponse()
first = r.read(40_000); assert first == DATA[:40_000]                  # dosyanın %17'si varken ilk bayt hemen geldi
def finish():
    time.sleep(0.2)
    with open(part2, "ab") as fh: fh.write(DATA[50_000:])
    os.replace(part2, final2); st2.done.set()
threading.Thread(target=finish).start(); rest = r.read(); c.close()
assert first + rest == DATA
print("erken başlama OK")

# ---- toplam bilinmiyorsa: Range yok sayılır, 200 ve baştan, Accept-Ranges: none ----
f3 = tmp / "u.m4a"; f3.write_bytes(DATA[:1000])
st3 = pg.Stream(lambda: f3, total=None); st3.done.set(); url3 = srv.register(st3)
s, h, b = get(url3, "bytes=500-"); assert s == 200 and b == DATA[:1000] and h["Accept-Ranges"] == "none" and "Content-Length" not in h
print("toplam bilinmiyor OK")

# ---- indirme başarısız olursa bağlantı kesilir (Qt hata alır, oynatıcı yedeğe düşer) ----
f4 = tmp / "f.m4a"; f4.write_bytes(DATA[:10_000])
st4 = pg.Stream(lambda: f4, total=len(DATA)); url4 = srv.register(st4)
threading.Timer(0.3, lambda: (setattr(st4, "failed", True), st4.done.set())).start()
c = http.client.HTTPConnection(url4.split("://")[1].split("/")[0], timeout=10)
c.request("GET", "/" + url4.split("://")[1].split("/", 1)[1], headers={"Range": "bytes=0-"}); r = c.getresponse()
try: got = r.read()
except http.client.IncompleteRead as e: got = e.partial
assert len(got) == 10_000 and got == DATA[:10_000]                      # eldeki kadarı verip kesti, sonsuza beklemedi
print("başarısız indirme OK")

# ---- durgunluk zaman aşımı ----
old = pg.STALL_TIMEOUT; pg.STALL_TIMEOUT = 0.4
f5 = tmp / "s.m4a"; f5.write_bytes(DATA[:1000]); st5 = pg.Stream(lambda: f5, total=len(DATA)); url5 = srv.register(st5)
t0 = time.time()
c = http.client.HTTPConnection(url5.split("://")[1].split("/")[0], timeout=10)
c.request("GET", "/" + url5.split("://")[1].split("/", 1)[1]); r = c.getresponse()
try: r.read()
except http.client.IncompleteRead: pass
assert time.time() - t0 < 3; pg.STALL_TIMEOUT = old
print("durgunluk zaman aşımı OK")

# ---- istemci ortasında kopar: sunucu çökmez, sonraki istek çalışır ----
f6 = tmp / "d.m4a"; f6.write_bytes(DATA); st6 = pg.Stream(lambda: f6, total=len(DATA)); st6.done.set(); url6 = srv.register(st6)
for _ in range(5):
    c = http.client.HTTPConnection(url6.split("://")[1].split("/")[0], timeout=5)
    c.request("GET", "/" + url6.split("://")[1].split("/", 1)[1]); r = c.getresponse(); r.read(100); c.close()   # yarıda bırak
s, h, b = get(url6); assert s == 200 and b == DATA
# ---- eşzamanlı istemciler ----
out = []
ths = [threading.Thread(target=lambda i=i: out.append(get(url6, f"bytes={i*1000}-{i*1000+999}")[2] == DATA[i*1000:i*1000+1000])) for i in range(8)]
[t.start() for t in ths]; [t.join() for t in ths]; assert all(out) and len(out) == 8
print("kopan bağlantı + eşzamanlı istemciler OK")

# ---- güvenlik: kayıtsız/yanlış yol 404, kayıt silinince 404, eski akışlar atılır ----
assert get(url.rsplit("/", 1)[0] + "/ffffffffffffffff.m4a")[0] == 404
assert get(url.rsplit("/s/", 1)[0] + "/etc/passwd")[0] == 404 and get(url.rsplit("/s/", 1)[0] + "/s/../../x")[0] in (404, 400)
srv.unregister(url6); assert get(url6)[0] == 404
urls = [srv.register(pg.Stream(lambda: f, total=1)) for _ in range(pg.MAX_STREAMS + 3)]
assert get(urls[0])[0] == 404 and get(urls[-1])[0] in (200, 206)
print("güvenlik OK")
srv.shutdown()
