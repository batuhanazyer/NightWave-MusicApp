"""Tüm testleri sırayla çalıştırır:  python tests/run_all.py"""
import pathlib
import subprocess
import sys

HERE = pathlib.Path(__file__).resolve().parent
failed = []
for t in sorted(HERE.glob("test_*.py")):
    r = subprocess.run([sys.executable, str(t)], capture_output=True, text=True, timeout=240)
    ok = r.returncode == 0
    print(("[ OK ]" if ok else "[HATA]"), t.name)
    if not ok:
        failed.append(t.name)
        print((r.stdout[-1200:] + r.stderr[-2000:]).strip(), "\n")
print("\nSonuç:", "hepsi geçti" if not failed else f"{len(failed)} test başarısız: {', '.join(failed)}")
sys.exit(1 if failed else 0)
