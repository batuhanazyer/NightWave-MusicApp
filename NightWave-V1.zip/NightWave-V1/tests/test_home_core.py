"""Ana sayfa çekirdeği: türler, raf süzme, önbellek, arama geçmişi, aramaya göre öneri."""
import pathlib, sys, tempfile, time, types
HERE = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
sys.modules.setdefault("yt_dlp", types.ModuleType("yt_dlp")); sys.modules["yt_dlp"].YoutubeDL = object
from core import home, recommend, youtube
from core.history import History
from core.models import Track

def T(i, title="Şarkı", dur=200, **k): return Track(id=f"{i:011d}", title=title, artist="A", duration=dur, source="youtube", **k)

# ---- selamlama / türler ----
assert [home.greeting(h) for h in (2, 8, 14, 21)] == ["İyi geceler", "Günaydın", "İyi günler", "İyi akşamlar"]
assert set(home.DEFAULT_GENRES) <= set(home.GENRE_MAP) and len(home.GENRES) >= 10
assert home.valid_genres(["lofi", "yok", "yeni"]) == ["lofi", "yeni"] and home.valid_genres([]) == home.DEFAULT_GENRES and home.valid_genres(None) == home.DEFAULT_GENRES

# ---- raf süzme ----
raw = [T(1, "Hit Song"), T(1, "Hit Song"), T(2, "Best Hits Playlist 2026"), T(3, "Lofi Mix 3 Hours"), T(4, "Uzun", 3600),
       T(5, "Çok kısa", 10), T(6, "Remix Bomb"), T(7, "Full Album Karaoke"), T(8, "Normal", 0)]
ids = [t.id for t in home.clean_shelf(raw)]
assert ids == [T(1).id, T(6).id, T(8).id], ids                       # tekrar/derleme/mix/uzun/kısa elendi; "Remix" kalır; süresi bilinmeyen kalır
assert len(home.clean_shelf([T(i, f"s{i}") for i in range(50)], limit=10)) == 10

# ---- önbellek ----
tmp = pathlib.Path(tempfile.mkdtemp()); hc = home.HomeCache(tmp / "h.json")
assert hc.get("x") is None and not hc.is_fresh("x")
hc.put("x", [T(1), T(2)]); got, ts = hc.get("x")
assert [t.id for t in got] == [T(1).id, T(2).id] and abs(ts - time.time()) < 5 and hc.is_fresh("x")
assert not hc.is_fresh("x", ttl=-1)
assert [t.id for t in home.HomeCache(tmp / "h.json").get("x")[0]] == [T(1).id, T(2).id]       # diskten yeniden yükleniyor
(tmp / "bad.json").write_text("{bozuk"); assert home.HomeCache(tmp / "bad.json").get("x") is None
(tmp / "bad2.json").write_text('{"x": {"tracks": 5}}'); assert home.HomeCache(tmp / "bad2.json").get("x") is None
hc.clear(); assert hc.get("x") is None
print("Ana sayfa çekirdeği OK")

# ---- arama geçmişi ----
h = History(tmp / "history.json")
for q in ["tarkan", "duman", "  Tarkan  ", "x", "sezen   aksu"]: h.add_search(q)
assert h.recent_searches(5) == ["Tarkan", "duman", "sezen aksu"][::-1][:0] or True
r = h.recent_searches(5); assert r == ["sezen aksu", "Tarkan", "duman"], r                      # yeniden aratma öne alır, tek harf yok sayılır
assert History(tmp / "history.json").recent_searches(2) == ["sezen aksu", "Tarkan"]             # kalıcı
for i in range(40): h.add_search(f"sorgu {i}")
assert len(h.recent_searches(100)) == 30
h.clear(); assert h.recent_searches() == [] and History(tmp / "history.json").recent_searches() == []
print("Arama geçmişi OK")

# ---- aramaya göre öneri ----
youtube.search = lambda q, limit=20: [T(1, "Seed Song")]
youtube.related = lambda vid, limit=25: [T(2, "Sim A"), T(3, "Best Of Playlist"), T(2, "Sim A"), T(4, "Sim B", 5000), T(5, "Sim C")]
out = recommend.from_query("tarkan şımarık", 10)
assert [t.id for t in out["tracks"]] == [T(1).id, T(2).id, T(5).id], [t.title for t in out["tracks"]]
assert out["reasons"][T(2).id] == "“tarkan şımarık” aramana göre"
youtube.search = lambda q, limit=20: []
assert recommend.from_query("yok") == {"tracks": [], "reasons": {}}
print("Aramaya göre öneri OK")
