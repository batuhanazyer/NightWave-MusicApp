"""Ana pencere akış testi (sahte Qt ile): arama, çalma, kuyruk, beğeni, çalma listesi, paylaşım,
indirme, öneri, tema, uyarı bandı, ayarlar. Gerçek Qt/ağ gerektirmez; yalnızca MANTIK hatalarını yakalar.

Çalıştırma:  python tests/test_ui_flows.py
"""
import os, sys, tempfile, traceback
from pathlib import Path
HERE = Path(__file__).resolve().parent
tmp = Path(tempfile.mkdtemp()); os.environ["APPDATA"] = str(tmp)
sys.path.insert(0, str(HERE / "fake_qt")); sys.path.insert(0, str(HERE.parent))
sys.modules["yt_dlp"] = type(sys)("yt_dlp"); sys.modules["yt_dlp"].YoutubeDL = object
sys.modules["spotipy"] = type(sys)("spotipy"); so = type(sys)("spotipy.oauth2"); so.SpotifyClientCredentials = object
sys.modules["spotipy.oauth2"] = so
import types; v = types.ModuleType("yt_dlp.version"); v.__version__ = "test"; sys.modules["yt_dlp.version"] = v

from core import config, youtube, recommend, health, network
network.is_online = lambda timeout=2.0: True
from core.models import Track
import ui.main_window as mw

fails = []
def step(name, fn):
    try: fn(); print("  ok  ", name)
    except Exception: fails.append(name); print("  FAIL", name); traceback.print_exc()

# --- ağ/disk dışı bağımlılıkları sahtele ---
T = lambda i, t, a="Art", d=200: Track(id=(i*11)[:11], title=t, artist=a, duration=d, source="youtube", url=f"https://www.youtube.com/watch?v={(i*11)[:11]}")
tracks = [T("a", "Tarkan - Simarik"), T("b", "Tarkan - Kuzu Kuzu"), T("c", "Duman - Bulusamayiz")]
youtube.search = lambda q, limit=20: tracks
youtube.resolve_stream = lambda t, alt=False: "https://fake/stream.m4a"
youtube.related = lambda vid, limit=25: [T("x", "Sim 1"), T("y", "Sim 2")]
def fake_fetch(track, cache, progress=None, cancelled=None, stage=None):
    if stage: stage("Hazırlanıyor… %50")
    cache.dir.mkdir(parents=True, exist_ok=True)
    f = cache.dir / (cache.base_name(track.id) + ".m4a"); f.write_bytes(b"audio"); return f
youtube.fetch_audio = fake_fetch
def fake_prog(track, cache, on_ready, stage=None, cancelled=None, start_bytes=0):      # indirirken çal: erken hazır, sonra tamam
    on_ready("http://127.0.0.1:1/s/bbbbbbbbbbbbbbbb.m4a")
    return fake_fetch(track, cache)
youtube.fetch_progressive = fake_prog
class FakeMode:                                                    # QComboBox yerine: her metodu kabul eder
    def currentIndex(self): return 0
    def __getattr__(self, n): return lambda *a, **k: None
def fake_download(track, dest, progress=None):
    if progress: progress(50); progress(100)
    p = Path(dest) / f"{track.title}.mp3"; Path(dest).mkdir(parents=True, exist_ok=True); p.write_text("x"); return p
youtube.download = fake_download
mw.youtube = youtube
class FakeDlg:
    result = {"name": "Yolculuk", "description": "d", "emoji": "🚗", "color": "#112233", "cover_src": None}
    def __init__(self, *a, **k): pass
    def exec(self): return mw.QDialog.DialogCode.Accepted
    def values(self): return dict(self.result)
mw.PlaylistDialog = FakeDlg
class FakeInput:
    code = ""
    @staticmethod
    def getMultiLineText(*a, **k): return FakeInput.code, True
mw.QInputDialog = FakeInput
mw.QMessageBox.question = staticmethod(lambda *a, **k: mw.QMessageBox.StandardButton.Yes)

cfg = config.load(); cfg["download_dir"] = str(tmp / "music")
win = mw.MainWindow(cfg)
p = win.player

class Edit:                                         # arama kutusu yerine gerçek metin
    def __init__(s, t=""): s.t = t
    def text(s): return s.t
    def clear(s): s.t = ""
    def __getattr__(s, n): return lambda *a, **k: None
win.search_edit = Edit("tarkan")

def t_views():
    for show in (win.show_discover, win.show_library, win.show_queue, win.show_liked, win.show_foryou):
        show()
step("görünümler açılıyor", t_views)

def t_search():
    win.show_discover(); win.search_edit = Edit("tarkan"); win.mode_box = FakeMode()
    win.do_search(); assert [t.id for t in win.shown] == [t.id for t in tracks], win.shown
step("arama -> sonuç tablosu", t_search)

def t_play():
    win._on_row_activated(0)
    assert p.current_track().id == tracks[0].id and len(p.queue) == 3
    p.next(); assert p.current_track().id == tracks[1].id
    p.prev(); assert p.current_track().id == tracks[0].id or p.current_track().id == tracks[2].id
    p.toggle_shuffle(); assert p.shuffle and sorted(p.order.items) == [0, 1, 2]
    p.cycle_repeat(); assert p.repeat == "all"; p.cycle_repeat(); assert p.repeat == "one"; p.cycle_repeat(); assert p.repeat == "off"
    p.set_modes(False, "off")
step("çalma / sonraki / önceki / karışık / tekrar", t_play)

def t_queue():
    p.set_queue(tracks, 0, shuffle=False); p.enqueue(T("q", "Sonra"), play_next=True)
    assert [t.title for t in p.queue_tracks()][:2] == ["Tarkan - Simarik", "Sonra"]
    win.show_queue(); assert len(win.shown) == 4
    p.jump(1); assert p.current_track().title == "Sonra"
    p.next(auto=True); assert p.current_track().title == "Tarkan - Kuzu Kuzu"
step("kuyruk: sıradaki çal / atla", t_queue)

def t_history_like():
    win._finalize_play()
    p.set_queue(tracks, 0); win._on_position(120_000); win._on_duration(200_000)
    p.next()                                         # parça değişince önceki parça geçmişe işlenir
    assert win.history.total_plays() >= 1, win.history.entries()
    win._toggle_like(tracks[0]); assert win.history.is_liked(tracks[0].id)
    win.show_liked(); assert [t.id for t in win.shown] == [tracks[0].id]
    win._toggle_like(tracks[0]); assert not win.history.is_liked(tracks[0].id)
step("dinleme geçmişi + beğeni", t_history_like)

def t_playlists():
    win._new_playlist([tracks[0]])
    pl = win.playlists.all()[0]; assert pl.name == "Yolculuk" and len(pl.tracks) == 1 and win.view == "playlist"
    win._add_to_playlist(pl.id, tracks[1:]); assert len(win.playlists.get(pl.id).tracks) == 3
    win._move_in_playlist(0, +1)
    win._remove_from_playlist(tracks[2]); assert len(win.playlists.get(pl.id).tracks) == 2
    win._play_playlist(pl.id); assert len(p.queue) == 2
    win._play_playlist(pl.id, shuffle=True); assert p.shuffle
    win.current_pl = pl.id; win._on_sort_changed(1); assert win.playlists.get(pl.id).sort == "title"
    win._share_copy(pl.id)
    win._edit_playlist(pl.id)
    win._delete_playlist(pl.id); assert win.playlists.all() == []
step("çalma listesi: oluştur/ekle/taşı/kaldır/çal/sırala/paylaş/sil", t_playlists)

def t_import():
    pl = win.playlists.create("K"); win.playlists.add_tracks(pl.id, tracks)
    from core import playlists as pls
    code, _ = pls.to_share_code(pl, win.playlists.tracks(pl.id))
    FakeInput.code = code; before = len(win.playlists.all()); win._import_code()
    assert len(win.playlists.all()) == before + 1 and win.view == "playlist"
    FakeInput.code = "NW1:bozuk"; mw.QMessageBox.warning = staticmethod(lambda *a, **k: None); win._import_code()
step("paylaşım kodundan içe aktarma (+ bozuk kod)", t_import)

def t_download():
    class Btn:
        def __init__(s): s.txt = ""; s.en = True
        def setText(s, t): s.txt = t
        def setEnabled(s, e): s.en = e
    b = Btn(); win.online = True; win.force_offline = False
    win.download_track(tracks[0], b)
    assert tracks[0].local_path and win.library.is_downloaded(tracks[0].id) and b.txt == "✓ İndirildi", b.txt
    p.set_queue([tracks[0]], 0)                      # indirilen parça yerelden çalınmalı
step("indirme + yerelden çalma", t_download)

def t_library():
    win.show_library(); assert len(win.shown) == 1
    win.delete_track(win.shown[0]); assert win.library.all() == []
step("kütüphane: listele/sil", t_library)

def t_recs():
    from core import history
    for i, tr in enumerate(tracks):
        win.history.record(tr, 200_000, 200_000); win.history.record(tr, 200_000, 200_000)
    out = recommend.build(win.history.entries(), 10)
    assert out["tracks"] and out["reasons"] and out["taste"], out
    win.view = "foryou"; win._on_recs(out); assert win.shown and win._rec_taste
    win._start_radio(tracks[0]); assert p.current_track().id == tracks[0].id and len(p.queue) == 3
step("öneri motoru + 'Sana özel' + radyo", t_recs)

def t_theme():
    win.cfg["theme"] = "light"; win.apply_theme(); win.cfg["theme"] = "auto"; win.apply_theme()
    win.cfg["custom_themes"] = {"custom:1": {"name": "x", "bg": "#101820", "panel": "#182430", "text": "#FFE9D6"}}
    win.cfg["theme"] = "custom:1"; win.apply_theme(); assert win.pal["bg"] == "#101820"
    win.cfg["dynamic_accent"] = True; win._dyn_accent = "#FF0000"; win.apply_theme(); assert win.pal["accent"] == "#FF0000"
step("tema: açık/sistem/özel/dinamik vurgu", t_theme)

def t_misc():
    win._on_playing_changed(True); win._on_modes_changed(True, "one"); win._on_volume(30); win._on_player_status("x")
    win.set_status("⚠ hata"); win.set_status("")
    win._on_health = getattr(win, "_on_health", None)
    win._refresh_mode_ui(); win._set_online(False); assert win.is_offline; win._set_online(True)
    win._place_mini = lambda: None
    win.switch_to_mini(); win.switch_to_main(); win.toggle_mini()
    win.quit_app()
step("çeşitli: durum/çevrimdışı/mini/çıkış", t_misc)


def t_banner():
    win._on_health([health.Check("js", False, "JavaScript çalışma zamanı", "eksik", "winget install DenoLand.Deno", "error"),
                    health.Check("ffmpeg", False, "FFmpeg", "eksik", "winget install Gyan.FFmpeg", "warn")])
    assert win._banner_fix == "winget install DenoLand.Deno"            # ciddi olan önce
    win._dismiss_banner(); assert win._banner_dismissed
    win._on_health([])
step("uyarı bandı: ciddi sorun önce / kapatma", t_banner)

def t_settings_dialog():
    from ui.settings_dialog import SettingsDialog
    d = SettingsDialog(win.cfg, "SMTC", True, 3, health.run_checks(), 3, None)
    d._recheck(); d.values()
step("ayarlar penceresi: Sistem sekmesi kuruluyor", t_settings_dialog)

def t_friendly_status():
    class Lbl:
        def setText(s, t): s.t = t
        def setStyleSheet(s, css): s.css = css
    lbl = Lbl(); real = win.status_label; win.status_label = lbl
    def boom(q, limit=20): raise RuntimeError("ERROR: [youtube] x: Requested format is not available")
    youtube.search = boom; win.view = "discover"; win.search_edit = Edit("x"); win.online = True
    win.mode_box = FakeMode()
    win.do_search()
    assert "Deno" in lbl.t and lbl.css, (getattr(lbl, "t", None), getattr(lbl, "css", None))
    win.set_status("normal"); assert lbl.css == ""
    win.status_label = real
step("hata -> anlaşılır Türkçe mesaj + kırmızı vurgu", t_friendly_status)


def t_now_view():
    win.mode_box = mw.QComboBox()                      # önceki adımın sahtesini temizle
    win.show_now(); assert win.view == "now"
    win.player.set_queue(tracks, 0); win.show_now()
    win.toggle_fullscreen(); win.toggle_fullscreen()
    class Ev:
        def __init__(s, k): s.k = k
        def key(s): return s.k
        def ignore(s): pass
    win.keyPressEvent(Ev(mw.Qt.Key.Key_F11)); win.keyPressEvent(Ev(mw.Qt.Key.Key_Escape)); win.keyPressEvent(Ev(mw.Qt.Key.Key_A))
    win._save_cfg(); win.show_discover(); assert win.view == "discover"
step("Çalıyor ekranı: açma / tam ekran / kısayollar", t_now_view)


youtube.search = lambda q, limit=20: tracks          # hata testinin bozduğu aramayı geri yükle

def t_single_click_and_cache_play():
    win.mode_box = FakeMode(); win.view = "discover"; win._discover_mode = "results"
    win.populate(tracks); p.cache.clear(); calls = []
    win._on_row_clicked(0)                                                   # TEK tıkla çalar
    cur = p.current_track(); assert cur.id == tracks[0].id
    assert win.cache.path_for(tracks[0].id), "şarkı önbelleğe indirilip yerelden çalmalıydı"
    real_toggle, p.toggle = p.toggle, lambda: calls.append("toggle")
    win._on_row_clicked(0); assert calls == ["toggle"] and p.current_track().id == tracks[0].id    # aynı şarkıya tıkla: duraklat/devam
    p.toggle = real_toggle
    win._on_row_clicked(2); assert p.current_track().id == tracks[2].id      # başka satır: onu çal
    win._on_row_clicked(99)                                                  # geçersiz satır: sessizce yok sayılır
step("tek tıkla çal + önbellekten çalma + aynı şarkıya tıkla = duraklat", t_single_click_and_cache_play)

def t_home_shelves():
    win.cfg["home_genres"] = ["turkce_pop", "lofi"]; win.cfg["personalize"] = True
    win.home_cache.clear(); win._home_pending = 0
    win.show_discover(); assert win.view == "discover" and win._discover_mode == "home"
    keys = win.home_view.keys()
    assert "g:turkce_pop" in keys and "g:lofi" in keys and "g:global" not in keys, keys       # seçili türler raf oldu
    assert win.home_cache.get("g:lofi") and win._shelf_data["g:lofi"][0] == "Rahatlatıcı · Lo-fi"
    win.cfg["home_genres"] = ["rock"]; win._home_pending = 0; win._load_home()
    keys = win.home_view.keys(); assert "g:rock" in keys and "g:lofi" not in keys, keys      # tür değişince raflar güncellenir
step("ana sayfa: tür rafları (arama yapmadan) + tür seçimi değişince", t_home_shelves)

def t_home_personal():
    win.cfg["home_genres"] = ["lofi"]
    for tr in tracks:
        win.history.record(tr, 200_000, 200_000); win.history.record(tr, 200_000, 200_000)
    win.history.add_search("tarkan şımarık"); win.history.add_search("duman")
    win._home_pending = 0; win._load_home(force=True)
    keys = win.home_view.keys()
    assert keys[0] == "foryou" and "q0" in keys and "q1" in keys and "recent" in keys, keys   # kişisel raflar en üstte, sırayla
    assert keys.index("foryou") < keys.index("q0") < keys.index("recent") < keys.index("g:lofi"), keys
    assert win._shelf_data["q0"][0] == "“duman” aramana göre"                                   # son arama en üstte
    win.cfg["personalize"] = False; win._home_pending = 0; win._load_home()
    assert "recent" not in win.home_view.keys()                                                # kişiselleştirme kapalı: geçmiş rafı yok
    win.cfg["personalize"] = True
step("ana sayfa: kişisel raflar (Sana özel + aramalara göre + geçmiş)", t_home_personal)

def t_home_actions():
    calls = []; real = p.toggle; p.toggle = lambda: calls.append(1)
    win._on_home_play(tracks, 1); assert p.current_track().id == tracks[1].id and not calls      # karta tıkla: raf kuyruğuyla çal
    win._on_home_play(tracks, 1); assert calls == [1]                                           # çalan karta tekrar: duraklat
    p.toggle = real
    win._on_card_menu(tracks[0], None)                                                          # kart sağ tık menüsü
    win._on_shelf_more("g:lofi") if "g:lofi" in win._shelf_data else win._on_shelf_more("g:rock")
    assert win.view == "collection" and win.shown, win.view
    win._on_shelf_more("foryou"); assert win.view == "foryou"
step("ana sayfa: kart tıklama / menü / 'tümünü gör'", t_home_actions)

def t_search_flow():
    win.mode_box = FakeMode(); win.online = True; win.force_offline = False
    youtube.search = lambda q, limit=20: tracks
    win.show_discover(); win.search_edit = Edit("sezen aksu"); win.do_search()
    assert win._discover_mode == "results" and "sezen aksu" in win.history.recent_searches(3)    # arama kaydedilir (öneriler için)
    win.search_edit = Edit(""); win.do_search(); assert win._discover_mode == "home"             # boş arama: ana sayfaya dön
    win.search_edit = Edit("duman"); win.do_search(); win.show_now(); win.close_now()
    assert win.view == "discover" and win._discover_mode == "results"                            # Çalıyor'dan sonuçlara dön
step("arama: sonuç modu / geçmişe kayıt / boş arama = ana sayfa", t_search_flow)

def t_now_from_bar():
    win.show_discover(); assert win.view == "discover"
    win.toggle_now(); assert win.view == "now"                                                   # alt çubuğa tıkla: görselleştirici
    win.toggle_now(); assert win.view == "discover"                                              # tekrar tıkla: geri
    win.show_library(); win.toggle_now(); win.close_now(); assert win.view == "library"          # önceki görünüme döner
    pl = win.playlists.create("X"); win.show_playlist(pl.id); win.toggle_now(); win.close_now()
    assert win.view == "playlist" and win.current_pl == pl.id
    win.show_queue(); win.show_now(); win.keyPressEvent(type("E", (), {"key": lambda s: mw.Qt.Key.Key_Escape, "ignore": lambda s: None})())
step("alt çubuktan Çalıyor: aç/kapat, önceki görünüme dönüş, Esc", t_now_from_bar)

def t_offline_home():
    win.cfg["home_genres"] = ["lofi"]; win.show_discover()
    before = win.home_view.keys()
    win._set_online(False); assert win.is_offline and win.view == "discover"                    # çevrimdışıyken ana sayfa açık kalır
    assert win.home_view.keys() == before and "g:lofi" in win.home_view.keys()                  # önbellekteki raflar görünür
    win.show_discover(); win.search_edit = Edit("x"); win.do_search(); assert win._discover_mode == "home"   # çevrimdışı arama yapılmaz
    win._set_online(True)
step("çevrimdışı: ana sayfa önbellekten dolu kalır, arama engellenir", t_offline_home)

def t_settings_apply():
    win.cfg.update({"play_mode": "stream", "prefetch": False, "cache_mb": 200})
    win.player.play_mode = win.cfg["play_mode"]; win.player.prefetch = win.cfg["prefetch"]
    win.cache.max_bytes = win.cfg["cache_mb"] * 1024 * 1024
    assert win.cache.max_bytes == 200 * 1024 * 1024 and win.player.play_mode == "stream"
    from ui.settings_dialog import SettingsDialog
    d = SettingsDialog(win.cfg, "SMTC", True, 3, health.run_checks(), 2, None, cache_used_mb=12); d.values(); d._on_clear_cache()
    assert d.clear_cache_requested()
    win.player.play_mode = "cache"
step("ayarlar: Müzik sekmesi / oynatma yöntemi / önbellek", t_settings_apply)


def t_hover_prefetch():
    win.online = True; win.force_offline = False; win.mode_box = FakeMode()
    p.cache.clear(); p._inflight.clear(); p.prefetch = True; p.play_mode = "cache"
    win._on_hover_track(tracks[1]); assert win._hover_track is tracks[1]
    win._hover_fire(); assert win.cache.path_for(tracks[1].id), "üstüne gelinen şarkı arka planda hazırlanmalıydı"
    win._on_hover_track(None); assert win._hover_track is None
    win.populate(tracks); win._on_row_hover(2); assert win._hover_track.id == tracks[2].id; win._on_row_hover(99)
    p.cache.clear(); win._set_online(False); win._on_hover_track(tracks[0]); win._hover_fire()
    assert win.cache.path_for(tracks[0].id) is None                          # çevrimdışı: hazırlama yok
    win._set_online(True)
step("fare üstüne gelince önceden hazırlama (+ çevrimdışıyken yok)", t_hover_prefetch)

def t_raw_failed_and_progressive_settings():
    win._on_raw_failed(); assert win.cfg["raw_ok"] is False and config.load()["raw_ok"] is False      # kalıcı kaydedildi
    win.cfg["raw_ok"] = True; config.save(win.cfg)
    from ui.settings_dialog import SettingsDialog
    v = SettingsDialog(win.cfg, "SMTC", True, 0, [], 0, None, cache_used_mb=0).values()
    assert "progressive" in v and "force_ipv4" in v and "play_mode" in v
    win.player.progressive = False; win.player.progressive = True
step("ham ses yedeği kaydı + yeni ayarlar", t_raw_failed_and_progressive_settings)

def t_mini_visualizer():
    m = win.mini; assert m.viz is not None
    m.apply_viz_settings({"viz_style": "circle", "viz_color": "rainbow", "viz_gain": 150})
    assert m.viz.viz_style == "bars" and m.viz.color_mode == "rainbow" and abs(m.viz.gain - 1.5) < 1e-9      # dairesel küçük ekrana sığmaz
    m.apply_viz_settings({"viz_style": "wave"}); assert m.viz.viz_style == "wave"
    win.cfg.update({"viz_style": "mirror"}); win.switch_to_mini(); assert m.viz.viz_style == "mirror"; win.switch_to_main()
    m.apply_palette(win.pal)
step("küçük ekran görselleştirici: ayar aktarımı", t_mini_visualizer)

print("\nBAŞARISIZ:", fails if fails else "yok")
sys.exit(1 if fails else 0)
