from PyQt6._stub import *
from PyQt6._stub import module_getattr as __getattr__
