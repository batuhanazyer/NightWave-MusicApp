"""Sahte Qt: her sınıf/öznitelik çalışır, sinyaller eşzamanlı çalışır. Sadece mantık hatalarını yakalamak içindir."""
class _Meta(type):
    def __getattr__(cls, name):
        if name.startswith("__"): raise AttributeError(name)
        sub = _Meta(name, (Stub,), {})          # Qt.AlignmentFlag.AlignTop gibi zincirler
        setattr(cls, name, sub)                 # kimlik sabit kalsın
        return sub
    def __or__(cls, other): return cls
    def __ror__(cls, other): return cls
    def __iter__(cls): return iter(())

class Stub(metaclass=_Meta):
    def __init__(self, *a, **k): pass
    def __getattr__(self, name):
        if name.startswith("__"): raise AttributeError(name)
        return Stub()
    def __call__(self, *a, **k): return Stub()
    def keyPressEvent(self, *a, **k): return None
    def showEvent(self, *a, **k): return None
    def hideEvent(self, *a, **k): return None
    def closeEvent(self, *a, **k): return None
    def moveEvent(self, *a, **k): return None
    def paintEvent(self, *a, **k): return None
    def mousePressEvent(self, *a, **k): return None
    def mouseReleaseEvent(self, *a, **k): return None
    def mouseDoubleClickEvent(self, *a, **k): return None
    def changeEvent(self, *a, **k): return None
    def resizeEvent(self, *a, **k): return None
    def count(self): return 0          # 'while layout.count()' döngüleri sonsuza gitmesin
    def __or__(self, o): return self
    def __ror__(self, o): return self
    def __iter__(self): return iter(())
    def __bool__(self): return True
    def __int__(self): return 0
    def __index__(self): return 0
    def __float__(self): return 0.0
    def __len__(self): return 0
    def __enter__(self): return self
    def __exit__(self, *a): return False
    def __eq__(self, o): return self is o
    def __gt__(self, o): return False
    def __add__(self, o): return 0.0
    def __radd__(self, o): return 0.0
    def __sub__(self, o): return 0.0
    def __rsub__(self, o): return 0.0
    def __mul__(self, o): return 0.0
    def __rmul__(self, o): return 0.0
    def __truediv__(self, o): return 0.0
    def __rtruediv__(self, o): return 0.0
    def __floordiv__(self, o): return 0.0
    def __neg__(self): return 0.0
    def __lt__(self, o): return False
    def __ge__(self, o): return False
    def __le__(self, o): return False
    def __hash__(self): return id(self)

class _Bound:
    def __init__(self): self.slots = []
    def connect(self, f, *a): self.slots.append(f)
    def disconnect(self, *a): pass
    def emit(self, *args):
        for f in list(self.slots):
            try: f(*args)
            except TypeError:
                f()
class pyqtSignal:
    def __init__(self, *types): self.name = None
    def __set_name__(self, owner, name): self.name = name
    def __get__(self, obj, objtype=None):
        if obj is None: return self
        return obj.__dict__.setdefault("_sigs", {}).setdefault(self.name, _Bound())

class QThreadPool(Stub):
    @staticmethod
    def globalInstance():
        class _P:
            def start(self, w): w.run()          # iş parçacığı yok: eşzamanlı çalıştır
        return _P()

class QRunnable(Stub):
    pass

class QObject(Stub):
    pass

def module_getattr(name):
    if name.startswith("__"): raise AttributeError(name)
    return _Meta(name, (Stub,), {})
