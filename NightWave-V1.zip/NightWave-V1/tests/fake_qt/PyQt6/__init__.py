from PyQt6._stub import *
