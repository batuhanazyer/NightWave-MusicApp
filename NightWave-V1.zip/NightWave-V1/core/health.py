"""Sistem sağlık kontrolü: uygulamanın çalışması için gereken harici programları bulur.

Önemli: winget ile kurulan programlar çoğu zaman o an açık olan terminalin PATH'ine
girmez. Bu yüzden `shutil.which`'in yanında bilinen kurulum klasörlerine de bakıyoruz;
böylece "kurdum ama bulamıyor" sorunu yaşanmaz.
"""
import glob
import importlib.util
import os
import shutil
import sys
from dataclasses import dataclass
from pathlib import Path

# yt-dlp'nin tanıdığı çalışma zamanı adı -> çalıştırılabilir dosya adı
JS_RUNTIME_BINARIES = {"deno": "deno", "node": "node", "bun": "bun", "quickjs": "qjs"}

FIX_DENO = "winget install DenoLand.Deno"
FIX_FFMPEG = "winget install Gyan.FFmpeg"
FIX_YTDLP = 'pip install -U "yt-dlp[default]"'


def _exe(name: str) -> str:
    return name + (".exe" if sys.platform == "win32" else "")


def _candidate_dirs() -> list[Path]:
    home = Path.home()
    local = Path(os.environ.get("LOCALAPPDATA", home / "AppData" / "Local"))
    prog = Path(os.environ.get("ProgramFiles", r"C:\Program Files"))
    choco = Path(os.environ.get("ChocolateyInstall", r"C:\ProgramData\chocolatey"))
    return [
        local / "Microsoft" / "WinGet" / "Links",
        home / ".deno" / "bin",
        prog / "nodejs",
        prog / "deno",
        home / "scoop" / "shims",
        choco / "bin",
        Path(r"C:\ffmpeg\bin"),
    ]


def _find(name: str) -> str | None:
    found = shutil.which(name)
    if found:
        return found
    for d in _candidate_dirs():
        f = d / _exe(name)
        if f.exists():
            return str(f)
    return None


def find_ffmpeg() -> str | None:
    found = _find("ffmpeg")
    if found:
        return found
    # winget'in Gyan.FFmpeg paketi: ...\Packages\Gyan.FFmpeg_*\ffmpeg-*\bin\ffmpeg.exe
    local = Path(os.environ.get("LOCALAPPDATA", Path.home() / "AppData" / "Local"))
    pattern = str(local / "Microsoft" / "WinGet" / "Packages" / "Gyan.FFmpeg*" /
                  "ffmpeg-*" / "bin" / _exe("ffmpeg"))
    hits = sorted(glob.glob(pattern))
    return hits[-1] if hits else None


def find_js_runtimes() -> dict[str, str]:
    """Bulunan JavaScript çalışma zamanları: {"deno": "C:\\...\\deno.exe", ...} (Deno başta)."""
    out = {}
    for name, binary in JS_RUNTIME_BINARIES.items():
        path = _find(binary)
        if path:
            out[name] = path
    return out


@dataclass
class Check:
    key: str
    ok: bool
    title: str
    detail: str
    fix: str = ""            # kopyalanabilir kurulum komutu
    severity: str = "info"   # error: çalma bozulur | warn: bir özellik bozulur | info


def run_checks() -> list[Check]:
    checks: list[Check] = []

    # yt-dlp
    try:
        from yt_dlp.version import __version__ as ver
        checks.append(Check("ytdlp", True, "yt-dlp", f"Sürüm {ver}"))
    except Exception as exc:  # noqa: BLE001
        checks.append(Check("ytdlp", False, "yt-dlp", f"Yüklenemedi: {exc}", FIX_YTDLP, "error"))

    # JavaScript çalışma zamanı (YouTube'dan çalmak için şart)
    js = find_js_runtimes()
    if js:
        first = next(iter(js))
        checks.append(Check("js", True, "JavaScript çalışma zamanı", f"{first}: {js[first]}"))
    else:
        checks.append(Check(
            "js", False, "JavaScript çalışma zamanı",
            "Bulunamadı. YouTube'dan çalmak ve indirmek için Deno gerekli. "
            "Kurduktan sonra uygulamayı yeniden başlatın.", FIX_DENO, "error"))

    # EJS çözücü betikleri (yt-dlp[default] ile gelir)
    if importlib.util.find_spec("yt_dlp_ejs") is not None:
        checks.append(Check("ejs", True, "yt-dlp-ejs", "Kurulu"))
    else:
        checks.append(Check("ejs", False, "yt-dlp-ejs",
                            "Eksik. YouTube çözücü betikleri bulunamadı.", FIX_YTDLP, "error"))

    # FFmpeg (yalnızca MP3 indirme için)
    ff = find_ffmpeg()
    if ff:
        checks.append(Check("ffmpeg", True, "FFmpeg", ff))
    else:
        checks.append(Check("ffmpeg", False, "FFmpeg",
                            "Bulunamadı. Şarkı indirme (MP3) için gerekli; çalma etkilenmez. "
                            "Kurduktan sonra uygulamayı yeniden başlatın.", FIX_FFMPEG, "warn"))

    # numpy (müzik görselleştirici için gerçek ses analizi)
    if importlib.util.find_spec("numpy") is not None:
        checks.append(Check("numpy", True, "numpy", "Kurulu (görselleştirici gerçek sesi analiz eder)"))
    else:
        checks.append(Check("numpy", False, "numpy",
                            "Eksik. Görselleştirici gerçek sesi analiz edemez, simülasyonla çalışır.",
                            "pip install numpy", "info"))

    # Python sürümü
    v = sys.version_info
    if v < (3, 11):
        checks.append(Check("python", False, "Python sürümü",
                            f"Python {v.major}.{v.minor}: çalışıyor, ama yt-dlp bu sürümü yakında "
                            "desteklemeyi bırakacak. Python 3.11 veya üstü önerilir.", "", "info"))
    else:
        checks.append(Check("python", True, "Python sürümü", f"{v.major}.{v.minor}.{v.micro}"))
    return checks


def problems(checks: list[Check]) -> list[Check]:
    """Kullanıcıya gösterilmesi gereken sorunlar (önce ciddi olanlar)."""
    bad = [c for c in checks if not c.ok and c.severity in ("error", "warn")]
    return sorted(bad, key=lambda c: c.severity != "error")
