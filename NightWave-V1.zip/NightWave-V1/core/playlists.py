"""Çalma listeleri: oluşturma, özelleştirme, sıralama, içe/dışa aktarma ve paylaşım.

Paylaşım yalnızca PARÇA BİLGİSİNİ içerir (başlık, sanatçı, YouTube/Spotify kimliği).
Ses dosyaları paylaşılmaz; alan kişi parçaları kendi uygulamasında stream eder.

Güvenlik: Dışarıdan gelen veri asla olduğu gibi kullanılmaz. `clean_track` her parçayı
doğrular; YouTube bağlantısı kimlikten yeniden üretilir, kapak adresleri yalnızca
bilinen görsel sunucularına izin verir, yerel dosya yolları atılır.
"""
import base64
import json
import re
import time
import uuid
import zlib
from dataclasses import dataclass, field
from pathlib import Path
from urllib.parse import urlparse

from .models import Track

SHARE_PREFIX = "NW1:"
MAX_TRACKS = 2000
MAX_JSON_BYTES = 5 * 1024 * 1024
SORTS = ("manual", "title", "artist", "added")

_YT_ID = re.compile(r"^[A-Za-z0-9_-]{11}$")
_SP_ID = re.compile(r"^sp:[A-Za-z0-9]{10,32}$")
_COLOR = re.compile(r"^#[0-9A-Fa-f]{6}$")
_THUMB_HOSTS = ("ytimg.com", "scdn.co", "ggpht.com", "googleusercontent.com")


@dataclass
class Playlist:
    id: str
    name: str
    description: str = ""
    color: str = "#8B7CFF"
    emoji: str = "🎵"
    cover_path: str = ""
    sort: str = "manual"
    created: float = 0.0
    tracks: list = field(default_factory=list)   # Track sözlükleri (+ "added" zamanı)

    def to_dict(self) -> dict:
        return {
            "id": self.id, "name": self.name, "description": self.description,
            "color": self.color, "emoji": self.emoji, "cover_path": self.cover_path,
            "sort": self.sort, "created": self.created, "tracks": self.tracks,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "Playlist":
        return cls(
            id=str(d.get("id") or uuid.uuid4().hex),
            name=str(d.get("name") or "Adsız liste"),
            description=str(d.get("description") or ""),
            color=d.get("color") if _COLOR.match(str(d.get("color", ""))) else "#8B7CFF",
            emoji=str(d.get("emoji") or "🎵"),
            cover_path=str(d.get("cover_path") or ""),
            sort=d.get("sort") if d.get("sort") in SORTS else "manual",
            created=float(d.get("created") or 0),
            tracks=[t for t in d.get("tracks", []) if isinstance(t, dict)],
        )


# =========================================================================
# Doğrulama / temizleme (dışarıdan gelen verilere asla güvenme)
# =========================================================================
def _safe_thumb(url: str) -> bool:
    try:
        u = urlparse(url)
    except ValueError:
        return False
    host = (u.hostname or "").lower()
    return u.scheme == "https" and any(host == h or host.endswith("." + h) for h in _THUMB_HOSTS)


def clean_track(d) -> Track | None:
    """Paylaşımdan/dosyadan gelen bir parçayı doğrular. Geçersizse None döner."""
    if not isinstance(d, dict):
        return None
    title = str(d.get("title", "")).strip()[:200]
    artist = str(d.get("artist", "")).strip()[:200]
    tid = str(d.get("id", ""))
    source = d.get("source")
    if not title:
        return None
    try:
        duration = max(0, min(int(d.get("duration", 0)), 24 * 3600))
    except (TypeError, ValueError):
        duration = 0

    if source == "youtube" and _YT_ID.match(tid):
        return Track(
            id=tid, title=title, artist=artist, duration=duration, source="youtube",
            url=f"https://www.youtube.com/watch?v={tid}",          # gelen URL'yi yok say
            thumbnail=f"https://i.ytimg.com/vi/{tid}/mqdefault.jpg",
        )
    if source == "spotify" and _SP_ID.match(tid):
        thumb = str(d.get("thumbnail", ""))
        return Track(
            id=tid, title=title, artist=artist, duration=duration, source="spotify",
            thumbnail=thumb if _safe_thumb(thumb) else "",
            query=str(d.get("query") or f"{artist} - {title}")[:300],
        )
    return None  # yerel dosyalar ve bilinmeyen kaynaklar paylaşılamaz


def _share_dict(t: Track) -> dict:
    d = {"id": t.id, "title": t.title, "artist": t.artist,
         "duration": t.duration, "source": t.source}
    if t.source == "spotify":
        d["query"] = t.query
        d["thumbnail"] = t.thumbnail
    return d


def _playlist_from_obj(obj) -> Playlist:
    if not isinstance(obj, dict):
        raise ValueError("Geçersiz çalma listesi verisi.")
    raw_tracks = obj.get("tracks")
    if not isinstance(raw_tracks, list):
        raise ValueError("Çalma listesinde parça bulunamadı.")
    now = time.time()
    tracks = []
    for raw in raw_tracks[:MAX_TRACKS]:
        t = clean_track(raw)
        if t:
            d = t.to_dict()
            d["added"] = now
            tracks.append(d)
    if not tracks:
        raise ValueError("Listede çalınabilir parça yok.")
    color = str(obj.get("color", ""))
    return Playlist(
        id=uuid.uuid4().hex,
        name=str(obj.get("name") or "İçe aktarılan liste").strip()[:80],
        description=str(obj.get("description") or "")[:300],
        color=color if _COLOR.match(color) else "#8B7CFF",
        emoji=(str(obj.get("emoji") or "🎵"))[:8],
        created=now,
        tracks=tracks,
    )


# =========================================================================
# Paylaşım: kod / dosya / M3U
# =========================================================================
def _export_obj(name, description, color, emoji, tracks: list[Track]):
    """(paylaşılabilir sözlük, atlanan parça sayısı)"""
    ok = [clean_track(t.to_dict()) for t in tracks]
    shared = [_share_dict(t) for t in ok if t]
    obj = {"format": "nightwave-playlist", "version": 1, "name": name,
           "description": description, "color": color, "emoji": emoji, "tracks": shared}
    return obj, len(tracks) - len(shared)


def to_share_code(pl: Playlist, tracks: list[Track]) -> tuple[str, int]:
    obj, skipped = _export_obj(pl.name, pl.description, pl.color, pl.emoji, tracks)
    raw = json.dumps(obj, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    code = base64.urlsafe_b64encode(zlib.compress(raw, 9)).decode("ascii")
    return SHARE_PREFIX + code, skipped


def from_share_code(code: str) -> Playlist:
    code = "".join(code.split())
    if code.startswith(SHARE_PREFIX):
        code = code[len(SHARE_PREFIX):]
    if not code:
        raise ValueError("Paylaşım kodu boş.")
    try:
        raw = base64.urlsafe_b64decode(code + "=" * (-len(code) % 4))
        dec = zlib.decompressobj()
        data = dec.decompress(raw, MAX_JSON_BYTES)       # "zip bombası" koruması
        if dec.unconsumed_tail:
            raise ValueError("Paylaşım kodu çok büyük.")
        obj = json.loads(data.decode("utf-8"))
    except (ValueError, zlib.error, UnicodeDecodeError) as exc:
        raise ValueError("Paylaşım kodu geçersiz ya da bozuk.") from exc
    return _playlist_from_obj(obj)


def export_file(pl: Playlist, tracks: list[Track], path: Path) -> int:
    obj, skipped = _export_obj(pl.name, pl.description, pl.color, pl.emoji, tracks)
    Path(path).write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")
    return skipped


def import_file(path: Path) -> Playlist:
    p = Path(path)
    if p.stat().st_size > MAX_JSON_BYTES:
        raise ValueError("Dosya çok büyük.")
    text = p.read_text(encoding="utf-8").strip()
    if text.startswith(SHARE_PREFIX):
        return from_share_code(text)
    try:
        return _playlist_from_obj(json.loads(text))
    except json.JSONDecodeError as exc:
        raise ValueError("Dosya geçerli bir NightWave çalma listesi değil.") from exc


def export_m3u(pl: Playlist, tracks: list[Track], path: Path) -> None:
    """Diğer oynatıcılarda açılabilen M3U8 listesi (indirilenler için yerel yol, diğerleri için bağlantı)."""
    lines = ["#EXTM3U", f"#PLAYLIST:{pl.name}"]
    for t in tracks:
        label = f"{t.artist} - {t.title}" if t.artist else t.title
        if t.local_path:
            target = t.local_path
        elif t.source == "spotify":
            target = f"https://open.spotify.com/track/{t.id[3:]}"
        else:
            target = t.url or f"https://www.youtube.com/watch?v={t.id}"
        lines += [f"#EXTINF:{t.duration or -1},{label}", target]
    Path(path).write_text("\n".join(lines) + "\n", encoding="utf-8")


# =========================================================================
# Depo
# =========================================================================
class PlaylistStore:
    def __init__(self, file: Path, cover_dir: Path):
        self.file = Path(file)
        self.cover_dir = Path(cover_dir)
        self.cover_dir.mkdir(parents=True, exist_ok=True)
        self._lists: dict[str, Playlist] = {}
        self._load()

    def _load(self):
        try:
            data = json.loads(self.file.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            data = []
        for d in data if isinstance(data, list) else []:
            if isinstance(d, dict):
                pl = Playlist.from_dict(d)
                self._lists[pl.id] = pl

    def save(self):
        payload = [pl.to_dict() for pl in self._lists.values()]
        self.file.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")

    # --- liste işlemleri -------------------------------------------------
    def all(self) -> list[Playlist]:
        return list(self._lists.values())

    def get(self, pid: str) -> Playlist | None:
        return self._lists.get(pid)

    def create(self, name: str, description: str = "", color: str = "#8B7CFF",
               emoji: str = "🎵") -> Playlist:
        pl = Playlist(id=uuid.uuid4().hex, name=name.strip() or "Yeni liste",
                      description=description, color=color, emoji=emoji or "🎵",
                      created=time.time())
        self._lists[pl.id] = pl
        self.save()
        return pl

    def add(self, pl: Playlist) -> Playlist:
        """Hazır (örn. içe aktarılmış) bir listeyi ekler."""
        self._lists[pl.id] = pl
        self.save()
        return pl

    def update(self, pid: str, **fields):
        pl = self._lists.get(pid)
        if not pl:
            return
        for k, v in fields.items():
            if hasattr(pl, k):
                setattr(pl, k, v)
        self.save()

    def delete(self, pid: str):
        pl = self._lists.pop(pid, None)
        if pl and pl.cover_path:
            try:
                Path(pl.cover_path).unlink(missing_ok=True)
            except OSError:
                pass
        self.save()

    # --- parça işlemleri -------------------------------------------------
    def add_tracks(self, pid: str, tracks: list[Track]) -> int:
        """Listede olmayan parçaları ekler; eklenen sayıyı döndürür."""
        pl = self._lists.get(pid)
        if not pl:
            return 0
        have = {t.get("id") for t in pl.tracks}
        added = 0
        now = time.time()
        for t in tracks:
            if t.id in have:
                continue
            d = t.to_dict()
            d["local_path"] = ""      # yol cihaza özel; çalarken kütüphaneden çözülür
            d["added"] = now
            pl.tracks.append(d)
            have.add(t.id)
            added += 1
        if added:
            self.save()
        return added

    def remove_track(self, pid: str, track_id: str):
        pl = self._lists.get(pid)
        if pl:
            pl.tracks = [t for t in pl.tracks if t.get("id") != track_id]
            self.save()

    def move_track(self, pid: str, row: int, delta: int):
        """Elle sıralı listede parçayı yukarı/aşağı taşır."""
        pl = self._lists.get(pid)
        if not pl or pl.sort != "manual":
            return
        new = row + delta
        if 0 <= row < len(pl.tracks) and 0 <= new < len(pl.tracks):
            pl.tracks[row], pl.tracks[new] = pl.tracks[new], pl.tracks[row]
            self.save()

    def tracks(self, pid: str) -> list[Track]:
        """Listenin parçaları, seçili sıralamaya göre."""
        pl = self._lists.get(pid)
        if not pl:
            return []
        items = list(pl.tracks)
        if pl.sort == "title":
            items.sort(key=lambda t: str(t.get("title", "")).lower())
        elif pl.sort == "artist":
            items.sort(key=lambda t: (str(t.get("artist", "")).lower(),
                                      str(t.get("title", "")).lower()))
        elif pl.sort == "added":
            items.sort(key=lambda t: t.get("added", 0))
        return [Track.from_dict(t) for t in items]
