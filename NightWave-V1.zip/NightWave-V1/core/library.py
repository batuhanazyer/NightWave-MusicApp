"""İndirilen şarkıların kütüphanesi (çevrimdışı mod bunu kullanır).

- İndirmeler library.json'da (başlık, sanatçı, kapak vb.) tutulur.
- İndirme klasörüne elle atılan ses dosyaları da otomatik listelenir.
"""
import json
import os
from pathlib import Path

from .models import Track

AUDIO_EXT = {".mp3", ".m4a", ".flac", ".wav", ".ogg", ".opus"}


class Library:
    def __init__(self, index_file: Path, music_dir: Path):
        self.index_file = index_file
        self.music_dir = music_dir
        self._items: dict[str, Track] = {}
        self._load()

    # --- dosya işlemleri -------------------------------------------------
    def _load(self) -> None:
        try:
            data = json.loads(self.index_file.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            data = []
        for d in data:
            t = Track.from_dict(d)
            self._items[t.id] = t

    def _save(self) -> None:
        payload = [t.to_dict() for t in self._items.values()]
        self.index_file.write_text(
            json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8"
        )

    # --- sorgular --------------------------------------------------------
    def path_for(self, track_id: str) -> str | None:
        t = self._items.get(track_id)
        if t and t.local_path and os.path.exists(t.local_path):
            return t.local_path
        return None

    def is_downloaded(self, track_id: str) -> bool:
        return self.path_for(track_id) is not None

    def all(self) -> list[Track]:
        """Diskte gerçekten bulunan tüm parçalar (indeksli + klasördeki yabancı dosyalar)."""
        tracks = [t for t in self._items.values()
                  if t.local_path and os.path.exists(t.local_path)]
        known = {os.path.normcase(t.local_path) for t in tracks}

        if self.music_dir.exists():
            for p in sorted(self.music_dir.iterdir()):
                if p.suffix.lower() in AUDIO_EXT and os.path.normcase(str(p)) not in known:
                    artist, _, title = p.stem.partition(" - ")
                    if not title:
                        artist, title = "", p.stem
                    tracks.append(Track(
                        id=f"local:{p.name}", title=title, artist=artist,
                        source="local", local_path=str(p),
                    ))
        return tracks

    # --- değişiklikler ---------------------------------------------------
    def add(self, track: Track) -> None:
        self._items[track.id] = track
        self._save()

    def remove(self, track: Track) -> None:
        """Dosyayı siler ve indeksten çıkarır (dosya kilitliyse OSError fırlatır)."""
        if track.local_path and os.path.exists(track.local_path):
            os.remove(track.local_path)
        if self._items.pop(track.id, None) is not None:
            self._save()
