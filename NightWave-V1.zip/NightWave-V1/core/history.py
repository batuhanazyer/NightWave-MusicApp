"""Dinleme geçmişi ve beğeniler. Tamamen YEREL: hiçbir yere gönderilmez.

Öneri motoru (recommend.py) bu verileri okur. Ayarlar > Genel'den kapatılabilir ve
tek tıkla silinebilir.

Sayım kuralları (Last.fm "scrobble" mantığına benzer):
  - 30 sn (ya da kısa parçalarda %50) dinlendiyse  -> "çalındı"
  - 10 sn dolmadan geçildiyse                      -> "atlandı"
  - arası sayılmaz
"""
import json
import time
from pathlib import Path

from .models import Track

MIN_PLAY_SECONDS = 30
SKIP_SECONDS = 10


class History:
    def __init__(self, file: Path):
        self.file = Path(file)
        self.searches_file = self.file.with_name("searches.json")
        self._d: dict[str, dict] = {}
        self._searches: list[dict] = []
        self._load()
        self._load_searches()

    # --- dosya -----------------------------------------------------------
    def _load(self):
        try:
            data = json.loads(self.file.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return
        for e in data if isinstance(data, list) else []:
            try:
                tid = e["track"]["id"]
                self._d[tid] = {
                    "track": e["track"], "plays": int(e.get("plays", 0)),
                    "skips": int(e.get("skips", 0)), "last": float(e.get("last", 0)),
                    "first": float(e.get("first", 0)), "liked": bool(e.get("liked", False)),
                    "liked_at": float(e.get("liked_at", 0)), "listened": float(e.get("listened", 0)),
                }
            except (KeyError, TypeError, ValueError):
                continue

    def _save(self):
        try:
            self.file.write_text(json.dumps(list(self._d.values()), ensure_ascii=False),
                                 encoding="utf-8")
        except OSError:
            pass

    def _entry(self, track: Track) -> dict:
        e = self._d.get(track.id)
        if e is None:
            data = track.to_dict()
            data["local_path"] = ""
            e = self._d[track.id] = {"track": data, "plays": 0, "skips": 0, "last": 0.0,
                                     "first": time.time(), "liked": False, "liked_at": 0.0,
                                     "listened": 0.0}
        return e

    # --- kayıt -----------------------------------------------------------
    def record(self, track: Track, listened_ms: int, duration_ms: int) -> None:
        if track.source == "local":      # elle atılmış dosyalar öneriye tohum olamaz
            return
        secs = max(0.0, listened_ms / 1000)
        dur = duration_ms / 1000 if duration_ms else 0
        threshold = min(MIN_PLAY_SECONDS, dur * 0.5) if 0 < dur else MIN_PLAY_SECONDS
        if secs >= threshold:
            e = self._entry(track)
            e["plays"] += 1
            e["last"] = time.time()
            e["listened"] += secs
        elif secs < SKIP_SECONDS:
            self._entry(track)["skips"] += 1
        else:
            return
        self._save()

    def toggle_like(self, track: Track) -> bool:
        e = self._entry(track)
        e["liked"] = not e["liked"]
        e["liked_at"] = time.time() if e["liked"] else 0.0
        self._save()
        return e["liked"]

    # --- sorgular --------------------------------------------------------
    def is_liked(self, track_id: str) -> bool:
        return bool(self._d.get(track_id, {}).get("liked"))

    def liked_tracks(self) -> list[Track]:
        items = sorted((e for e in self._d.values() if e["liked"]),
                       key=lambda e: -e["liked_at"])
        return [Track.from_dict(e["track"]) for e in items]

    def recent(self, n: int = 20) -> list[Track]:
        items = sorted((e for e in self._d.values() if e["last"] > 0), key=lambda e: -e["last"])
        return [Track.from_dict(e["track"]) for e in items[:n]]

    def entries(self) -> list[dict]:
        return list(self._d.values())

    def total_plays(self) -> int:
        return sum(e["plays"] for e in self._d.values())

    # --- arama geçmişi (ana sayfa önerileri için) ---------------------------
    def _load_searches(self):
        try:
            data = json.loads(self.searches_file.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return
        self._searches = [e for e in data if isinstance(e, dict) and isinstance(e.get("q"), str)] \
            if isinstance(data, list) else []

    def add_search(self, query: str) -> None:
        q = " ".join(query.split())[:80]
        if len(q) < 2:
            return
        self._searches = [e for e in self._searches if e["q"].lower() != q.lower()]
        self._searches.insert(0, {"q": q, "t": time.time()})
        del self._searches[30:]
        try:
            self.searches_file.write_text(json.dumps(self._searches, ensure_ascii=False), encoding="utf-8")
        except OSError:
            pass

    def recent_searches(self, n: int = 5) -> list[str]:
        return [e["q"] for e in self._searches[:n]]

    def clear(self) -> None:
        self._d.clear()
        self._searches = []
        self._save()
        try:
            self.searches_file.unlink(missing_ok=True)
        except OSError:
            pass
