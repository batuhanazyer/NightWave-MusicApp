"""Kişiye özel müzik önerisi. Dış bir "öneri API"sine ihtiyaç duymaz.

Nasıl çalışır?
  1. ZEVK PROFİLİ: Her parçaya bir puan verilir:
         (dinlenme + 3×beğeni − 0.7×atlama) × yakınlık
     "Yakınlık" zamanla azalır (yarı ömür 30 gün): geçen ay çok dinlediğin şey, dün
     dinlediğin kadar ağır basmaz.
  2. TOHUMLAR: En yüksek puanlı parçalardan, puanla orantılı rastgelelikle (her sanatçıdan
     en fazla biri) 4 tohum seçilir. Böylece her yenilemede biraz farklı öneri gelir.
  3. ADAYLAR: Her tohum için YouTube'un kendi "Mix" (radyo) listesi çekilir. Bu liste
     "bu şarkıyı sevenler şunları da dinledi" mantığıyla YouTube tarafından üretilir.
  4. SÜZME VE KARIŞTIRMA: Zaten çok dinlediğin, sürekli atladığın, çok uzun/derleme
     videolar elenir; tohumlar arasında sırayla karıştırılır; her öneriye bir "neden"
     yazılır (ör. "Tarkan dinlediğin için").

Spotify'ın eski öneri uç noktası yeni uygulamalara kapalı olduğu için kullanılmıyor.
"""
import random
import re
import time

from . import youtube
from .home import _BAD as _HOME_BAD
from .models import Track

HALF_LIFE_DAYS = 30
MIN_DURATION, MAX_DURATION = 45, 900          # saniye: 45 sn - 15 dk
_BAD_TITLE = re.compile(
    r"\b(full album|compilation|nonstop|non-stop|1 hour|10 hours|reaction|karaoke|"
    r"tam albüm|derleme)\b", re.I)
_VIDEO_ID = re.compile(r"^[A-Za-z0-9_-]{11}$")


# ---------------------------------------------------------------------------
# Sanatçı adı ve puanlama (saf fonksiyonlar, ağ gerektirmez)
# ---------------------------------------------------------------------------
def artist_of(t: Track) -> str:
    """YouTube kanal adı çoğu zaman sanatçı değildir; başlık/kanal ipuçlarından tahmin eder."""
    channel = (t.artist or "").split(",")[0].strip()
    if re.search(r"-\s*topic$", channel, re.I):                    # "Sanatçı - Topic" kanalı
        return re.sub(r"\s*-\s*topic$", "", channel, flags=re.I).strip()
    if t.source == "youtube" and " - " in t.title:                 # "Sanatçı - Şarkı" başlığı
        left = t.title.split(" - ", 1)[0].strip()
        if 0 < len(left) <= 40:
            return left
    return re.sub(r"\s*vevo$", "", channel, flags=re.I).strip()


def entry_score(e: dict, now: float | None = None) -> float:
    now = now or time.time()
    base = e["plays"] + 3.0 * (1 if e["liked"] else 0) - 0.7 * e["skips"]
    if base <= 0:
        return 0.0
    last = max(e.get("last", 0), e.get("liked_at", 0), e.get("first", 0))
    age_days = max(0.0, (now - last) / 86400)
    recency = 0.5 ** (age_days / HALF_LIFE_DAYS)
    return base * (0.35 + 0.65 * recency)


def enough_data(entries: list[dict]) -> bool:
    return sum(1 for e in entries if entry_score(e) > 0) >= 3


def top_artists(entries: list[dict], n: int = 5) -> list[tuple[str, float]]:
    agg: dict[str, float] = {}
    for e in entries:
        score = entry_score(e)
        if score <= 0:
            continue
        name = artist_of(Track.from_dict(e["track"]))
        if name:
            agg[name] = agg.get(name, 0.0) + score
    return sorted(agg.items(), key=lambda kv: -kv[1])[:n]


def pick_seeds(entries: list[dict], k: int = 4, rng=random) -> list[Track]:
    pool = [(entry_score(e), e) for e in entries]
    pool = sorted((p for p in pool if p[0] > 0), key=lambda p: -p[0])[:12]
    seeds, used = [], set()
    while pool and len(seeds) < k:
        i = rng.choices(range(len(pool)), weights=[p[0] for p in pool])[0]
        _score, e = pool.pop(i)
        t = Track.from_dict(e["track"])
        a = artist_of(t).lower()
        if a and a in used:                 # çeşitlilik: sanatçı başına tek tohum
            continue
        used.add(a)
        seeds.append(t)
    return seeds


def excluded_ids(entries: list[dict]) -> set[str]:
    """Önerilmeyecek parçalar: zaten çok dinlenenler ve sürekli atlananlar."""
    out = set()
    for e in entries:
        tid = e["track"]["id"]
        if e["plays"] >= 3 or (e["skips"] >= 2 and not e["liked"]):
            out.add(tid)
    return out


def home_bad_title(title: str) -> bool:
    return bool(_HOME_BAD.search(title))


def _acceptable(t: Track) -> bool:
    if _BAD_TITLE.search(t.title) or home_bad_title(t.title):
        return False
    return t.duration == 0 or MIN_DURATION <= t.duration <= MAX_DURATION


def merge_candidates(per_seed: list[tuple[Track, list[Track]]], exclude: set[str],
                     count: int = 30) -> tuple[list[Track], dict[str, str]]:
    """Tohum listelerini sırayla (round-robin) karıştırır, süzer ve nedenlerini yazar."""
    seen = set(exclude)
    seen.update(seed.id for seed, _ in per_seed)
    reasons: dict[str, str] = {}
    out: list[Track] = []
    queues = [(seed, [t for t in cands]) for seed, cands in per_seed]
    while queues and len(out) < count:
        for seed, cands in list(queues):
            while cands:
                t = cands.pop(0)
                if t.id in seen or not _acceptable(t):
                    continue
                seen.add(t.id)
                out.append(t)
                who = artist_of(seed) or seed.title
                reasons[t.id] = f"{who} dinlediğin için"
                break
            if not cands:
                queues.remove((seed, cands))
            if len(out) >= count:
                break
    return out, reasons


# ---------------------------------------------------------------------------
# Ağ gerektiren kısım
# ---------------------------------------------------------------------------
def youtube_id_for(track: Track) -> str:
    """Parçanın YouTube kimliği; yoksa (ör. Spotify parçası) aratıp bulur."""
    if track.source == "youtube" and _VIDEO_ID.match(track.id):
        return track.id
    query = track.query or f"{track.artist} - {track.title}"
    found = youtube.search(query, limit=1)
    if not found:
        raise RuntimeError("Bu parça YouTube'da bulunamadı.")
    return found[0].id


def build(entries: list[dict], count: int = 30, rng=random) -> dict:
    """Önerileri üretir. Arka plan iş parçacığında çağrılmalıdır (ağ kullanır).

    Döner: {"tracks": [...], "reasons": {id: neden}, "taste": [(sanatçı, puan), ...]}
    """
    seeds = pick_seeds(entries, k=4, rng=rng)
    per_seed, last_error = [], None
    for seed in seeds:
        try:
            per_seed.append((seed, youtube.related(youtube_id_for(seed), limit=25)))
        except Exception as exc:  # noqa: BLE001 - bir tohum başarısızsa diğerleriyle devam et
            last_error = exc
    if not per_seed:
        raise RuntimeError(f"Öneriler alınamadı: {last_error}" if last_error
                           else "Öneri için yeterli veri yok.")
    tracks, reasons = merge_candidates(per_seed, excluded_ids(entries), count)
    return {"tracks": tracks, "reasons": reasons, "taste": top_artists(entries, 5)}


def from_query(query: str, limit: int = 20) -> dict:
    """Kullanıcının aramasına göre öneri: aramanın en iyi sonucunun YouTube "Mix" listesi.

    Ağ kullanır; arka planda çağrılmalıdır. Döner: {"tracks": [...], "reasons": {id: neden}}
    """
    top = youtube.search(query, limit=1)
    if not top:
        return {"tracks": [], "reasons": {}}
    similar = youtube.related(top[0].id, limit=limit + 10)
    tracks, reasons = [], {}
    for t in [top[0]] + similar:
        if t.id not in reasons and _acceptable(t):
            tracks.append(t)
            reasons[t.id] = f"“{query}” aramana göre"
        if len(tracks) >= limit:
            break
    return {"tracks": tracks, "reasons": reasons}
