"""Bağlantı kontrolü ve küçük ağ yardımcıları."""
import socket
import urllib.request


def is_online(timeout: float = 2.0) -> bool:
    """İnternet var mı? Hızlı bir TCP bağlantısı denemesiyle anlar."""
    for host in (("1.1.1.1", 53), ("8.8.8.8", 53)):
        try:
            with socket.create_connection(host, timeout=timeout):
                return True
        except OSError:
            continue
    return False


def fetch_bytes(url: str, timeout: float = 8.0) -> bytes:
    """Kapak görseli gibi küçük dosyaları indirir."""
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return resp.read()
