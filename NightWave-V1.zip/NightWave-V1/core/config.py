"""Ayarların saklanması.

Ayarlar:        %APPDATA%\\NightWave\\config.json
Kütüphane:      %APPDATA%\\NightWave\\library.json
Çalma listeleri:%APPDATA%\\NightWave\\playlists.json  (kapaklar: covers\\)
Müzikler:       Müzik\\NightWave  (Ayarlar'dan değiştirilebilir)
"""
import json
import os
from pathlib import Path

APP_NAME = "NightWave"
APP_DIR = Path(os.getenv("APPDATA", Path.home())) / APP_NAME
APP_DIR.mkdir(parents=True, exist_ok=True)

CONFIG_FILE = APP_DIR / "config.json"
LIBRARY_FILE = APP_DIR / "library.json"
PLAYLISTS_FILE = APP_DIR / "playlists.json"
HISTORY_FILE = APP_DIR / "history.json"
COVER_DIR = APP_DIR / "covers"
CACHE_DIR = APP_DIR / "cache"
THUMB_DIR = APP_DIR / "thumbs"
HOME_CACHE_FILE = APP_DIR / "home_cache.json"

DEFAULTS = {
    # Spotify
    "spotify_client_id": "",
    "spotify_client_secret": "",
    # Genel
    "download_dir": str(Path.home() / "Music" / APP_NAME),
    "volume": 70,
    "close_to": "tray",        # tray | mini | quit  (X tuşuna basınca)
    "media_keys": True,        # Windows medya tuşları / SMTC
    "taskbar": True,           # görev çubuğu: önizleme düğmeleri, ilerleme, rozet
    "personalize": True,       # dinleme geçmişi + kişisel öneriler (yalnızca bu cihazda)
    "play_mode": "cache",      # cache: önce hızlıca indirip yerelden çal (güvenilir) | stream: doğrudan akış
    "prefetch": True,          # sıradaki şarkıyı arka planda hazırla
    "progressive": True,       # HIZLI BAŞLAT: şarkıyı indirirken çal (tamamını bekleme)
    "raw_ok": True,            # ham ses Qt'de çalıyor mu? Çalmazsa uygulama kendisi False yapar
    "force_ipv4": False,       # YouTube çok yavaşsa: yalnızca IPv4
    "cache_mb": 500,           # ses önbelleği üst sınırı
    "home_genres": ["turkce_pop", "global", "yeni", "lofi", "turkce_rap"],   # ana sayfa türleri
    "shuffle": False,
    "repeat": "off",           # off | all | one
    # Görünüm
    "theme": "midnight",
    "accent": "#8B7CFF",
    "row_height": 46,          # 36 sıkışık, 46 normal, 56 geniş
    "dynamic_accent": False,   # vurgu rengini çalan şarkının kapağından al
    "custom_themes": {},       # kullanıcının oluşturduğu temalar
    # Müzik görselleştirici ("Çalıyor" ekranı)
    "viz_style": "bars",       # bars | mirror | blocks | wave | circle
    "viz_color": "accent",     # accent | rainbow
    "viz_bars": 64,
    "viz_gain": 100,           # duyarlılık, yüzde
    "viz_real": True,          # gerçek ses analizi (kapalıysa simülasyon)
    # Mini oynatıcı
    "mini_opacity": 95,        # yüzde
    "mini_pos": None,          # [x, y]
}


def load() -> dict:
    cfg = dict(DEFAULTS)
    try:
        cfg.update(json.loads(CONFIG_FILE.read_text(encoding="utf-8")))
    except (OSError, ValueError):
        pass  # ilk çalıştırma ya da bozuk dosya -> varsayılanlar
    return cfg


def save(cfg: dict) -> None:
    CONFIG_FILE.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
