"""Spotify Web API (spotipy) ile sadece üst veri: arama, albüm, çalma listesi.

NOT: Spotify ses akışını DRM ile korur, uygulamalara vermez. Bu yüzden Spotify
parçaları çalınırken "Sanatçı - Şarkı" ifadesi YouTube'da aranıp o ses akışı
oynatılır (bkz. youtube.resolve_stream).
"""
import spotipy
from spotipy.oauth2 import SpotifyClientCredentials

from .models import Track


class SpotifyClient:
    def __init__(self, client_id: str, client_secret: str):
        auth = SpotifyClientCredentials(client_id=client_id, client_secret=client_secret)
        self.sp = spotipy.Spotify(auth_manager=auth, requests_timeout=10, retries=2)

    @staticmethod
    def _to_track(item: dict, album: dict | None = None) -> Track:
        album = album or item.get("album") or {}
        images = album.get("images") or []
        # Görseller büyükten küçüğe sıralı; ortadakini seçiyoruz
        thumb = images[1]["url"] if len(images) > 1 else (images[0]["url"] if images else "")
        artists = ", ".join(a["name"] for a in item.get("artists", []))
        title = item["name"]
        return Track(
            id=f"sp:{item['id']}",
            title=title,
            artist=artists,
            duration=int((item.get("duration_ms") or 0) // 1000),
            thumbnail=thumb,
            source="spotify",
            query=f"{artists} - {title} official audio",
        )

    def search_tracks(self, query: str, limit: int = 20) -> list[Track]:
        res = self.sp.search(q=query, type="track", limit=limit)
        return [self._to_track(i) for i in res["tracks"]["items"] if i and i.get("id")]

    def search_album_tracks(self, query: str) -> list[Track]:
        """En iyi eşleşen albümü bulur ve parçalarını döndürür."""
        res = self.sp.search(q=query, type="album", limit=1)
        albums = res["albums"]["items"]
        if not albums:
            return []
        album = albums[0]
        items = self.sp.album_tracks(album["id"], limit=50)["items"]
        return [self._to_track(i, album) for i in items if i and i.get("id")]

    def playlist_tracks(self, playlist_url: str, max_tracks: int = 300) -> list[Track]:
        """Herkese açık bir çalma listesinin (URL ya da URI) parçalarını getirir."""
        page = self.sp.playlist_items(playlist_url, limit=100)
        tracks: list[Track] = []
        while page:
            for entry in page["items"]:
                t = (entry or {}).get("track")
                if t and t.get("id"):  # silinmiş parçalar None gelebilir
                    tracks.append(self._to_track(t))
            if len(tracks) >= max_tracks or not page.get("next"):
                break
            page = self.sp.next(page)
        return tracks[:max_tracks]
