"""Uygulama genelinde kullanılan veri modeli."""
from dataclasses import asdict, dataclass, fields


def fmt_time(seconds: int) -> str:
    """Saniyeyi m:ss (ya da h:mm:ss) biçimine çevirir."""
    seconds = max(0, int(seconds or 0))
    h, rem = divmod(seconds, 3600)
    m, s = divmod(rem, 60)
    return f"{h}:{m:02d}:{s:02d}" if h else f"{m}:{s:02d}"


@dataclass
class Track:
    id: str                 # Benzersiz anahtar: YouTube id'si, "sp:<spotify id>" veya "local:<dosya>"
    title: str
    artist: str = ""
    duration: int = 0       # saniye
    thumbnail: str = ""     # kapak görseli URL'si
    source: str = "youtube" # youtube | spotify | local
    url: str = ""           # YouTube izleme adresi (source == youtube ise)
    query: str = ""         # Spotify parçaları için YouTube'da aranacak ifade
    local_path: str = ""    # İndirildiyse yerel dosya yolu

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict) -> "Track":
        names = {f.name for f in fields(cls)}
        return cls(**{k: v for k, v in data.items() if k in names})
