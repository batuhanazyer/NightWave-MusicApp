"""Ses önbelleği: internetten çalınan şarkılar önce buraya (ses-only, dönüştürmesiz) iner, sonra yerelden çalınır.

Neden? Qt'nin ses motoru YouTube akış adreslerini (özel başlık/imza ister) çoğu sistemde doğrudan açamaz.
yt-dlp ise bunu sorunsuz indirir. İndirilen dosya yerelden çalındığı için sorunsuz çalar, tekrar çalınca
da anında başlar. Önbellek boyutu sınırlıdır; en eski kullanılanlar otomatik silinir.
"""
import os
import re
import time
from pathlib import Path

AUDIO_SUFFIXES = {".m4a", ".webm", ".opus", ".ogg", ".mp3", ".aac", ".mp4", ".flac", ".wav"}
_TEMP_FORMAT = re.compile(r"\.f\d+\.")           # yt-dlp'nin birleştirme sırasındaki geçici dosyaları


class AudioCache:
    def __init__(self, directory: Path, max_mb: int = 500):
        self.dir = Path(directory)
        self.max_bytes = int(max_mb) * 1024 * 1024

    @staticmethod
    def base_name(track_id: str) -> str:
        return re.sub(r"[^A-Za-z0-9_-]", "_", track_id)[:80] or "parca"

    def path_for(self, track_id: str, mp3_only: bool = False) -> Path | None:
        """Tamamlanmış önbellek dosyası (yarım .part dosyaları sayılmaz). Yoksa None.

        mp3_only: ham (m4a/webm) dosyaları yok say."""
        if not self.dir.exists():
            return None
        base = self.base_name(track_id)
        # MP3 öncelikli: en uyumlu biçim (İndir düğmesinin de ürettiği, sorunsuz çalan biçim)
        for p in sorted(self.dir.glob(base + ".*"), key=lambda f: (f.suffix.lower() != ".mp3", f.name)):
            if p.suffix.lower() in AUDIO_SUFFIXES and not _TEMP_FORMAT.search(p.name) and p.is_file():
                if mp3_only and p.suffix.lower() != ".mp3":
                    continue
                return p
        return None

    def purge_non_mp3(self) -> int:
        """FFmpeg varken ham (m4a/webm) önbellek dosyalarını siler: bunlar bazı sistemlerde Qt'de çalmıyor.
        Silinenler gerektiğinde MP3 olarak yeniden indirilir."""
        n = 0
        if self.dir.exists():
            for p in self.dir.iterdir():
                if p.is_file() and p.suffix.lower() in AUDIO_SUFFIXES and p.suffix.lower() != ".mp3":
                    try:
                        p.unlink()
                        n += 1
                    except OSError:
                        pass
        return n

    def touch(self, path: Path) -> None:
        """Kullanıldı olarak işaretle (silme sırasında en sona kalsın)."""
        try:
            os.utime(path, None)
        except OSError:
            pass

    def size(self) -> int:
        if not self.dir.exists():
            return 0
        return sum(p.stat().st_size for p in self.dir.iterdir() if p.is_file())

    def trim(self, keep: Path | None = None) -> int:
        """Sınırı aşıyorsa en eski kullanılan dosyaları siler. Silinen dosya sayısını döndürür."""
        if not self.dir.exists():
            return 0
        files = [p for p in self.dir.iterdir() if p.is_file()]
        total = sum(p.stat().st_size for p in files)
        removed = 0
        now = time.time()
        for p in sorted(files, key=lambda f: f.stat().st_mtime):          # en eski önce
            if total <= self.max_bytes:
                break
            if keep is not None and p == keep:
                continue
            if p.suffix == ".part" and now - p.stat().st_mtime < 600:       # indirilmekte olanı silme
                continue
            try:
                total -= p.stat().st_size
                p.unlink()
                removed += 1
            except OSError:
                pass
        return removed

    def clear(self) -> int:
        n = 0
        if self.dir.exists():
            for p in self.dir.iterdir():
                try:
                    if p.is_file():
                        p.unlink()
                        n += 1
                except OSError:
                    pass
        return n
