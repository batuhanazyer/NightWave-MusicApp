"""'İndirirken çal': yt-dlp'nin henüz indirmekte olduğu ses dosyasını Qt'ye yerel HTTP üzerinden, büyüdükçe verir.

Neden? Şarkıyı tamamen indirmeyi beklemek yavaş bağlantıda dakikalar sürebilir. Ses çalma hızından
(~16 KB/s) çok daha hızlı indiği için, birkaç yüz KB geldiği anda çalmaya başlamak kesintisiz çalar.
Qt'nin ses motoru dosyayı normal bir HTTP sunucusundan okuyormuş gibi alır (Range desteği vardır); okuma
indirmeyi yakalarsa sunucu yeni veri gelene kadar bekler.

Güvenlik: yalnızca 127.0.0.1'e bağlanır, rastgele anahtarlı adresler verir, yalnızca kayıtlı dosyaları sunar.
"""
import os
import re
import secrets
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

_RANGE = re.compile(r"bytes=(\d*)-(\d*)$")
CHUNK = 64 * 1024
STALL_TIMEOUT = 45.0         # bu kadar süre hiç büyümezse bağlantıyı kes (Qt hata verir, oynatıcı yedeğe düşer)
MAX_STREAMS = 8
MIME = {"m4a": "audio/mp4", "mp4": "audio/mp4", "webm": "audio/webm", "opus": "audio/ogg",
        "ogg": "audio/ogg", "mp3": "audio/mpeg"}


class Stream:
    """Büyümekte olan (ya da bitmiş) tek bir ses dosyası."""

    def __init__(self, path_fn, total: int | None = None, ext: str = "m4a"):
        self.path_fn = path_fn           # () -> Path | None : şu an yazılan (.part) ya da tamamlanmış dosya
        self.total = total               # bilinen kesin toplam bayt (bilinmiyorsa None)
        self.ext = ext
        self.done = threading.Event()    # indirme bitti (başarılı ya da başarısız)
        self.failed = False

    def size(self) -> int:
        p = self.path_fn()
        try:
            return os.stat(p).st_size if p else 0
        except OSError:
            return 0

    def read(self, pos: int, n: int) -> bytes:
        """Kısa süreli açıp kapatır: Windows'ta yt-dlp'nin .part dosyasını yeniden adlandırmasını engellemesin."""
        p = self.path_fn()
        if not p:
            return b""
        try:
            with open(p, "rb") as f:
                f.seek(pos)
                return f.read(n)
        except OSError:
            return b""


class _LocalServer(ThreadingHTTPServer):
    daemon_threads = True

    def server_bind(self):
        """HTTPServer.server_bind ters DNS sorgusu (getfqdn) yapar; bazı Windows makinelerinde saniyelerce bekletir."""
        import socketserver
        socketserver.TCPServer.server_bind(self)
        host, port = self.server_address[:2]
        self.server_name, self.server_port = host, port


class ProgressiveServer:
    def __init__(self):
        self._streams: dict[str, Stream] = {}
        self._lock = threading.Lock()
        self._httpd: ThreadingHTTPServer | None = None
        self.port = 0

    # ---- yaşam döngüsü ---------------------------------------------------
    def _ensure_started(self) -> None:
        with self._lock:
            if self._httpd is not None:
                return
            server = self

            class Handler(BaseHTTPRequestHandler):
                def log_message(self, *a):          # konsolu kirletme
                    pass

                def do_HEAD(self):
                    self._serve(head=True)

                def do_GET(self):
                    self._serve(head=False)

                def _serve(self, head: bool):
                    try:
                        server._handle(self, head)
                    except (BrokenPipeError, ConnectionError, OSError):
                        pass                        # Qt bağlantıyı kapattı (sarma/parça değişimi): normal

            httpd = _LocalServer(("127.0.0.1", 0), Handler)
            self.port = httpd.server_address[1]
            threading.Thread(target=httpd.serve_forever, daemon=True, name="nw-progressive").start()
            self._httpd = httpd

    def register(self, stream: Stream) -> str:
        """Akışı kaydeder ve Qt'ye verilecek yerel URL'yi döndürür."""
        self._ensure_started()
        key = secrets.token_hex(8)
        with self._lock:
            self._streams[key] = stream
            while len(self._streams) > MAX_STREAMS:              # en eskiyi at
                self._streams.pop(next(iter(self._streams)))
        return f"http://127.0.0.1:{self.port}/s/{key}.{stream.ext}"

    def unregister(self, url: str) -> None:
        key = url.rsplit("/", 1)[-1].split(".")[0]
        with self._lock:
            self._streams.pop(key, None)

    def shutdown(self) -> None:
        with self._lock:
            httpd, self._httpd = self._httpd, None
            self._streams.clear()
        if httpd is not None:
            httpd.shutdown()
            httpd.server_close()

    # ---- istek işleme --------------------------------------------------------
    def _handle(self, h: BaseHTTPRequestHandler, head: bool) -> None:
        path = h.path.split("?", 1)[0]
        m = re.fullmatch(r"/s/([0-9a-f]{16})\.[A-Za-z0-9]+", path)
        stream = None
        if m:
            with self._lock:
                stream = self._streams.get(m.group(1))
        if stream is None:
            h.send_error(404)
            return

        total = stream.total
        start, end, ranged = 0, None, False
        rng = h.headers.get("Range")
        if rng and total is not None:                        # toplam bilinmiyorsa Range yok sayılır (200, baştan)
            mm = _RANGE.match(rng.strip())
            if mm:
                a, b = mm.groups()
                ranged = True
                if a:
                    start = int(a)
                    end = int(b) if b else None
                elif b:                                       # bytes=-N : son N bayt
                    start, end = max(0, total - int(b)), None
        if total is not None:
            if start >= total:
                h.send_response(416)
                h.send_header("Content-Range", f"bytes */{total}")
                h.send_header("Content-Length", "0")
                h.end_headers()
                return
            end = total - 1 if end is None else min(end, total - 1)
            length = max(0, end - start + 1)
        else:
            length = None

        h.send_response(206 if ranged else 200)
        h.send_header("Content-Type", MIME.get(stream.ext, "application/octet-stream"))
        h.send_header("Accept-Ranges", "bytes" if total is not None else "none")
        if length is not None:
            h.send_header("Content-Length", str(length))
        if ranged:
            h.send_header("Content-Range", f"bytes {start}-{end}/{total}")
        h.send_header("Cache-Control", "no-store")
        h.end_headers()
        if head:
            return

        pos, remaining = start, length
        last_growth = time.monotonic()
        while remaining is None or remaining > 0:
            size = stream.size()
            if size > pos:
                n = min(CHUNK, size - pos, remaining if remaining is not None else CHUNK)
                data = stream.read(pos, n)
                if data:
                    h.wfile.write(data)
                    pos += len(data)
                    if remaining is not None:
                        remaining -= len(data)
                    last_growth = time.monotonic()
                    continue
            if stream.done.is_set() and stream.size() <= pos:
                break                                        # kaynak bitti ama istenen bayt yok: bağlantıyı kes
            if time.monotonic() - last_growth > STALL_TIMEOUT:
                break
            time.sleep(0.03)


_server: ProgressiveServer | None = None
_server_lock = threading.Lock()


def server() -> ProgressiveServer:
    global _server
    with _server_lock:
        if _server is None:
            _server = ProgressiveServer()
        return _server


def existing(tmp: Path, final: Path) -> Path | None:
    """İndirme sırasında .part, bittiğinde asıl dosya. Yeniden adlandırma anında ikisi de yoksa None."""
    if final.exists():
        return final
    if tmp.exists():
        return tmp
    return None
