"""QMediaPlayer'ın çaldığı sesin gerçek örneklerini yakalar (Qt 6.8+ QAudioBufferOutput, FFmpeg arka ucu).

Akış: QMediaPlayer -> QAudioBufferOutput -> AudioTap (PCM -> mono float) -> ChunkBuffer.
Görselleştirici, çalma konumuna karşılık gelen ses penceresini ChunkBuffer'dan ister;
böylece görüntü müzikle senkron olur (kod çözücü çalmanın biraz önündedir).

Qt 6.8'den eski ya da FFmpeg dışı arka uçta `ok` False kalır ve görselleştirici simülasyona düşer.
"""
import time
from collections import deque

try:
    import numpy as np
except ImportError:  # numpy yoksa görselleştirici simüle modda çalışır
    np = None

from PyQt6.QtCore import QObject

_FORMATS = {   # Qt örnek biçimi -> (numpy tipi, ölçek, kaydırma)
    "Float": ("float32", 1.0, 0.0),
    "Int16": ("int16", 32768.0, 0.0),
    "Int32": ("int32", 2147483648.0, 0.0),
    "UInt8": ("uint8", 128.0, 128.0),
}


def pcm_to_mono(raw: bytes, fmt: str, channels: int):
    """Ham PCM baytlarını -1..1 aralığında mono float32 dizisine çevirir. Bilinmeyen biçimde None."""
    if fmt not in _FORMATS:
        return None
    dtype, scale, offset = _FORMATS[fmt]
    frame_bytes = np.dtype(dtype).itemsize * max(1, channels)
    usable = len(raw) - (len(raw) % frame_bytes)
    if usable <= 0:
        return np.zeros(0, np.float32)
    arr = np.frombuffer(raw[:usable], dtype=dtype).astype(np.float32)
    if offset:
        arr -= offset
    if scale != 1.0:
        arr /= scale
    if channels > 1:
        arr = arr.reshape(-1, channels).mean(axis=1)
    return arr


class _Chunk:
    __slots__ = ("start_us", "samples", "sr")

    def __init__(self, start_us, samples, sr):
        self.start_us, self.samples, self.sr = start_us, samples, sr

    @property
    def end_us(self):
        return self.start_us + len(self.samples) * 1_000_000 / self.sr


class ChunkBuffer:
    """Son ~2 saniyelik ses parçalarını zaman damgalarıyla tutar."""

    def __init__(self, max_seconds: float = 2.0):
        self._chunks: deque = deque()
        self._max = max_seconds
        self._last_arrival = 0.0

    def clear(self) -> None:
        self._chunks.clear()

    def add(self, start_us: int, samples, sr: int) -> None:
        if not len(samples) or sr <= 0:
            return
        last = self._chunks[-1] if self._chunks else None
        if start_us is None or start_us < 0:               # zaman damgası yok: öncekinin devamı say
            start_us = last.end_us if last else 0
        elif last is not None and start_us < last.start_us:  # geriye sarıldı: eski veriyi at
            self._chunks.clear()
        self._chunks.append(_Chunk(start_us, samples, sr))
        self._last_arrival = time.monotonic()
        while len(self._chunks) > 1 and \
                sum(len(c.samples) for c in self._chunks) > self._max * sr:
            self._chunks.popleft()

    def has_data(self, max_age: float = 1.0) -> bool:
        return bool(self._chunks) and (time.monotonic() - self._last_arrival) < max_age

    def window(self, pos_ms: int, n: int):
        """Çalma konumunda biten, n örneklik pencere ve örnekleme hızı. Veri yoksa None."""
        if not self._chunks:
            return None
        first, last = self._chunks[0], self._chunks[-1]
        end_us = pos_ms * 1000
        if end_us < first.start_us - 500_000 or end_us > last.end_us + 500_000:
            end_us = last.end_us                            # zaman çizelgeleri uyuşmuyor: en yeniyi kullan
        idx = 0
        for i in range(len(self._chunks) - 1, -1, -1):
            if self._chunks[i].start_us <= end_us:
                idx = i
                break
        chunks = list(self._chunks)
        c = chunks[idx]
        off = int(max(0, min(len(c.samples), (end_us - c.start_us) * c.sr / 1_000_000)))
        parts = [c.samples[:off]]
        need, j = n - off, idx - 1
        while need > 0 and j >= 0:
            take = chunks[j].samples[-need:]
            parts.insert(0, take)
            need -= len(take)
            j -= 1
        out = np.concatenate(parts)[-n:]
        return (out, c.sr) if len(out) else None


class AudioTap(QObject):
    """Ses yakalama, görselleştirici ilk kez gösterildiğinde (tembel) bağlanır.

    Böylece görselleştiriciyi hiç açmayan biri için çalma yolu Qt'nin ses tamponu çıkışıyla
    hiç değiştirilmez: bir sistemde sorun çıkarsa bile müzik çalmaya devam eder.
    """

    def __init__(self, media_player, parent=None):
        super().__init__(parent)
        self._media = media_player
        self._buf = ChunkBuffer()
        self._out = None
        self._attached = False
        self._allowed = True       # Ayarlar > "gerçek ses analizi"
        self.ok = False            # gerçek ses yakalama bağlı ve çalışıyor mu
        self.enabled = False       # sadece görselleştirici görünürken analiz et
        self._users = 0            # görünen görselleştirici sayısı (Çalıyor ekranı + mini oynatıcı)
        self.error = ""
        self._failures = 0
        if np is None:
            self.error = "numpy kurulu değil"

    # ---- arka uç aç/kapat ------------------------------------------------
    def set_backend(self, on: bool) -> None:
        """Ayarlar'dan gerçek analizi aç/kapat. Kapatılırsa yakalama ayrılır (simülasyona dönülür)."""
        self._allowed = bool(on)
        if not on:
            self._detach()
        elif self.enabled:
            self._attach()

    def set_enabled(self, on: bool) -> None:
        """Görselleştirici göründü/gizlendi. İlk gösterimde yakalama bağlanır, sonra bağlı kalır."""
        self._users = self._users + 1 if on else max(0, self._users - 1)
        self.enabled = self._users > 0                 # biri hâlâ görünüyorsa yakalama açık kalır
        if on:
            if self._allowed:
                self._attach()
        elif not self.enabled:
            self._buf.clear()

    def _attach(self) -> None:
        if np is None or self._attached:
            return
        try:
            if self._out is None:
                from PyQt6.QtMultimedia import QAudioBufferOutput
                self._out = QAudioBufferOutput(self)
                self._out.audioBufferReceived.connect(self._on_buffer)
            self._media.setAudioBufferOutput(self._out)
            self._attached = True
            self.ok, self.error, self._failures = True, "", 0
        except Exception as exc:  # noqa: BLE001 - Qt < 6.8 ya da farklı arka uç
            self.ok = False
            self.error = f"{exc.__class__.__name__}: {exc}"

    def _detach(self) -> None:
        self.ok = False
        self._buf.clear()
        if self._attached:
            try:
                self._media.setAudioBufferOutput(None)
            except Exception:  # noqa: BLE001
                pass
            self._attached = False

    # ---- veri ------------------------------------------------------------
    def clear(self) -> None:
        self._buf.clear()

    def has_data(self) -> bool:
        return self._buf.has_data()

    def window(self, pos_ms: int, n: int):
        return self._buf.window(pos_ms, n)

    def _on_buffer(self, buf) -> None:
        if not self.enabled:
            return
        try:
            if not buf.isValid():                          # akış sonu: boş tampon
                return
            fmt = buf.format()
            raw = buf.constData().asstring(buf.byteCount())
            samples = pcm_to_mono(raw, fmt.sampleFormat().name, fmt.channelCount())
            if samples is None or not len(samples):
                raise ValueError(f"desteklenmeyen örnek biçimi: {fmt.sampleFormat()}")
            self._buf.add(buf.startTime(), samples, fmt.sampleRate())
            self._failures = 0
        except Exception as exc:  # noqa: BLE001
            self._failures += 1
            self.error = f"{exc.__class__.__name__}: {exc}"
            if self._failures > 20:                        # kalıcı sorun: simülasyona düş
                self.ok = False
