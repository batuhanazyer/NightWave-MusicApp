"""yt-dlp / ağ hatalarını anlaşılır Türkçe mesajlara çevirir."""
import re

class Cancelled(RuntimeError):
    """Kullanıcı başka şarkıya geçtiği için bilerek iptal edilen iş. Hata değildir; sessizce yok sayılır."""


MSG_JS = ("YouTube için JavaScript çalışma zamanı (Deno) bulunamadı. "
          "Kurulum: winget install DenoLand.Deno — sonra uygulamayı yeniden başlatın.")
MSG_FFMPEG = ("FFmpeg bulunamadı ya da çalışmadı. "
              "Kurulum: winget install Gyan.FFmpeg — sonra uygulamayı yeniden başlatın.")
MSG_UPDATE = 'yt-dlp güncel olmayabilir. Deneyin: pip install -U "yt-dlp[default]"'

# (desen, mesaj): ilk eşleşen kazanır
RULES = [
    (r"javascript runtime|js runtime|n challenge|nsig|challenge solving|jsc\b", MSG_JS),
    (r"requested format is not available",
     "YouTube'dan ses akışı alınamadı. Çoğu zaman JavaScript çalışma zamanı (Deno) eksik "
     "olduğundan olur: winget install DenoLand.Deno — ya da yt-dlp eskidir: "
     'pip install -U "yt-dlp[default]"'),
    (r"ffmpeg|ffprobe|postprocessing", MSG_FFMPEG),
    (r"sign in to confirm|not a bot|confirm you.?re not",
     "YouTube bot doğrulaması istiyor. " + MSG_UPDATE + " VPN/proxy kapalıyken deneyin."),
    (r"age.?restricted|confirm your age", "Bu video yaş sınırlı; giriş yapmadan çalınamaz."),
    (r"private video|video unavailable|not available|has been removed|terminated|blocked it",
     "Bu video kullanılamıyor (özel, silinmiş ya da bölgenize kapalı). Başka bir sonuç deneyin."),
    (r"http error 403", "YouTube erişimi reddetti (403). " + MSG_UPDATE),
    (r"http error 429|too many requests",
     "YouTube çok fazla istek algıladı (429). Biraz bekleyip tekrar deneyin."),
    (r"getaddrinfo|name or service not known|timed out|timeout|connection (reset|refused|aborted)|"
     r"network is unreachable|urlopen error|remote end closed",
     "Ağ hatası: internet bağlantınızı kontrol edin."),
    (r"permission denied|access is denied|winerror 5",
     "Dosya erişim hatası: indirme klasörüne yazma izniniz olduğundan emin olun."),
    (r"no space left|disk full", "Diskte yeterli boş alan yok."),
]


def clean(text) -> str:
    return re.sub(r"\x1b\[[0-9;]*m", "", str(text)).strip()


def friendly_error(exc_or_text) -> str:
    raw = clean(exc_or_text)
    low = raw.lower()
    for pattern, message in RULES:
        if re.search(pattern, low):
            return message
    return (raw or "Bilinmeyen hata")[:300]


# yt-dlp UYARILARI (hata değil) -> kullanıcıya ipucu. En önemlisi: JS çözücü çalışmıyorsa YouTube indirmeyi YAVAŞLATIR.
WARNING_HINTS = [
    (r"n challenge|nsig|javascript runtime|js runtime|challenge solving",
     "JS çözücü çalışmıyor: YouTube indirmeyi yavaşlatıyor olabilir. Deno kurulu mu? (Ayarlar → Sistem)"),
    (r"throttl", "YouTube indirmeyi yavaşlatıyor (kısıtlama). Deno kurulu mu? (Ayarlar → Sistem)"),
]


def warning_hint(text: str) -> str:
    low = (text or "").lower()
    for pattern, hint in WARNING_HINTS:
        if re.search(pattern, low):
            return hint
    return ""
