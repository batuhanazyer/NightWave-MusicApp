"""Windows medya tuşları ve SMTC (System Media Transport Controls) entegrasyonu.

İki yöntem dener, ilk çalışanı kullanır:
  1. SMTC  -> Ses paneli / kilit ekranı / Bluetooth kulaklık düğmeleri. Şarkı adı, sanatçı,
              kapak ve ilerleme çubuğu Windows'un medya penceresinde görünür.
              Gerekli paket: winrt-* (ya da eski `winsdk`), bkz. requirements.txt
  2. Global kısayol -> SMTC kurulamazsa klavyedeki medya tuşlarını (RegisterHotKey) yakalar.

Hiçbiri çalışmazsa uygulama normal çalışır, sadece medya tuşları devre dışı kalır.
`backend` alanı hangisinin aktif olduğunu söyler: "SMTC" | "Global kısayol" | "yok".

NOT: SMTC olayları Qt dışı bir iş parçacığından gelir. Bu yüzden doğrudan arayüze
dokunmuyor, Qt sinyalleriyle ana iş parçacığına aktarıyoruz.
"""
import ctypes
import sys
from datetime import timedelta

from PyQt6.QtCore import QAbstractNativeEventFilter, QCoreApplication, QObject, pyqtSignal

WM_HOTKEY = 0x0312
MOD_NOREPEAT = 0x4000
_VK = {0xB3: "play_pause", 0xB0: "next", 0xB1: "prev", 0xB2: "stop"}   # medya tuşu kodları


class _WinRT:
    """winrt / winsdk isim alanlarını tek yerde toplar."""

    def __init__(self):
        try:                                   # modern paketler: pip install winrt-...
            from winrt.windows.foundation import Uri
            from winrt.windows.media import (MediaPlaybackStatus, MediaPlaybackType,
                                             SystemMediaTransportControlsButton,
                                             SystemMediaTransportControlsTimelineProperties)
            from winrt.windows.media.playback import MediaPlayer
            from winrt.windows.storage.streams import RandomAccessStreamReference
        except ImportError:                    # eski/alternatif: pip install winsdk
            from winsdk.windows.foundation import Uri
            from winsdk.windows.media import (MediaPlaybackStatus, MediaPlaybackType,
                                              SystemMediaTransportControlsButton,
                                              SystemMediaTransportControlsTimelineProperties)
            from winsdk.windows.media.playback import MediaPlayer
            from winsdk.windows.storage.streams import RandomAccessStreamReference
        self.Uri = Uri
        self.Status = MediaPlaybackStatus
        self.Type = MediaPlaybackType
        self.Button = SystemMediaTransportControlsButton
        self.Timeline = SystemMediaTransportControlsTimelineProperties
        self.MediaPlayer = MediaPlayer
        self.StreamRef = RandomAccessStreamReference


class _HotkeyFilter(QAbstractNativeEventFilter):
    def __init__(self, callback):
        super().__init__()
        self._callback = callback

    def nativeEventFilter(self, event_type, message):
        if bytes(event_type) in (b"windows_generic_MSG", b"windows_dispatcher_MSG"):
            from ctypes import wintypes
            msg = wintypes.MSG.from_address(int(message))
            if msg.message == WM_HOTKEY and msg.wParam in _VK:
                self._callback(_VK[msg.wParam])
                return True, 0
        return False, 0


class SystemMedia(QObject):
    play_pressed = pyqtSignal()
    pause_pressed = pyqtSignal()
    toggle_pressed = pyqtSignal()
    next_pressed = pyqtSignal()
    prev_pressed = pyqtSignal()
    stop_pressed = pyqtSignal()
    seek_requested = pyqtSignal(int)   # ms

    def __init__(self, parent=None):
        super().__init__(parent)
        self.backend = "yok"
        self._w = None
        self._mp = None
        self._smtc = None
        self._tokens = []
        self._filter = None
        if sys.platform != "win32":
            return
        if self._init_smtc():
            self.backend = "SMTC"
        elif self._init_hotkeys():
            self.backend = "Global kısayol"

    # =====================================================================
    # SMTC
    # =====================================================================
    def _init_smtc(self) -> bool:
        try:
            w = _WinRT()
            mp = w.MediaPlayer()
            mp.command_manager.is_enabled = False     # SMTC'yi biz yöneteceğiz
            smtc = mp.system_media_transport_controls
            smtc.is_enabled = True
            smtc.is_play_enabled = True
            smtc.is_pause_enabled = True
            smtc.is_next_enabled = True
            smtc.is_previous_enabled = True
            smtc.is_stop_enabled = True
            self._tokens.append(smtc.add_button_pressed(self._on_button))
            try:   # Windows medya penceresindeki ilerleme çubuğundan sarma
                self._tokens.append(smtc.add_playback_position_change_requested(self._on_seek))
            except Exception:
                pass
            smtc.display_updater.type = w.Type.MUSIC
            smtc.playback_status = w.Status.STOPPED
            self._w, self._mp, self._smtc = w, mp, smtc
            return True
        except Exception as exc:  # noqa: BLE001
            print(f"[NightWave] SMTC başlatılamadı: {exc!r}")
            return False

    def _on_button(self, _sender, args):
        B = self._w.Button
        b = args.button
        if b == B.PLAY:
            self.play_pressed.emit()
        elif b == B.PAUSE:
            self.pause_pressed.emit()
        elif b == B.NEXT:
            self.next_pressed.emit()
        elif b == B.PREVIOUS:
            self.prev_pressed.emit()
        elif b == B.STOP:
            self.stop_pressed.emit()

    def _on_seek(self, _sender, args):
        try:
            self.seek_requested.emit(int(args.requested_playback_position.total_seconds() * 1000))
        except Exception:  # noqa: BLE001
            pass

    # ---- uygulamadan SMTC'ye bilgi gönderme -----------------------------
    def set_track(self, track) -> None:
        if not self._smtc:
            return
        try:
            upd = self._smtc.display_updater
            upd.type = self._w.Type.MUSIC
            mus = upd.music_properties
            mus.title = track.title
            mus.artist = track.artist or ""
            if track.thumbnail.startswith("https://"):
                upd.thumbnail = self._w.StreamRef.create_from_uri(self._w.Uri(track.thumbnail))
            upd.update()
        except Exception as exc:  # noqa: BLE001
            print(f"[NightWave] SMTC bilgi güncellenemedi: {exc!r}")

    def set_playing(self, playing: bool) -> None:
        if self._smtc:
            try:
                self._smtc.playback_status = self._w.Status.PLAYING if playing else self._w.Status.PAUSED
            except Exception:  # noqa: BLE001
                pass

    def set_timeline(self, position_ms: int, duration_ms: int) -> None:
        if not self._smtc or duration_ms <= 0:
            return
        try:
            tl = self._w.Timeline()
            tl.start_time = timedelta(0)
            tl.min_seek_time = timedelta(0)
            tl.end_time = timedelta(milliseconds=duration_ms)
            tl.max_seek_time = timedelta(milliseconds=duration_ms)
            tl.position = timedelta(milliseconds=max(0, position_ms))
            self._smtc.update_timeline_properties(tl)
        except Exception:  # noqa: BLE001
            pass

    # =====================================================================
    # Yedek: global medya tuşları
    # =====================================================================
    def _init_hotkeys(self) -> bool:
        try:
            user32 = ctypes.windll.user32
            ok = [user32.RegisterHotKey(None, vk, MOD_NOREPEAT, vk) for vk in _VK]
            if not any(ok):
                return False
            self._filter = _HotkeyFilter(self._on_hotkey)
            QCoreApplication.instance().installNativeEventFilter(self._filter)
            return True
        except Exception as exc:  # noqa: BLE001
            print(f"[NightWave] Medya tuşları kaydedilemedi: {exc!r}")
            return False

    def _on_hotkey(self, name: str):
        {"play_pause": self.toggle_pressed, "next": self.next_pressed,
         "prev": self.prev_pressed, "stop": self.stop_pressed}[name].emit()

    # =====================================================================
    def shutdown(self) -> None:
        if self._filter is not None:
            try:
                QCoreApplication.instance().removeNativeEventFilter(self._filter)
                for vk in _VK:
                    ctypes.windll.user32.UnregisterHotKey(None, vk)
            except Exception:  # noqa: BLE001
                pass
            self._filter = None
        if self._smtc is not None:
            try:
                self._smtc.is_enabled = False
                self._mp.close()
            except Exception:  # noqa: BLE001
                pass
            self._smtc = self._mp = None
        self.backend = "yok"
