"""Müzik görselleştirici için ses analizi (numpy). Qt'ye bağımlı değildir, bu yüzden test edilebilir.

SpectrumAnalyzer : ses örneklerinden (FFT) logaritmik frekans bantları üretir (0..1)
simulate         : gerçek ses verisi yoksa müziğin ritmine benzeyen sahte spektrum üretir
VizEngine        : gerçek analiz <-> simülasyon seçimi, vuruş (beat) algılama
"""
import zlib
from typing import NamedTuple

import numpy as np

WAVE_POINTS = 200


class Frame(NamedTuple):
    bands: np.ndarray   # 0..1, bant sayısı kadar
    wave: np.ndarray    # -1..1, WAVE_POINTS nokta
    beat: float         # 0..1: bas vuruşu şiddeti
    kind: str           # "real" (gerçek ses analizi) | "sim" (simülasyon)


class SpectrumAnalyzer:
    def __init__(self, bands: int = 64, fft_size: int = 2048, fmin: float = 35.0,
                 fmax: float = 16000.0, floor_db: float = -72.0, tilt_db_per_oct: float = 2.0):
        self.bands = bands
        self.n = fft_size
        self.fmin, self.fmax = fmin, fmax
        self.floor_db = floor_db
        self.tilt = tilt_db_per_oct
        self._window = np.hanning(fft_size).astype(np.float32)
        self._norm = 2.0 / float(self._window.sum())      # tam ölçekli sinüs -> genlik 1.0
        self._layouts: dict = {}

    def set_bands(self, n: int) -> None:
        self.bands = int(n)

    def _layout(self, sr: int):
        key = (sr, self.bands)
        if key not in self._layouts:
            freqs = np.fft.rfftfreq(self.n, 1.0 / sr)
            top = min(self.fmax, sr / 2 * 0.98)
            edges = np.geomspace(self.fmin, top, self.bands + 1)
            lo = np.searchsorted(freqs, edges[:-1])
            hi = np.maximum(np.searchsorted(freqs, edges[1:]), lo + 1)      # her banda en az 1 bin
            centers = np.sqrt(edges[:-1] * edges[1:])
            tilt_db = self.tilt * np.log2(centers / 400.0)                   # tizleri hafifçe yükselt
            self._layouts[key] = (lo.tolist(), hi.tolist(), tilt_db.astype(np.float32))
        return self._layouts[key]

    def spectrum(self, samples: np.ndarray, sr: int) -> np.ndarray:
        x = samples[-self.n:]
        if len(x) < self.n:
            x = np.concatenate([np.zeros(self.n - len(x), np.float32), x])
        mag = np.abs(np.fft.rfft(x * self._window)) * self._norm
        lo, hi, tilt_db = self._layout(sr)
        vals = np.fromiter((mag[a:b].max() for a, b in zip(lo, hi)), np.float32, self.bands)
        db = 20.0 * np.log10(vals + 1e-9) + tilt_db
        return np.clip((db - self.floor_db) / (-self.floor_db), 0.0, 1.0).astype(np.float32)

    @staticmethod
    def waveform(samples: np.ndarray, n: int = WAVE_POINTS) -> np.ndarray:
        """Son örnekleri n noktaya indirger (osiloskop çizgisi için)."""
        need = (1024 // n) * n or n
        x = samples[-need:]
        if len(x) < need:
            x = np.concatenate([np.zeros(need - len(x), np.float32), x])
        return x.reshape(n, -1).mean(axis=1).astype(np.float32)


def simulate(position_ms: int, seed: int, bands: int, playing: bool = True):
    """Gerçek ses yokken: parçanın konumuna bağlı, ritmik ve bas ağırlıklı sahte spektrum.

    Aynı parça + aynı konum her zaman aynı görüntüyü verir (seed parçadan türetilir).
    Döner: (bantlar, dalga, vuruş)
    """
    t = position_ms / 1000.0
    bpm = 92 + (seed % 48)
    kick = float(np.exp(-((t * bpm / 60.0) % 1.0) * 5.5))
    hat = float(np.exp(-((t * bpm / 30.0) % 1.0) * 9.0))
    f = np.linspace(0.0, 1.0, bands)
    rng = np.random.default_rng((int(t * 30) * 2654435761 + seed) & 0xFFFFFFFF)
    lv = (0.50 * (1 - f) ** 1.6 + 0.10
          + 0.12 * np.sin(t * 2.3 + f * 9 + seed * 0.1) + 0.08 * np.sin(t * 5.1 - f * 14)
          + kick * 0.42 * np.exp(-f * 5) + hat * 0.30 * f ** 1.2
          + rng.random(bands) * 0.06)
    lv = np.clip(lv, 0, 1) if playing else np.zeros(bands)
    x = np.linspace(0, 1, WAVE_POINTS)
    wave = (np.sin(x * 8 * np.pi + t * 7) * (0.25 + 0.5 * kick)
            + 0.2 * hat * np.sin(x * 23 * np.pi - t * 11)) if playing else np.zeros(WAVE_POINTS)
    return lv.astype(np.float32), wave.astype(np.float32), kick


class VizEngine:
    """Her karede: gerçek ses varsa onu analiz eder, yoksa simüle eder."""

    def __init__(self, tap=None, bands: int = 64):
        self.tap = tap
        self.analyzer = SpectrumAnalyzer(bands)
        self._avg_bass = 0.0
        self._beat = 0.0

    def set_bands(self, n: int) -> None:
        self.analyzer.set_bands(n)

    def frame(self, position_ms: int, playing: bool, track_id: str = "") -> Frame:
        bands = self.analyzer.bands
        if not playing:                                    # duraklatılmış: sessiz çizgi
            self._beat *= 0.8
            return Frame(np.zeros(bands, np.float32), np.zeros(WAVE_POINTS, np.float32),
                         self._beat, self.kind_hint())
        win = None
        if self.tap is not None and self.tap.ok and self.tap.has_data():
            win = self.tap.window(position_ms, self.analyzer.n)
        if win is not None:
            samples, sr = win
            lv = self.analyzer.spectrum(samples, sr)
            wave = self.analyzer.waveform(samples)
            n_bass = max(2, bands // 10)
            bass = float(lv[:n_bass].mean())
            self._avg_bass = 0.96 * self._avg_bass + 0.04 * bass
            kick = min(1.0, max(0.0, bass - self._avg_bass * 1.12) * 3.5)
            self._beat = max(self._beat * 0.88, kick)
            return Frame(lv, wave, self._beat, "real")
        lv, wave, kick = simulate(position_ms, zlib.crc32(track_id.encode()), bands, True)
        self._beat = kick
        return Frame(lv, wave, kick, "sim")

    def kind_hint(self) -> str:
        return "real" if (self.tap is not None and self.tap.ok and self.tap.has_data()) else "sim"
