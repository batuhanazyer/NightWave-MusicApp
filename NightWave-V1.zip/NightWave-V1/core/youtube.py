"""yt-dlp ile arama, akış (stream) adresi çözme ve MP3 indirme.

Reklamsız çalma mantığı: Tarayıcıdaki YouTube oynatıcısını değil, yt-dlp'nin
bulduğu *doğrudan ses akışı* adresini oynatıyoruz. Bu adreste reklam yoktur.

YouTube artık akış adreslerini çözmek için bir JavaScript çalışma zamanı (Deno önerilir)
istiyor. Bulunan çalışma zamanının yolunu yt-dlp'ye kendimiz veriyoruz (PATH'te olmasa da çalışır).
"""
import re
import threading
import time
from pathlib import Path

import yt_dlp

from . import errors, health, progressive
from .models import Track

_BASE_OPTS = {
    "quiet": True,
    "no_warnings": True,
    "noplaylist": True,
    "socket_timeout": 15,
    "noprogress": True,            # yt-dlp'nin kendi ilerleme çubuğunu konsola yazmasın
}
NET = {"force_ipv4": False}        # Ayarlar > Müzik: bazı ağlarda IPv6 YouTube'u çok yavaşlatır


def configure(force_ipv4: bool = False) -> None:
    NET["force_ipv4"] = bool(force_ipv4)

FORMAT_DEFAULT = "bestaudio[ext=m4a]/bestaudio/best"
FORMAT_PROGRESSIVE = "bestaudio[ext=m4a]/bestaudio"   # indirirken çal: ham ses (dönüştürme yok)
PROGRESSIVE_START_BYTES = 320_000                    # ~20 sn ses: Qt'nin açması için yeterli
FORMAT_CACHE = "bestaudio[ext=m4a]/bestaudio/best"   # önbellek: ses-only, dönüştürme yok (FFmpeg gerekmez)
FORMAT_ALT = "18/bestaudio/best"        # 18 = klasik MP4 (AAC sesli); en uyumlu yedek
_VIDEO_ID = re.compile(r"^[A-Za-z0-9_-]{11}$")


def _make_ydl(js: bool = False, **extra) -> "yt_dlp.YoutubeDL":
    """YoutubeDL nesnesi. js=True: akış çözme/indirme için JS çalışma zamanını da ayarlar."""
    opts = {**_BASE_OPTS, **extra}
    if js:
        runtimes = health.find_js_runtimes()
        if runtimes:
            opts["js_runtimes"] = {name: {"path": path} for name, path in runtimes.items()}
    if NET["force_ipv4"]:
        opts["source_address"] = "0.0.0.0"
    try:
        return yt_dlp.YoutubeDL(opts)
    except Exception:  # noqa: BLE001 - beklenmedik js_runtimes biçimi: onsuz tekrar dene
        opts.pop("js_runtimes", None)
        return yt_dlp.YoutubeDL(opts)


class _CollectLog:
    """yt-dlp'nin UYARILARINI toplar: 'JS çözücü çalışmıyor' gibi yavaşlık nedenlerini yakalamak için."""

    def __init__(self):
        self.warnings: list[str] = []

    def debug(self, msg):
        pass

    def info(self, msg):
        pass

    def warning(self, msg):
        self.warnings.append(str(msg))

    def error(self, msg):
        self.warnings.append(str(msg))


def _fmt_speed(bps) -> str:
    if not bps:
        return ""
    return f"{bps / 1048576:.1f} MB/s" if bps >= 1048576 else f"{bps / 1024:.0f} KB/s"


def _progress_text(done: int, total: int, speed) -> str:
    pct = f" %{min(99, int(done * 100 / total))}" if total else ""
    sp = f" · {_fmt_speed(speed)}" if speed else ""
    slow = " · yavaş" if speed and speed < 120_000 and done > 300_000 else ""
    return f"Hazırlanıyor…{pct}{sp}{slow}"


def _report(track: Track, log: "_CollectLog", t_resolve: float, t_download: float, speed) -> None:
    """Konsola kısa zaman dökümü: yavaşlığın NEREDE olduğunu görmek için (çözümleme mi, indirme mi)."""
    hint = errors.warning_hint("\n".join(log.warnings))
    print(f"[NightWave] {track.title[:40]!r}: çözümleme {t_resolve:.1f} sn · indirme {t_download:.1f} sn"
          + (f" ({_fmt_speed(speed)})" if speed else "") + (f"\n[NightWave] UYARI: {hint}" if hint else ""))


def _explain(exc: Exception) -> Exception:
    """JS çalışma zamanı yoksa, asıl nedeni (belirsiz yt-dlp hatası yerine) açıkça söyle."""
    if not health.find_js_runtimes():
        return RuntimeError(errors.MSG_JS)
    return exc


# ---------------------------------------------------------------------------
# Arama (JS çalışma zamanı gerekmez)
# ---------------------------------------------------------------------------
def _entries_to_tracks(info) -> list[Track]:
    tracks = []
    for e in (info or {}).get("entries") or []:
        if not e or not e.get("id"):
            continue
        thumbs = e.get("thumbnails") or []
        tracks.append(Track(
            id=e["id"],
            title=e.get("title") or "Adsız",
            artist=e.get("channel") or e.get("uploader") or "",
            duration=int(e.get("duration") or 0),
            thumbnail=thumbs[-1]["url"] if thumbs else "",
            source="youtube",
            url=e.get("url") or f"https://www.youtube.com/watch?v={e['id']}",
        ))
    return tracks


def search(query: str, limit: int = 20) -> list[Track]:
    """YouTube'da arar; sadece üst veriyi çeker (hızlıdır)."""
    with _make_ydl(extract_flat=True, skip_download=True) as ydl:
        info = ydl.extract_info(f"ytsearch{limit}:{query}", download=False)
    return _entries_to_tracks(info)


def related(video_id: str, limit: int = 25) -> list[Track]:
    """YouTube'un otomatik "Mix" (radyo) listesi: bir şarkıya benzer parçalar."""
    if not _VIDEO_ID.match(video_id or ""):
        raise ValueError("Geçersiz video kimliği.")
    with _make_ydl(noplaylist=False, extract_flat=True, skip_download=True,
                   playlistend=limit + 1) as ydl:
        info = ydl.extract_info(
            f"https://www.youtube.com/watch?v={video_id}&list=RD{video_id}", download=False)
    return [t for t in _entries_to_tracks(info) if t.id != video_id]


# ---------------------------------------------------------------------------
# Akış (JS çalışma zamanı gerekir)
# ---------------------------------------------------------------------------
def _target(track: Track) -> str:
    """YouTube parçası için doğrudan URL; Spotify parçası için arama ifadesi."""
    if track.source == "youtube" and track.url:
        return track.url
    return f"ytsearch1:{track.query or f'{track.artist} - {track.title}'}"


def resolve_stream(track: Track, alt: bool = False) -> str:
    """Parçanın doğrudan ses akışı URL'sini döndürür (indirme yapmaz).

    alt=True: ilk format çalınamadıysa denenen daha uyumlu yedek format.
    """
    try:
        with _make_ydl(js=True, format=FORMAT_ALT if alt else FORMAT_DEFAULT) as ydl:
            info = ydl.extract_info(_target(track), download=False)
        if info and info.get("entries"):
            info = info["entries"][0]
        if not info or not info.get("url"):
            raise RuntimeError("Bu parça için oynatılabilir bir akış bulunamadı.")
        return info["url"]
    except Exception as exc:  # noqa: BLE001
        raise _explain(exc) from exc


# ---------------------------------------------------------------------------
# Önbelleğe indirip yerelden çalma (en güvenilir yol)
# ---------------------------------------------------------------------------
_locks: dict[str, threading.Lock] = {}
_locks_guard = threading.Lock()


def _lock_for(name: str) -> threading.Lock:
    """Aynı parçayı aynı anda iki kez indirmeyi (ön yükleme + kullanıcı tıklaması) engeller."""
    with _locks_guard:
        return _locks.setdefault(name, threading.Lock())


def _cancel_exc():
    try:
        from yt_dlp.utils import DownloadCancelled
        return DownloadCancelled
    except Exception:  # noqa: BLE001
        return RuntimeError


def _cache_opts(cache, base: str, fmt: str, hook, log) -> dict:
    return dict(
        js=True, format=fmt, logger=log, no_warnings=False,
        outtmpl=str(cache.dir / base).replace("%", "%%") + ".%(ext)s",
        progress_hooks=[hook],
    )


def fetch_audio(track: Track, cache, progress=None, cancelled=None, stage=None) -> Path:
    """Parçanın sesini önbelleğe MP3 olarak indirir (tamamı inince döner). Zaten varsa hemen döner.

    progress(0-100) · stage("Hazırlanıyor… %40 · 1.2 MB/s") · cancelled(): True dönerse iptal.
    """
    base = cache.base_name(track.id)
    ffmpeg = health.find_ffmpeg()
    with _lock_for(base):
        found = cache.path_for(track.id, mp3_only=bool(ffmpeg))
        if found:
            cache.touch(found)
            return found
        cache.dir.mkdir(parents=True, exist_ok=True)
        cancel_exc, log = _cancel_exc(), _CollectLog()
        t0 = time.monotonic()
        mark = {"dl": None, "speed": None}
        if stage:
            stage("Çözümleniyor…")

        def hook(d):
            if cancelled and cancelled():
                raise cancel_exc()
            if d.get("status") != "downloading":
                return
            if mark["dl"] is None:
                mark["dl"] = time.monotonic()
            done = int(d.get("downloaded_bytes") or 0)
            total = int(d.get("total_bytes") or d.get("total_bytes_estimate") or 0)
            mark["speed"] = d.get("speed") or mark["speed"]
            if progress and total:
                progress(min(99, int(done * 100 / total)))
            if stage:
                stage(_progress_text(done, total, d.get("speed")))

        opts = _cache_opts(cache, base, FORMAT_CACHE, hook, log)
        if ffmpeg:
            # Ham m4a/webm (bölünmüş MP4) bazı sistemlerde Qt'de çalmıyor. MP3: İndir düğmesinin ürettiği,
            # kanıtlanmış şekilde çalan biçim.
            opts["ffmpeg_location"] = str(Path(ffmpeg).parent)
            opts["postprocessors"] = [{"key": "FFmpegExtractAudio", "preferredcodec": "mp3",
                                       "preferredquality": "160"}]
            opts["postprocessor_hooks"] = [
                lambda d: stage("MP3'e çevriliyor…") if stage and d.get("status") == "started" else None]
        try:
            with _make_ydl(**opts) as ydl:
                ydl.extract_info(_target(track), download=True)
        except cancel_exc as exc:
            raise errors.Cancelled("İptal edildi") from exc
        except Exception as exc:  # noqa: BLE001
            if not cache.path_for(track.id):              # dönüştürme çökse de ham dosya kaldıysa onu kullan
                raise _explain(exc) from exc

        found = cache.path_for(track.id)
        if not found:
            raise RuntimeError("Ses indirildi ama önbellekte dosya bulunamadı.")
        cache.trim(keep=found)
        t1 = time.monotonic()
        _report(track, log, (mark["dl"] or t1) - t0, t1 - (mark["dl"] or t1), mark["speed"])
        if progress:
            progress(100)
        return found


def fetch_progressive(track: Track, cache, on_ready, stage=None, cancelled=None,
                      start_bytes: int = PROGRESSIVE_START_BYTES) -> Path:
    """İNDİRİRKEN ÇAL: ham sesi indirir; ilk `start_bytes` gelince `on_ready(yerel_url)` çağrılır.

    Oynatıcı o adresten (yerel sunucu, bkz. progressive.py) hemen çalmaya başlar; indirme sürerken
    dosya büyür. Tamamı inince dosya yolunu döndürür. Önbellekte zaten varsa on_ready ÇAĞRILMAZ,
    doğrudan yol döner (çağıran yerelden çalar).
    """
    base = cache.base_name(track.id)
    with _lock_for(base):
        found = cache.path_for(track.id)
        if found:
            cache.touch(found)
            return found
        cache.dir.mkdir(parents=True, exist_ok=True)
        cancel_exc, log = _cancel_exc(), _CollectLog()
        t0 = time.monotonic()
        state = {"stream": None, "dl": None, "speed": None}
        if stage:
            stage("Çözümleniyor…")

        def hook(d):
            if cancelled and cancelled():
                raise cancel_exc()
            if d.get("status") != "downloading":
                return
            if state["dl"] is None:
                state["dl"] = time.monotonic()
            done = int(d.get("downloaded_bytes") or 0)
            exact = d.get("total_bytes")                       # KESİN toplam (tahmin Content-Length için yetmez)
            total = int(exact or d.get("total_bytes_estimate") or 0)
            state["speed"] = d.get("speed") or state["speed"]
            if state["stream"] is None:
                if stage:
                    stage(_progress_text(done, total, d.get("speed")))
                if done >= start_bytes and d.get("tmpfilename") and d.get("filename"):
                    tmp, fin = Path(d["tmpfilename"]), Path(d["filename"])
                    state["stream"] = progressive.Stream(
                        lambda: progressive.existing(tmp, fin),
                        total=int(exact) if exact else None, ext=fin.suffix.lstrip(".") or "m4a")
                    on_ready(progressive.server().register(state["stream"]))

        try:
            with _make_ydl(**_cache_opts(cache, base, FORMAT_PROGRESSIVE, hook, log)) as ydl:
                ydl.extract_info(_target(track), download=True)
        except cancel_exc as exc:
            raise errors.Cancelled("İptal edildi") from exc
        except Exception as exc:  # noqa: BLE001
            if state["stream"] is not None:
                state["stream"].failed = True
            raise _explain(exc) from exc
        finally:
            if state["stream"] is not None:
                state["stream"].done.set()                     # sunucu: artık büyümeyecek

        found = cache.path_for(track.id)
        if not found:
            raise RuntimeError("Ses indirildi ama önbellekte dosya bulunamadı.")
        cache.trim(keep=found)
        t1 = time.monotonic()
        _report(track, log, (state["dl"] or t1) - t0, t1 - (state["dl"] or t1), state["speed"])
        return found


# ---------------------------------------------------------------------------
# İndirme (JS çalışma zamanı + FFmpeg gerekir)
# ---------------------------------------------------------------------------
def _safe_name(name: str) -> str:
    name = re.sub(r'[\\/:*?"<>|]+', " ", name)
    return re.sub(r"\s+", " ", name).strip(" .")[:150] or "parca"


def download(track: Track, dest_dir: Path, progress=None) -> Path:
    """Parçayı MP3 olarak indirir. `progress(0-100)` çağrılır."""
    ffmpeg = health.find_ffmpeg()
    if not ffmpeg:
        raise RuntimeError(errors.MSG_FFMPEG)
    dest_dir.mkdir(parents=True, exist_ok=True)

    base = _safe_name(f"{track.artist} - {track.title}" if track.artist else track.title)
    final = dest_dir / f"{base}.mp3"
    # outtmpl'de '%' özel karakterdir, kaçırıyoruz.
    outtmpl = str(dest_dir / base).replace("%", "%%") + ".%(ext)s"

    def hook(d):
        if progress and d.get("status") == "downloading":
            total = d.get("total_bytes") or d.get("total_bytes_estimate") or 0
            if total:
                # %95'e kadar indirme, kalanı MP3'e dönüştürme payı
                progress(min(95, int(d.get("downloaded_bytes", 0) * 95 / total)))

    try:
        with _make_ydl(
            js=True,
            format="bestaudio/best",
            outtmpl=outtmpl,
            progress_hooks=[hook],
            ffmpeg_location=str(Path(ffmpeg).parent),
            postprocessors=[
                {"key": "FFmpegExtractAudio", "preferredcodec": "mp3", "preferredquality": "192"},
                {"key": "FFmpegMetadata", "add_metadata": True},
            ],
        ) as ydl:
            ydl.extract_info(_target(track), download=True)
    except Exception as exc:  # noqa: BLE001
        raise _explain(exc) from exc

    if not final.exists():
        raise RuntimeError("İndirme tamamlandı ama MP3 dosyası oluşturulamadı.")
    if progress:
        progress(100)
    return final
