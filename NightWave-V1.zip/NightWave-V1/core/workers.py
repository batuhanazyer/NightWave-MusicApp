"""Ağ/yt-dlp işlerini arayüzü dondurmadan arka planda çalıştırmak için yardımcı.

Kullanım:
    run_async(fonksiyon, arg1, arg2,
              on_result=..., on_error=..., on_progress=...)
`on_progress` verilirse fonksiyona `progress=` adlı bir geri çağrı (callback) geçilir.
Geri çağrılar her zaman ana (arayüz) iş parçacığında çalışır.
"""
import traceback

from PyQt6.QtCore import QObject, QRunnable, QThreadPool, pyqtSignal

from .errors import Cancelled, friendly_error

_alive: set = set()  # Çalışan işlerin çöp toplayıcıya kaptırılmaması için


class _Signals(QObject):
    result = pyqtSignal(object)
    error = pyqtSignal(str)
    progress = pyqtSignal(int)
    finished = pyqtSignal()


class _Worker(QRunnable):
    def __init__(self, fn, args, kwargs, pass_progress):
        super().__init__()
        self.setAutoDelete(False)
        self.fn, self.args, self.kwargs = fn, args, kwargs
        self.pass_progress = pass_progress
        self.signals = _Signals()

    def run(self):
        try:
            if self.pass_progress:
                self.kwargs["progress"] = self.signals.progress.emit
            result = self.fn(*self.args, **self.kwargs)
        except Cancelled:
            pass                       # bilerek iptal edildi: hata değil, konsola da yazma
        except Exception as exc:  # noqa: BLE001 - kullanıcıya mesaj göstereceğiz
            traceback.print_exc()      # ayrıntı konsolda kalsın (hata ayıklama için)
            self.signals.error.emit(friendly_error(exc))
        else:
            self.signals.result.emit(result)
        finally:
            self.signals.finished.emit()


def run_async(fn, *args, on_result=None, on_error=None, on_progress=None, **kwargs):
    worker = _Worker(fn, args, kwargs, pass_progress=on_progress is not None)
    if on_result:
        worker.signals.result.connect(on_result)
    if on_error:
        worker.signals.error.connect(on_error)
    if on_progress:
        worker.signals.progress.connect(on_progress)
    worker.signals.finished.connect(lambda: _alive.discard(worker))
    _alive.add(worker)
    QThreadPool.globalInstance().start(worker)
    return worker
