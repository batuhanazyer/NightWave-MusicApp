"""Çalma sırası (karışık çalma mantığı). Qt'ye bağımlı değildir, bu yüzden kolay test edilir.

`items`, kuyruktaki parçaların *indekslerinin* çalınma sırasıdır.
Karışık kapalıyken 0,1,2,...; açıkken rastgele bir permütasyon olur.
"""
import random


class PlayOrder:
    def __init__(self):
        self.items: list[int] = []
        self.shuffle = False

    def rebuild(self, size: int, first: int | None = None) -> None:
        """Sırayı yeniden kurar. Karışıkta `first` her zaman başa alınır."""
        idx = list(range(size))
        if self.shuffle and size > 1:
            head = [first] if first is not None and 0 <= first < size else []
            rest = [i for i in idx if i not in head]
            random.shuffle(rest)
            self.items = head + rest
        else:
            self.items = idx

    def pos(self, current: int) -> int:
        try:
            return self.items.index(current)
        except ValueError:
            return -1

    def next(self, current: int, wrap: bool) -> int | None:
        """Sıradaki parça indeksi. Liste bittiyse ve wrap=False ise None döner."""
        if not self.items:
            return None
        p = self.pos(current) + 1
        if p < len(self.items):
            return self.items[p]
        if not wrap:
            return None
        if self.shuffle:                      # yeni bir rastgele tur başlat
            self.rebuild(len(self.items))
            if len(self.items) > 1 and self.items[0] == current:
                self.items[0], self.items[1] = self.items[1], self.items[0]
        return self.items[0]

    def prev(self, current: int) -> int | None:
        if not self.items:
            return None
        p = self.pos(current) - 1
        return self.items[p] if p >= 0 else self.items[-1]

    def add(self, idx: int, after: int | None = None) -> None:
        """Yeni parçayı `after` parçasının hemen sonrasına (ya da sona) ekler."""
        if after is not None and after in self.items:
            self.items.insert(self.items.index(after) + 1, idx)
        else:
            self.items.append(idx)

    def from_pos(self, current: int) -> list[int]:
        """Şu anki parçadan itibaren kalan sıra."""
        return self.items[max(self.pos(current), 0):]
