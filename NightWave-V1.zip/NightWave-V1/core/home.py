"""Ana sayfa içeriği: tür listesi, raf filtreleme, önbellek ve selamlama. Ağ/Qt gerektirmez (test edilebilir)."""
import json
import re
import time
from pathlib import Path

from .models import Track

# (anahtar, başlık, YouTube arama ifadesi)
GENRES = [
    ("turkce_pop", "Türkçe Pop", "Türkçe pop hit şarkılar official audio"),
    ("turkce_rap", "Türkçe Rap", "Türkçe rap hit şarkılar official audio"),
    ("global", "Dünyada Popüler", "top global pop hits official audio"),
    ("yeni", "Yeni Çıkanlar", "new music friday official audio"),
    ("rock", "Rock", "best rock songs official audio"),
    ("elektronik", "Elektronik", "electronic dance hits official audio"),
    ("hiphop", "Hip-Hop", "hip hop hits official audio"),
    ("lofi", "Rahatlatıcı · Lo-fi", "lofi hip hop chill beats"),
    ("akustik", "Akustik", "acoustic songs official audio"),
    ("klasik", "Piyano & Enstrümantal", "relaxing piano instrumental music"),
    ("antrenman", "Antrenman", "workout gym motivation music"),
    ("arabesk", "Arabesk · Slow", "arabesk slow şarkılar official audio"),
]
GENRE_MAP = {k: (title, query) for k, title, query in GENRES}
DEFAULT_GENRES = ["turkce_pop", "global", "yeni", "lofi", "turkce_rap"]

SHELF_TTL = 4 * 3600          # sn: önbellekteki raf bu kadar tazedir
SHELF_SIZE = 18
MIN_SEC, MAX_SEC = 45, 720
_BAD = re.compile(r"\b(playlist|compilation|nonstop|non-stop|full album|best of|reaction|karaoke|tutorial|"
                  r"mix|hours?|saat|top \d+|tam albüm|derleme)\b", re.I)


def greeting(hour: int) -> str:
    if hour < 5:
        return "İyi geceler"
    if hour < 12:
        return "Günaydın"
    if hour < 18:
        return "İyi günler"
    return "İyi akşamlar"


def clean_shelf(tracks: list[Track], limit: int = SHELF_SIZE) -> list[Track]:
    """Tekrarları, derlemeleri/mix'leri ve çok uzun/kısa videoları eler."""
    seen, out = set(), []
    for t in tracks:
        if t.id in seen or _BAD.search(t.title):
            continue
        if t.duration and not (MIN_SEC <= t.duration <= MAX_SEC):
            continue
        seen.add(t.id)
        out.append(t)
        if len(out) >= limit:
            break
    return out


def valid_genres(keys) -> list[str]:
    ok = [k for k in (keys or []) if k in GENRE_MAP]
    return ok or list(DEFAULT_GENRES)


class HomeCache:
    """Raf içeriklerini diske yazar: uygulama açılır açılmaz (internet beklemeden) ana sayfa dolu görünsün."""

    def __init__(self, file: Path):
        self.file = Path(file)
        self._d: dict = {}
        try:
            data = json.loads(self.file.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                self._d = data
        except (OSError, ValueError):
            pass

    def get(self, key: str):
        """(parça listesi, kaydedilme zamanı) ya da None"""
        e = self._d.get(key)
        if not isinstance(e, dict) or not isinstance(e.get("tracks"), list):
            return None
        try:
            return [Track.from_dict(t) for t in e["tracks"] if isinstance(t, dict)], float(e.get("t", 0))
        except (TypeError, ValueError):
            return None

    def put(self, key: str, tracks: list[Track]) -> None:
        self._d[key] = {"t": time.time(), "tracks": [t.to_dict() for t in tracks]}
        try:
            self.file.write_text(json.dumps(self._d, ensure_ascii=False), encoding="utf-8")
        except OSError:
            pass

    def is_fresh(self, key: str, ttl: float = SHELF_TTL) -> bool:
        got = self.get(key)
        return bool(got and got[0] and time.time() - got[1] < ttl)

    def clear(self) -> None:
        self._d.clear()
        try:
            self.file.unlink(missing_ok=True)
        except OSError:
            pass
