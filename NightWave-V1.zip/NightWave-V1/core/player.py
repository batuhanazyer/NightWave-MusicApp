"""Ses motoru: QMediaPlayer + çalma kuyruğu + karışık/tekrar modları.

- Parça indirilmişse yerel dosyayı çalar (çevrimdışı da çalışır).
- Değilse yt-dlp ile ses akış adresini çözer ve indirmeden stream eder.
- Çalma sırası `PlayOrder` ile yönetilir (karışık çalma mantığı orada).
"""
import os
from pathlib import Path

from PyQt6.QtCore import QObject, QTimer, QUrl, pyqtSignal
from PyQt6.QtMultimedia import QAudioOutput, QMediaPlayer

from . import health, progressive, youtube
from .audio_tap import AudioTap
from .models import Track
from .play_order import PlayOrder
from .workers import run_async

REPEAT_MODES = ("off", "all", "one")


class Player(QObject):
    track_changed = pyqtSignal(object)     # Track
    playing_changed = pyqtSignal(bool)     # çalıyor mu?
    position_changed = pyqtSignal(int)     # ms
    duration_changed = pyqtSignal(int)     # ms
    modes_changed = pyqtSignal(bool, str)  # karışık, tekrar ("off" | "all" | "one")
    queue_changed = pyqtSignal()
    status_message = pyqtSignal(str)       # "Akış hazırlanıyor…" gibi
    error = pyqtSignal(str)
    raw_failed = pyqtSignal()              # ham ses Qt'de çalınamadı: MP3'e geçildi (Ayarlar'a kaydedilir)
    _ready_sig = pyqtSignal(str, int)      # (iç) indirirken çal: yerel URL hazır, parça jetonu
    _stage_sig = pyqtSignal(str, int)      # (iç) hazırlık aşaması/hız metni, parça jetonu

    def __init__(self, parent=None):
        super().__init__(parent)
        self._audio = QAudioOutput()
        self._media = QMediaPlayer()
        self._media.setAudioOutput(self._audio)
        self.tap = AudioTap(self._media, self)   # görselleştirici için gerçek ses örnekleri (isteğe bağlı)

        self.queue: list[Track] = []
        self.index = -1                 # kuyruktaki (depolama) indeksi
        self.order = PlayOrder()
        self.repeat = "off"
        self._token = 0                 # eski (gecikmiş) akış yanıtlarını yok saymak için
        self._streaming = False         # çalan kaynak internetten akıyor mu?
        self._retried = False           # yedek format bu parça için denendi mi?
        self._fallback_used = False     # akış başarısız olunca önbellek yoluna düşüldü mü?
        self._from_cache = False        # çalan dosya önbellekten mi?
        self._inflight: set = set()     # arka planda hazırlanan (ön yükleme) parçalar
        self.cache = None               # AudioCache (MainWindow atar)
        self.play_mode = "cache"        # "cache": indir+yerelden çal (güvenilir) | "stream": doğrudan akış
        self.prefetch = True            # sıradaki şarkıyı önceden hazırla
        self.progressive = True         # İNDİRİRKEN ÇAL: birkaç yüz KB gelince başla (tamamını bekleme)
        self.raw_ok = True              # ham (m4a/webm) ses Qt'de çalıyor mu? Çalmazsa False olur, MP3'e geçilir
        self._prog_active = False       # şu an indirilmekte olan dosyadan mı çalıyor?
        self._await_full = False        # indirirken-çal başarısız: tamamı inince yerelden çalınacak
        self._cached_path = None        # bu parçanın indirme tamamlanmış yolu
        self._prog_url = ""
        self._watchdog = QTimer(self)   # indirirken çal başladı ama ses gelmiyorsa yedeğe düş
        self._watchdog.setSingleShot(True)
        self._watchdog.timeout.connect(self._on_watchdog)
        self._ready_sig.connect(self._on_progressive_ready)
        self._stage_sig.connect(self._on_stage)
        self.local_resolver = None      # track_id -> yerel yol | None

        # qint64 -> int sinyalleri doğrudan bağlanamaz; araya küçük bir dönüştürücü koyuyoruz
        self._media.positionChanged.connect(self._on_position)
        self._media.durationChanged.connect(lambda ms: self.duration_changed.emit(int(ms)))
        self._media.playbackStateChanged.connect(self._on_state)
        self._media.mediaStatusChanged.connect(self._on_status)
        self._media.errorOccurred.connect(self._on_error)

    # --- durum -----------------------------------------------------------
    @property
    def is_playing(self) -> bool:
        return self._media.playbackState() == QMediaPlayer.PlaybackState.PlayingState

    @property
    def shuffle(self) -> bool:
        return self.order.shuffle

    def position(self) -> int:
        return self._media.position()

    def current_track(self) -> Track | None:
        return self.queue[self.index] if 0 <= self.index < len(self.queue) else None

    def queue_tracks(self) -> list[Track]:
        """Şu anki parçadan başlayarak çalma sırasındaki parçalar."""
        return [self.queue[i] for i in self.order.from_pos(self.index)]

    # --- kuyruk ----------------------------------------------------------
    def set_queue(self, tracks: list[Track], start: int = 0, shuffle: bool | None = None) -> None:
        self.queue = list(tracks)
        if shuffle is not None:
            self.order.shuffle = shuffle
            self.modes_changed.emit(self.order.shuffle, self.repeat)
        start = start if 0 <= start < len(self.queue) else 0
        self.order.rebuild(len(self.queue), first=start)
        self.queue_changed.emit()
        self.play_index(start)

    def play_shuffled(self, tracks: list[Track]) -> None:
        """Listeyi karışık modda, rastgele bir parçadan başlatır."""
        import random
        if tracks:
            self.set_queue(tracks, random.randrange(len(tracks)), shuffle=True)

    def enqueue(self, track: Track, play_next: bool = False) -> None:
        """Kuyruğa ekler; play_next=True ise çalan parçanın hemen sonrasına koyar."""
        self.queue.append(track)
        idx = len(self.queue) - 1
        after = self.index if (play_next and self.index >= 0) else None
        self.order.add(idx, after=after)
        self.queue_changed.emit()

    def jump(self, offset: int) -> None:
        """Kuyruk görünümünde `offset`. satıra (0 = çalan) atlar."""
        idxs = self.order.from_pos(self.index)
        if 0 <= offset < len(idxs):
            self.play_index(idxs[offset])

    # --- modlar ----------------------------------------------------------
    def set_modes(self, shuffle: bool, repeat: str) -> None:
        self.order.shuffle = bool(shuffle)
        self.repeat = repeat if repeat in REPEAT_MODES else "off"
        self.order.rebuild(len(self.queue), first=self.index if self.index >= 0 else None)
        self.modes_changed.emit(self.order.shuffle, self.repeat)
        self.queue_changed.emit()

    def toggle_shuffle(self) -> None:
        self.set_modes(not self.order.shuffle, self.repeat)

    def cycle_repeat(self) -> None:
        nxt = REPEAT_MODES[(REPEAT_MODES.index(self.repeat) + 1) % len(REPEAT_MODES)]
        self.set_modes(self.order.shuffle, nxt)

    # --- kontrol ---------------------------------------------------------
    def play_index(self, i: int) -> None:
        if not (0 <= i < len(self.queue)):
            return
        self._token += 1
        token = self._token
        self.index = i
        track = self.queue[i]

        self.tap.clear()
        self._media.stop()
        self._media.setSource(QUrl())   # eski kaynağı bırak (dosya kilidi de kalkar)
        self.track_changed.emit(track)
        self.queue_changed.emit()

        self._streaming, self._retried, self._fallback_used = False, False, False
        self._reset_progressive()
        local = self._local_path(track)
        if local:
            self._play_file(local)
            return
        if self.play_mode == "stream":
            self._begin_stream(track, token)
        else:
            self._begin_cache(track, token)

    def toggle(self) -> None:
        if self.is_playing:
            self._media.pause()
        elif not self._media.source().isEmpty():
            self._media.play()
        elif self.queue:
            self.play_index(max(self.index, 0))

    def next(self, auto: bool = False) -> None:
        if not self.queue:
            return
        # Otomatik geçişte sadece "tümünü tekrarla" modunda başa sarılır; elle "sonraki" her zaman sarar.
        wrap = (self.repeat == "all") or not auto
        nxt = self.order.next(self.index, wrap=wrap)
        if nxt is None:
            self._media.stop()          # liste bitti
            return
        self.play_index(nxt)

    def prev(self) -> None:
        if not self.queue:
            return
        if self._media.position() > 3000:   # 3 sn'den fazla çaldıysa parçayı başa sar
            self._media.setPosition(0)
            return
        prv = self.order.prev(self.index)
        if prv is not None:
            self.play_index(prv)

    def stop(self) -> None:
        self._token += 1
        self._reset_progressive()
        self._media.stop()
        self._media.setSource(QUrl())

    def seek(self, ms: int) -> None:
        self.tap.clear()
        self._media.setPosition(int(ms))

    def set_volume(self, percent: int) -> None:
        self._audio.setVolume(max(0, min(100, percent)) / 100)

    # --- iç işler --------------------------------------------------------
    def _local_path(self, track: Track) -> str | None:
        """Çalınabilir yerel dosya: kullanıcının indirdiği ya da önbellekteki."""
        if track.local_path and os.path.exists(track.local_path):
            return track.local_path
        found = self.local_resolver(track.id) if self.local_resolver else None
        if found:
            return found
        if self.cache is not None:
            cached = self.cache.path_for(track.id, mp3_only=not self.raw_ok)
            if cached:
                return str(cached)
        return None

    def _play_url(self, url: QUrl) -> None:
        self._media.setSource(url)
        self._media.play()

    def _play_file(self, path: str) -> None:
        self._from_cache = self.cache is not None and str(path).startswith(str(self.cache.dir))
        if self._from_cache:
            self.cache.touch(Path(path))
        self._play_url(QUrl.fromLocalFile(str(path)))
        self._schedule_prefetch()

    def _on_position(self, ms: int) -> None:
        if ms > 0 and self._watchdog.isActive():
            self._watchdog.stop()                    # ses gelmeye başladı: indirirken çal çalışıyor
        self.position_changed.emit(int(ms))

    def _reset_progressive(self) -> None:
        self._watchdog.stop()
        self._prog_active, self._await_full, self._cached_path = False, False, None
        if self._prog_url:
            progressive.server().unregister(self._prog_url)
            self._prog_url = ""

    # ---- önbelleğe indir; mümkünse İNDİRİRKEN ÇAL (varsayılan) ------------
    def _begin_cache(self, track: Track, token: int) -> None:
        self._streaming = False
        self._reset_progressive()
        self.status_message.emit("Hazırlanıyor…")
        cancelled = lambda: token != self._token            # noqa: E731 - başka şarkıya geçildi
        stage = lambda text: self._stage_sig.emit(text, token)   # noqa: E731 - iş parçacığından güvenli

        if self.progressive and self.raw_ok and self.cache is not None:
            def work():
                return youtube.fetch_progressive(
                    track, self.cache, on_ready=lambda url: self._ready_sig.emit(url, token),
                    stage=stage, cancelled=cancelled)
        else:
            def work():
                return youtube.fetch_audio(track, self.cache, stage=stage, cancelled=cancelled)

        run_async(
            work,
            on_result=lambda path: self._on_cached(path, token),
            on_error=lambda msg: self._on_resolve_error(msg, token),
        )

    def _on_stage(self, text: str, token: int) -> None:
        if token == self._token and not self._prog_active:
            self.status_message.emit(text)

    def _on_progressive_ready(self, url: str, token: int) -> None:
        """Yeterli veri indi: indirme sürerken yerel adresten çalmaya başla."""
        if token != self._token:
            return
        self._prog_active, self._from_cache, self._streaming = True, False, False
        self._prog_url = url
        self.status_message.emit("")
        self._play_url(QUrl(url))
        self._watchdog.start(15000)

    def _on_watchdog(self) -> None:
        if self._prog_active and self._media.position() <= 0:
            self._progressive_fail()

    def _progressive_fail(self) -> None:
        """İndirirken çal çalışmadı (ses gelmedi/çözülemedi): tamamı inince yerelden çal."""
        self._watchdog.stop()
        self._prog_active = False
        self._media.stop()
        self._media.setSource(QUrl())
        if self._cached_path:                        # indirme zaten bitmiş
            self._play_file(self._cached_path)
            return
        self._await_full = True
        self.status_message.emit("Tamamı indiriliyor…")

    def _on_cached(self, path, token: int) -> None:
        """İndirme tamamlandı."""
        if token != self._token:         # bu arada başka parçaya geçildi
            return
        self._cached_path = str(path)
        self.status_message.emit("")
        if self._prog_active and not self._await_full:
            self._schedule_prefetch()    # zaten indirirken çalıyor; sıradakini hazırlamaya başla
            return
        self._prog_active = False
        self._await_full = False
        self._play_file(str(path))

    def prefetch_track(self, track: Track) -> None:
        """Bir şarkıyı arka planda önbelleğe hazırla (sıradaki şarkı, üstüne gelinen kart...)."""
        if not (self.prefetch and self.play_mode == "cache" and self.cache is not None):
            return
        if track.source == "local" or track.id in self._inflight or len(self._inflight) >= 3 \
                or self._local_path(track):
            return
        self._inflight.add(track.id)
        run_async(
            lambda: youtube.fetch_audio(track, self.cache),
            on_result=lambda _p: self._inflight.discard(track.id),
            on_error=lambda _m: self._inflight.discard(track.id),
        )

    def _schedule_prefetch(self) -> None:
        """Sıradaki şarkıyı arka planda hazırla: geçince boşluk kalmasın."""
        nxt = self.order.next(self.index, wrap=False)      # wrap=False: karışık sırayı bozmaz
        if nxt is not None:
            self.prefetch_track(self.queue[nxt])

    # ---- doğrudan akış (isteğe bağlı) ------------------------------------
    def _begin_stream(self, track: Track, token: int) -> None:
        self._streaming = True
        self.status_message.emit("Akış hazırlanıyor…")
        run_async(
            youtube.resolve_stream, track,
            on_result=lambda url: self._on_stream(url, token),
            on_error=lambda msg: self._on_resolve_error(msg, token),
        )

    def _on_stream(self, url: str, token: int) -> None:
        if token != self._token:        # bu arada başka parçaya geçildi
            return
        self.status_message.emit("")
        self._from_cache = False
        self._play_url(QUrl(url))

    def _on_resolve_error(self, msg: str, token: int) -> None:
        if token != self._token:
            return
        track = self.current_track()
        if self.play_mode == "stream" and not self._fallback_used and track is not None \
                and self.cache is not None:
            self._fallback_used = True        # akış çözülemedi: önbellek yolunu dene
            self._begin_cache(track, token)
            return
        self.status_message.emit("")
        self.error.emit(msg)

    def _on_state(self, state) -> None:
        self.playing_changed.emit(state == QMediaPlayer.PlaybackState.PlayingState)

    def _on_status(self, status) -> None:
        if status == QMediaPlayer.MediaStatus.EndOfMedia:
            if self.repeat == "one":
                self._media.setPosition(0)
                self._media.play()
            else:
                self.next(auto=True)

    def _on_error(self, err, message: str) -> None:
        if err == QMediaPlayer.Error.NoError:
            return
        track = self.current_track()
        if self._prog_active and track is not None:
            self._progressive_fail()                 # indirirken çal çalmadı: tamamı inince yerelden dene
            return
        if self._from_cache and track is not None and self.cache is not None:
            bad = self.cache.path_for(track.id)
            if bad and bad.suffix.lower() != ".mp3" and health.find_ffmpeg():
                # Ham ses (m4a/webm) bu sistemde Qt'de çalmıyor: MP3'e çevirip öyle çal, bir daha ham deneme
                self.raw_ok = False
                self.raw_failed.emit()
                self._from_cache = False
                self.status_message.emit("Uyumlu biçime çevriliyor…")
                self._begin_cache(track, self._token)
                return
            # Önbellekteki dosya bozuk: sil ki bir sonraki denemede yeniden insin
            if bad:
                try:
                    bad.unlink()
                except OSError:
                    pass
            self._from_cache = False
            self.error.emit("Önbellekteki dosya çalınamadı ve silindi. Şarkıya tekrar tıklayın. "
                            f"(Ayrıntı: {message or 'bilinmiyor'})")
            return
        if self._streaming and track is not None:
            token = self._token
            if not self._retried:
                # İlk akış formatı çalınamadı: daha uyumlu yedek formatla bir kez daha dene
                self._retried = True
                self.status_message.emit("Alternatif akış deneniyor…")
                run_async(
                    youtube.resolve_stream, track, alt=True,
                    on_result=lambda url: self._on_stream(url, token),
                    on_error=lambda msg: self._on_resolve_error(msg, token),
                )
                return
            if not self._fallback_used and self.cache is not None:
                self._fallback_used = True      # akış hiç çalmıyor: indirip yerelden çal
                self._begin_cache(track, token)
                return
        self.error.emit(message or "Oynatma hatası")
