@echo off
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Once kur.bat dosyasini calistirin.
  pause
  exit /b 1
)
".venv\Scripts\python.exe" main.py
if errorlevel 1 (
  echo.
  echo Uygulama bir hatayla kapandi. Yukaridaki mesaji kopyalayip gonderebilirsiniz.
  pause
)
