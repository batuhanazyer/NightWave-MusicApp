@echo off
setlocal
cd /d "%~dp0"
title NightWave kurulumu
echo ============================================================
echo   NightWave kurulumu
echo ============================================================
echo.

rem --- 1) Python bul (3.13 / 3.12 / 3.11 tercih edilir) ---
set "PY="
for %%V in (3.13 3.12 3.11) do (
  if not defined PY (
    py -%%V -c "import sys" >nul 2>&1 && set "PY=py -%%V"
  )
)
if not defined PY (
  python --version >nul 2>&1 && set "PY=python"
)
if not defined PY (
  echo [HATA] Python bulunamadi.
  echo        https://www.python.org/downloads/ adresinden Python 3.11 veya ustunu kurun.
  echo        Kurulumda "Add python.exe to PATH" kutusunu isaretlemeyi unutmayin.
  pause
  exit /b 1
)
echo [1/5] Python bulundu: %PY%
%PY% --version

rem --- 2) Sanal ortam (varsa tekrar kullanir) ---
if not exist ".venv\Scripts\python.exe" (
  echo [2/5] Sanal ortam olusturuluyor...
  %PY% -m venv .venv
  if errorlevel 1 (
    echo [HATA] Sanal ortam olusturulamadi.
    pause
    exit /b 1
  )
) else (
  echo [2/5] Mevcut sanal ortam kullaniliyor: .venv
)

rem --- 3) Python paketleri ---
echo [3/5] Python paketleri kuruluyor, birkac dakika surebilir...
".venv\Scripts\python.exe" -m pip install --upgrade pip >nul 2>&1
".venv\Scripts\python.exe" -m pip install -U -r requirements.txt
if errorlevel 1 (
  echo [HATA] Paket kurulumu basarisiz oldu. Yukaridaki hata mesajina bakin.
  pause
  exit /b 1
)

rem --- 4) Deno (YouTube icin) ve FFmpeg (MP3 indirme icin) ---
echo [4/5] Gerekli programlar kontrol ediliyor...
where winget >nul 2>&1
if errorlevel 1 (
  echo [UYARI] winget bulunamadi. Deno ve FFmpeg'i elle kurmaniz gerekir:
  echo         Deno   : https://deno.com
  echo         FFmpeg : https://www.gyan.dev/ffmpeg/builds/
) else (
  where deno >nul 2>&1 || winget install -e --id DenoLand.Deno --accept-source-agreements --accept-package-agreements
  where ffmpeg >nul 2>&1 || winget install -e --id Gyan.FFmpeg --accept-source-agreements --accept-package-agreements
)

rem --- 5) Tani ---
echo.
echo [5/5] Son kontrol:
echo.
".venv\Scripts\python.exe" diagnose.py

echo.
echo ============================================================
echo   Kurulum bitti. Baslatmak icin: calistir.bat
echo   Yeni program kurulduysa once bu pencereyi kapatip
echo   calistir.bat dosyasini yeniden acin.
echo ============================================================
pause
