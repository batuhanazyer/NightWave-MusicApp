"""Ana sayfa: selamlama + yatay raflar. Her raf kapaklı kartlardan oluşur (tıkla = çal, sağ tık = menü)."""
from PyQt6.QtCore import QRectF, Qt, pyqtSignal
from PyQt6.QtGui import QBrush, QColor, QFont, QLinearGradient, QPainter, QPainterPath, QPixmap
from PyQt6.QtWidgets import (QFrame, QHBoxLayout, QLabel, QPushButton, QScrollArea, QVBoxLayout,
                             QWidget)

CARD_W, COVER, SHELF_H = 168, 152, 254


def _short(text: str, n: int) -> str:
    text = " ".join((text or "").split())
    return text if len(text) <= n else text[:n - 1].rstrip() + "…"


def card_pixmap(src: QPixmap, size: int, radius: int = 12) -> QPixmap:
    """Görseli ortadan kare kırpıp köşeleri yuvarlar."""
    out = QPixmap(size, size)
    out.fill(Qt.GlobalColor.transparent)
    p = QPainter(out)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)
    clip = QPainterPath()
    clip.addRoundedRect(0, 0, size, size, radius, radius)
    p.setClipPath(clip)
    scaled = src.scaled(size, size, Qt.AspectRatioMode.KeepAspectRatioByExpanding,
                        Qt.TransformationMode.SmoothTransformation)
    p.drawPixmap((size - scaled.width()) // 2, (size - scaled.height()) // 2, scaled)
    p.end()
    return out


def placeholder_pixmap(size: int, pal: dict, radius: int = 12) -> QPixmap:
    """Kapak yüklenene kadar gösterilen yer tutucu."""
    out = QPixmap(size, size)
    out.fill(Qt.GlobalColor.transparent)
    p = QPainter(out)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    g = QLinearGradient(0, 0, size, size)
    g.setColorAt(0, QColor(pal["surface"]))
    g.setColorAt(1, QColor(pal["hover"]))
    path = QPainterPath()
    path.addRoundedRect(0, 0, size, size, radius, radius)
    p.fillPath(path, QBrush(g))
    f = QFont()
    f.setPixelSize(int(size * 0.34))
    p.setFont(f)
    p.setPen(QColor(pal["muted"]))
    p.drawText(QRectF(0, 0, size, size), Qt.AlignmentFlag.AlignCenter, "♪")
    p.end()
    return out


class TrackCard(QFrame):
    clicked = pyqtSignal()
    context = pyqtSignal(object)            # global konum
    hover = pyqtSignal(bool)                # fare kartın üstünde mi (önceden hazırlama için)

    def __init__(self, track, thumbs, pal: dict, tooltip: str = "", parent=None):
        super().__init__(parent)
        self.setObjectName("card")
        self.setFixedWidth(CARD_W)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.track = track
        lay = QVBoxLayout(self)
        lay.setContentsMargins(8, 8, 8, 8)
        lay.setSpacing(6)
        self.cover = QLabel()
        self.cover.setFixedSize(COVER, COVER)
        self.cover.setPixmap(placeholder_pixmap(COVER, pal))
        title = QLabel(_short(track.title, 54))
        title.setObjectName("cardTitle")
        title.setWordWrap(True)
        title.setFixedHeight(40)
        title.setAlignment(Qt.AlignmentFlag.AlignTop | Qt.AlignmentFlag.AlignLeft)
        artist = QLabel(_short(track.artist or "—", 30))
        artist.setObjectName("muted")
        lay.addWidget(self.cover)
        lay.addWidget(title)
        lay.addWidget(artist)
        self.setToolTip(tooltip or f"{track.title}\n{track.artist}".strip())
        if track.thumbnail:
            thumbs.load(track.thumbnail, self._set_thumb)

    def _set_thumb(self, pix: QPixmap) -> None:
        self.cover.setPixmap(card_pixmap(pix, COVER))

    def mouseReleaseEvent(self, e):
        if e.button() == Qt.MouseButton.LeftButton and self.rect().contains(e.position().toPoint()):
            self.clicked.emit()
        super().mouseReleaseEvent(e)

    def contextMenuEvent(self, e):
        self.context.emit(e.globalPos())

    def enterEvent(self, e):
        self.hover.emit(True)
        super().enterEvent(e)

    def leaveEvent(self, e):
        self.hover.emit(False)
        super().leaveEvent(e)


class ShelfWidget(QWidget):
    play = pyqtSignal(object, int)           # parça listesi, tıklanan indeks
    context = pyqtSignal(object, object)     # parça, global konum
    more = pyqtSignal(str)
    hover_track = pyqtSignal(object)         # üstüne gelinen parça (ya da None)

    def __init__(self, key: str, thumbs, pal: dict, parent=None):
        super().__init__(parent)
        self.key, self.thumbs, self.pal = key, thumbs, pal
        self.tracks: list = []
        self._sig: tuple = ()

        self.title_btn = QPushButton()
        self.title_btn.setObjectName("shelfTitle")
        self.title_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.title_btn.clicked.connect(lambda: self.more.emit(self.key))
        self.subtitle = QLabel()
        self.subtitle.setObjectName("muted")
        self.btn_left, self.btn_right = QPushButton("‹"), QPushButton("›")
        for b, d in ((self.btn_left, -1), (self.btn_right, 1)):
            b.setObjectName("rowBtn")
            b.setFixedSize(30, 30)
            b.clicked.connect(lambda _=False, d=d: self._scroll_by(d))
        head = QHBoxLayout()
        head.setSpacing(10)
        head.addWidget(self.title_btn)
        head.addWidget(self.subtitle)
        head.addStretch(1)
        head.addWidget(self.btn_left)
        head.addWidget(self.btn_right)

        self.shelf_scroll = QScrollArea()
        self.shelf_scroll.setWidgetResizable(True)
        self.shelf_scroll.setFrameShape(QFrame.Shape.NoFrame)
        self.shelf_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.shelf_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.shelf_scroll.setFixedHeight(SHELF_H)
        inner = QWidget()
        self._cards = QHBoxLayout(inner)
        self._cards.setContentsMargins(0, 0, 0, 0)
        self._cards.setSpacing(10)
        self.shelf_scroll.setWidget(inner)

        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(8)
        lay.addLayout(head)
        lay.addWidget(self.shelf_scroll)

    def _scroll_by(self, direction: int) -> None:
        bar = self.shelf_scroll.horizontalScrollBar()
        bar.setValue(bar.value() + direction * (CARD_W + 10) * 3)

    def set_content(self, title: str, subtitle: str, tracks: list, reasons: dict | None, more: bool):
        self.title_btn.setText(title + ("  ›" if more else ""))
        self.title_btn.setEnabled(more)
        self.subtitle.setText(subtitle)
        sig = tuple(t.id for t in tracks)
        if sig == self._sig:
            return                                   # aynı parçalar: kartları yeniden kurma (titremesin)
        self._sig, self.tracks = sig, list(tracks)
        while self._cards.count():
            item = self._cards.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        reasons = reasons or {}
        for i, t in enumerate(self.tracks):
            card = TrackCard(t, self.thumbs, self.pal, reasons.get(t.id, ""))
            card.clicked.connect(lambda i=i: self.play.emit(self.tracks, i))
            card.context.connect(lambda pos, t=t: self.context.emit(t, pos))
            card.hover.connect(lambda on, t=t: self.hover_track.emit(t if on else None))
            self._cards.addWidget(card)
        self._cards.addStretch(1)


class HomeView(QScrollArea):
    play_requested = pyqtSignal(object, int)
    context_requested = pyqtSignal(object, object)
    more_requested = pyqtSignal(str)
    refresh_requested = pyqtSignal()
    hover_requested = pyqtSignal(object)

    def __init__(self, thumbs, pal: dict, parent=None):
        super().__init__(parent)
        self.thumbs, self.pal = thumbs, pal
        self._shelves: dict[str, ShelfWidget] = {}
        self._order: dict[str, int] = {}
        self.setWidgetResizable(True)
        self.setFrameShape(QFrame.Shape.NoFrame)

        self.greet = QLabel("Merhaba")
        self.greet.setObjectName("h1")
        self.sub = QLabel("")
        self.sub.setObjectName("muted")
        self.refresh_btn = QPushButton("Yenile")
        self.refresh_btn.setObjectName("rowBtn")
        self.refresh_btn.clicked.connect(lambda: self.refresh_requested.emit())
        titles = QVBoxLayout()
        titles.setSpacing(2)
        titles.addWidget(self.greet)
        titles.addWidget(self.sub)
        head = QHBoxLayout()
        head.addLayout(titles, 1)
        head.addWidget(self.refresh_btn, 0, Qt.AlignmentFlag.AlignTop)

        self.message = QLabel("")
        self.message.setObjectName("muted")
        self.message.setWordWrap(True)
        self.message.setVisible(False)

        page = QWidget()
        self._lay = QVBoxLayout(page)
        self._lay.setContentsMargins(0, 0, 8, 16)
        self._lay.setSpacing(18)
        self._lay.addLayout(head)             # indeks 0
        self._lay.addWidget(self.message)     # indeks 1  -> raflar 2'den itibaren eklenir
        self._lay.addStretch(1)
        self.setWidget(page)

    # ---- içerik --------------------------------------------------------------
    def set_greeting(self, greeting: str, sub: str) -> None:
        self.greet.setText(greeting)
        self.sub.setText(sub)

    def set_message(self, text: str) -> None:
        self.message.setText(text)
        self.message.setVisible(bool(text))

    def keys(self) -> list[str]:
        return sorted(self._shelves, key=lambda k: self._order.get(k, 0))

    def upsert(self, key: str, order: int, title: str, subtitle: str, tracks: list,
               reasons: dict | None = None, more: bool = False) -> None:
        """Rafı ekler ya da günceller; parça yoksa rafı kaldırır. Raflar `order` sırasına dizilir."""
        if not tracks:
            self.remove(key)
            return
        shelf = self._shelves.get(key)
        if shelf is None:
            shelf = ShelfWidget(key, self.thumbs, self.pal)
            shelf.play.connect(self.play_requested.emit)
            shelf.context.connect(self.context_requested.emit)
            shelf.more.connect(self.more_requested.emit)
            shelf.hover_track.connect(self.hover_requested.emit)
            rank = sum(1 for k, o in self._order.items() if k in self._shelves and o < order)
            self._lay.insertWidget(2 + rank, shelf)
            self._shelves[key] = shelf
        self._order[key] = order
        shelf.set_content(title, subtitle, tracks, reasons, more)
        self.set_message("")

    def remove(self, key: str) -> None:
        shelf = self._shelves.pop(key, None)
        self._order.pop(key, None)
        if shelf is not None:
            self._lay.removeWidget(shelf)
            shelf.deleteLater()

    def apply_palette(self, pal: dict) -> None:
        self.pal = pal
        for shelf in self._shelves.values():
            shelf.pal = pal
