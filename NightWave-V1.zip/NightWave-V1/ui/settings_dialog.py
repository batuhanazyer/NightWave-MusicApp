"""Ayarlar penceresi: Genel / Görünüm / Spotify sekmeleri."""
import copy
import sys
import uuid

from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import (QApplication, QCheckBox, QComboBox, QDialog, QDialogButtonBox,
                             QFileDialog, QFormLayout, QGridLayout, QHBoxLayout, QInputDialog,
                             QLabel, QLineEdit, QMessageBox, QPushButton, QSlider, QTabWidget,
                             QVBoxLayout, QWidget)

from core import health
from core import home as home_data
from ui import styles
from ui.styles import ACCENT_PRESETS, THEMES
from ui.theme_dialog import ThemeDialog
from ui.widgets import ColorPicker

CLOSE_CHOICES = [("tray", "Sistem tepsisine küçült"),
                 ("mini", "Mini oynatıcıya geç"),
                 ("quit", "Uygulamayı kapat")]
DENSITY_CHOICES = [(36, "Sıkışık"), (46, "Normal"), (56, "Geniş")]


def _tab(form: QFormLayout) -> QWidget:
    w = QWidget()
    form.setContentsMargins(8, 18, 8, 8)
    form.setSpacing(14)
    w.setLayout(form)
    return w


def _select(combo: QComboBox, choices, value):
    for i, (key, _label) in enumerate(choices):
        if key == value:
            combo.setCurrentIndex(i)
            return


def _small(text: str, slot) -> QPushButton:
    b = QPushButton(text)
    b.setObjectName("rowBtn")
    b.clicked.connect(lambda _=False: slot())
    return b


class SettingsDialog(QDialog):
    def __init__(self, cfg: dict, media_backend: str = "yok", taskbar_ok: bool = False,
                 history_plays: int = 0, checks: list | None = None, start_tab: int = 0,
                 parent=None, cache_used_mb: int = 0):
        super().__init__(parent)
        self.setWindowTitle("Ayarlar")
        self.setMinimumWidth(620)
        self.custom = copy.deepcopy(cfg.get("custom_themes") or {})
        self._clear_history = False
        self._clear_cache = False

        # ---- Genel ------------------------------------------------------
        self.folder = QLineEdit(cfg.get("download_dir", ""))
        folder_row = QHBoxLayout()
        folder_row.addWidget(self.folder, 1)
        folder_row.addWidget(_small("Seç…", self._browse))

        self.close_box = QComboBox()
        for _k, label in CLOSE_CHOICES:
            self.close_box.addItem(label)
        _select(self.close_box, CLOSE_CHOICES, cfg.get("close_to", "tray"))

        self.media_keys = QCheckBox("Windows medya tuşlarını ve medya panelini (SMTC) kullan")
        self.media_keys.setChecked(bool(cfg.get("media_keys", True)))
        self.media_state = QLabel(f"Şu an aktif: {media_backend}")
        self.media_state.setObjectName("muted")

        self.taskbar = QCheckBox("Görev çubuğu entegrasyonu (önizleme düğmeleri, ilerleme, rozet)")
        self.taskbar.setChecked(bool(cfg.get("taskbar", True)))
        self.taskbar.setEnabled(sys.platform == "win32")
        self.taskbar_state = QLabel("Şu an aktif: " + ("evet" if taskbar_ok else "hayır"))
        self.taskbar_state.setObjectName("muted")

        self.personalize = QCheckBox("Kişisel öneriler (dinleme geçmişi yalnızca bu cihazda saklanır)")
        self.personalize.setChecked(bool(cfg.get("personalize", True)))
        self.clear_btn = _small(f"Dinleme geçmişini temizle ({history_plays} dinleme)", self._on_clear)

        general = QFormLayout()
        general.addRow("İndirme klasörü", folder_row)
        general.addRow("X tuşuna basınca", self.close_box)
        general.addRow("", self.media_keys)
        general.addRow("", self.media_state)
        general.addRow("", self.taskbar)
        general.addRow("", self.taskbar_state)
        general.addRow("", self.personalize)
        general.addRow("", self.clear_btn)

        # ---- Görünüm ----------------------------------------------------
        self.theme_box = QComboBox()
        self.theme_box.currentIndexChanged.connect(self._on_theme_selected)
        self.accent = ColorPicker(ACCENT_PRESETS, cfg.get("accent", ACCENT_PRESETS[0]))
        self.dynamic = QCheckBox("Vurgu rengini çalan şarkının kapağından al")
        self.dynamic.setChecked(bool(cfg.get("dynamic_accent", False)))

        self.btn_edit = _small("Düzenle…", self._edit_theme)
        self.btn_delete = _small("Sil", self._delete_theme)
        tools = QGridLayout()
        tools.setSpacing(8)
        tools.addWidget(_small("＋ Yeni özel tema…", self._new_theme), 0, 0)
        tools.addWidget(self.btn_edit, 0, 1)
        tools.addWidget(self.btn_delete, 0, 2)
        tools.addWidget(_small("Temayı paylaş (kodu kopyala)", self._share_theme), 1, 0, 1, 2)
        tools.addWidget(_small("Kodla içe aktar…", self._import_theme), 1, 2)
        tools_w = QWidget()
        tools_w.setLayout(tools)
        tools.setContentsMargins(0, 0, 0, 0)

        self.viz_real = QCheckBox("Görselleştirici gerçek sesi analiz etsin (kapalıysa simülasyon)")
        self.viz_real.setChecked(bool(cfg.get("viz_real", True)))

        self.density_box = QComboBox()
        for _k, label in DENSITY_CHOICES:
            self.density_box.addItem(label)
        _select(self.density_box, DENSITY_CHOICES, int(cfg.get("row_height", 46)))

        self.opacity = QSlider(Qt.Orientation.Horizontal)
        self.opacity.setRange(40, 100)
        self.opacity.setValue(int(cfg.get("mini_opacity", 95)))
        self.opacity_label = QLabel(f"%{self.opacity.value()}")
        self.opacity_label.setObjectName("muted")
        self.opacity.valueChanged.connect(lambda v: self.opacity_label.setText(f"%{v}"))
        opacity_row = QHBoxLayout()
        opacity_row.addWidget(self.opacity, 1)
        opacity_row.addWidget(self.opacity_label)

        look = QFormLayout()
        look.addRow("Tema", self.theme_box)
        look.addRow("", tools_w)
        look.addRow("Vurgu rengi", self.accent)
        look.addRow("", self.dynamic)
        look.addRow("", self.viz_real)
        look.addRow("Liste yoğunluğu", self.density_box)
        look.addRow("Mini oynatıcı saydamlığı", opacity_row)
        self._fill_themes(cfg.get("theme", "midnight"))

        # ---- Müzik (oynatma + ana sayfa) --------------------------------
        self.play_box = QComboBox()
        self.play_box.addItem("Önbellek: önce hızlıca indir, sonra çal (güvenilir, önerilen)", "cache")
        self.play_box.addItem("Doğrudan akış (hızlı başlar ama bazı sistemlerde çalmaz)", "stream")
        i = self.play_box.findData(cfg.get("play_mode", "cache"))
        self.play_box.setCurrentIndex(i if i >= 0 else 0)
        self.progressive = QCheckBox("Hızlı başlat: şarkıyı indirirken çal (tamamının inmesini bekleme)")
        self.progressive.setChecked(bool(cfg.get("progressive", True)))
        self.ipv4 = QCheckBox("Yalnızca IPv4 kullan (YouTube çok yavaşsa dene)")
        self.ipv4.setChecked(bool(cfg.get("force_ipv4", False)))
        self.prefetch = QCheckBox("Sıradaki şarkıyı ve üstüne gelinen şarkıyı arka planda hazırla")
        self.prefetch.setChecked(bool(cfg.get("prefetch", True)))
        self.cache_box = QComboBox()
        for mb in (200, 500, 1000, 2000, 5000):
            self.cache_box.addItem(f"{mb} MB" if mb < 1000 else f"{mb // 1000} GB", mb)
        i = self.cache_box.findData(int(cfg.get("cache_mb", 500)))
        self.cache_box.setCurrentIndex(i if i >= 0 else 1)
        self.cache_info = QLabel(f"Şu an kullanılan: {cache_used_mb} MB")
        self.cache_info.setObjectName("muted")
        self.clear_cache_btn = _small("Ses önbelleğini temizle", self._on_clear_cache)

        selected = set(home_data.valid_genres(cfg.get("home_genres")))
        self.genre_checks = {}
        genre_grid = QGridLayout()
        genre_grid.setSpacing(8)
        for n, (key, title, _q) in enumerate(home_data.GENRES):
            cb = QCheckBox(title)
            cb.setChecked(key in selected)
            self.genre_checks[key] = cb
            genre_grid.addWidget(cb, n // 2, n % 2)
        genre_w = QWidget()
        genre_w.setLayout(genre_grid)
        genre_grid.setContentsMargins(0, 0, 0, 0)

        music = QFormLayout()
        music.addRow("Oynatma yöntemi", self.play_box)
        music.addRow("", self.progressive)
        music.addRow("", self.prefetch)
        music.addRow("", self.ipv4)
        music.addRow("Ses önbelleği sınırı", self.cache_box)
        music.addRow("", self.cache_info)
        music.addRow("", self.clear_cache_btn)
        music.addRow("Ana sayfa türleri", genre_w)

        # ---- Spotify ----------------------------------------------------
        self.cid = QLineEdit(cfg.get("spotify_client_id", ""))
        self.secret = QLineEdit(cfg.get("spotify_client_secret", ""))
        self.secret.setEchoMode(QLineEdit.EchoMode.Password)
        hint = QLabel("Anahtarları developer.spotify.com/dashboard adresinde \"Create app\" ile "
                      "ücretsiz alabilirsiniz. Yalnızca arama ve şarkı bilgisi için kullanılır.")
        hint.setObjectName("muted")
        hint.setWordWrap(True)
        spotify = QFormLayout()
        spotify.addRow("Client ID", self.cid)
        spotify.addRow("Client Secret", self.secret)
        spotify.addRow("", hint)

        tabs = QTabWidget()
        tabs.addTab(_tab(general), "Genel")
        tabs.addTab(_tab(look), "Görünüm")
        tabs.addTab(_tab(music), "Müzik")
        tabs.addTab(_tab(spotify), "Spotify")
        tabs.addTab(self._build_system_tab(checks), "Sistem")
        tabs.setCurrentIndex(start_tab)

        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Save |
                                   QDialogButtonBox.StandardButton.Cancel)
        buttons.button(QDialogButtonBox.StandardButton.Save).setText("Kaydet")
        buttons.button(QDialogButtonBox.StandardButton.Cancel).setText("İptal")
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)

        lay = QVBoxLayout(self)
        lay.setContentsMargins(24, 16, 24, 20)
        lay.setSpacing(12)
        lay.addWidget(tabs)
        lay.addWidget(buttons)

    # ---- sistem durumu ----------------------------------------------------
    def _build_system_tab(self, checks) -> QWidget:
        w = QWidget()
        outer = QVBoxLayout(w)
        outer.setContentsMargins(8, 14, 8, 8)
        outer.setSpacing(12)
        info = QLabel("NightWave'in çalışması için gereken programlar. Eksik olanın yanındaki "
                      "\"Komutu kopyala\" düğmesine basıp PowerShell'e yapıştırın; kurulumdan "
                      "sonra uygulamayı yeniden başlatın.")
        info.setObjectName("muted")
        info.setWordWrap(True)
        outer.addWidget(info)
        self._sys_box = QVBoxLayout()
        self._sys_box.setSpacing(12)
        outer.addLayout(self._sys_box)
        outer.addWidget(_small("Yeniden kontrol et", self._recheck), 0, Qt.AlignmentFlag.AlignLeft)
        outer.addStretch(1)
        self._render_checks(checks or health.run_checks())
        return w

    def _render_checks(self, checks):
        while self._sys_box.count():
            item = self._sys_box.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        for c in checks:
            color = "#4ADE80" if c.ok else ("#F87171" if c.severity == "error" else "#E0A458")
            mark = QLabel("✓" if c.ok else ("✗" if c.severity == "error" else "⚠"))
            mark.setStyleSheet(f"color: {color}; font-size: 16px; font-weight: 700;")
            mark.setFixedWidth(20)
            title = QLabel(c.title)
            title.setStyleSheet("font-weight: 600;")
            detail = QLabel(c.detail)
            detail.setObjectName("muted")
            detail.setWordWrap(True)
            col = QVBoxLayout()
            col.setSpacing(1)
            col.addWidget(title)
            col.addWidget(detail)
            row_w = QWidget()
            row = QHBoxLayout(row_w)
            row.setContentsMargins(0, 0, 0, 0)
            row.setSpacing(10)
            row.addWidget(mark, 0, Qt.AlignmentFlag.AlignTop)
            row.addLayout(col, 1)
            if c.fix and not c.ok:
                row.addWidget(_small("Komutu kopyala",
                                     lambda cmd=c.fix: QApplication.clipboard().setText(cmd)),
                              0, Qt.AlignmentFlag.AlignTop)
            self._sys_box.addWidget(row_w)

    def _recheck(self):
        self._render_checks(health.run_checks())

    # ---- müzik ------------------------------------------------------------
    def _on_clear_cache(self):
        self._clear_cache = True
        self.clear_cache_btn.setText("Kaydedince önbellek temizlenecek ✓")
        self.clear_cache_btn.setEnabled(False)

    def clear_cache_requested(self) -> bool:
        return self._clear_cache

    # ---- genel ------------------------------------------------------------
    def _browse(self):
        path = QFileDialog.getExistingDirectory(self, "İndirme klasörünü seç", self.folder.text())
        if path:
            self.folder.setText(path)

    def _on_clear(self):
        self._clear_history = True
        self.clear_btn.setText("Kaydedince geçmiş silinecek ✓")
        self.clear_btn.setEnabled(False)

    # ---- tema yönetimi ----------------------------------------------------
    def _fill_themes(self, select_key: str):
        self.theme_box.blockSignals(True)
        self.theme_box.clear()
        for key, t in THEMES.items():
            self.theme_box.addItem(t["name"], key)
        for key, c in self.custom.items():
            self.theme_box.addItem("🎨 " + str(c.get("name", "Özel tema")), key)
        self.theme_box.addItem("🖥 Sistem temasını izle", "auto")
        idx = self.theme_box.findData(select_key)
        self.theme_box.setCurrentIndex(idx if idx >= 0 else 0)
        self.theme_box.blockSignals(False)
        self._on_theme_selected()

    def _key(self) -> str:
        return self.theme_box.currentData() or "midnight"

    def _on_theme_selected(self, *_):
        is_custom = self._key() in self.custom
        self.btn_edit.setEnabled(is_custom)
        self.btn_delete.setEnabled(is_custom)

    def _current_palette(self) -> dict:
        return styles.get_palette(self._key(), self.accent.color(), self.custom)

    def _new_theme(self):
        dlg = ThemeDialog(self._current_palette(), self.accent.color(), None, self)
        if dlg.exec() == QDialog.DialogCode.Accepted:
            key = "custom:" + uuid.uuid4().hex[:8]
            self.custom[key] = dlg.values()
            self._fill_themes(key)

    def _edit_theme(self):
        key = self._key()
        if key not in self.custom:
            return
        dlg = ThemeDialog(self._current_palette(), self.accent.color(), self.custom[key], self)
        if dlg.exec() == QDialog.DialogCode.Accepted:
            self.custom[key] = dlg.values()
            self._fill_themes(key)

    def _delete_theme(self):
        key = self._key()
        if key in self.custom:
            del self.custom[key]
            self._fill_themes("midnight")

    def _share_theme(self):
        p = self._current_palette()
        code = styles.theme_to_code(p["name"], p["bg"], p["panel"], p["text"], self.accent.color())
        QApplication.clipboard().setText(code)
        QMessageBox.information(self, "Tema kodu kopyalandı",
                                "Kod panoya kopyalandı. Arkadaşınız Ayarlar > Görünüm > "
                                "“Kodla içe aktar…” ile ekleyebilir.")

    def _import_theme(self):
        clip = QApplication.clipboard().text().strip()
        text, ok = QInputDialog.getMultiLineText(
            self, "Tema içe aktar", "Tema kodunu yapıştırın:",
            clip if clip.startswith(styles.THEME_PREFIX) else "")
        if not ok or not text.strip():
            return
        try:
            t = styles.theme_from_code(text)
        except ValueError as exc:
            QMessageBox.warning(self, "İçe aktarılamadı", str(exc))
            return
        key = "custom:" + uuid.uuid4().hex[:8]
        self.custom[key] = {"name": t["name"], "bg": t["bg"], "panel": t["panel"], "text": t["text"]}
        self.accent.set_color(t["accent"])
        self._fill_themes(key)

    # ---- sonuç ------------------------------------------------------------
    def values(self) -> dict:
        return {
            "download_dir": self.folder.text().strip(),
            "close_to": CLOSE_CHOICES[self.close_box.currentIndex()][0],
            "media_keys": self.media_keys.isChecked(),
            "taskbar": self.taskbar.isChecked(),
            "personalize": self.personalize.isChecked(),
            "theme": self._key(),
            "custom_themes": self.custom,
            "accent": self.accent.color(),
            "dynamic_accent": self.dynamic.isChecked(),
            "viz_real": self.viz_real.isChecked(),
            "play_mode": self.play_box.currentData() or "cache",
            "prefetch": self.prefetch.isChecked(),
            "progressive": self.progressive.isChecked(),
            "force_ipv4": self.ipv4.isChecked(),
            "cache_mb": int(self.cache_box.currentData() or 500),
            "home_genres": home_data.valid_genres([k for k, cb in self.genre_checks.items() if cb.isChecked()]),
            "row_height": DENSITY_CHOICES[self.density_box.currentIndex()][0],
            "mini_opacity": self.opacity.value(),
            "spotify_client_id": self.cid.text().strip(),
            "spotify_client_secret": self.secret.text().strip(),
        }

    def clear_history_requested(self) -> bool:
        return self._clear_history
