"""Ana pencere: kenar çubuğu (görünümler + çalma listeleri) + içerik + alt oynatıcı çubuğu."""
import json
import re
import sys
import time
from pathlib import Path

from PyQt6.QtCore import QSize, Qt, QTimer
from PyQt6.QtGui import QAction, QColor, QFont, QGuiApplication, QIcon, QPixmap
from PyQt6.QtWidgets import (QAbstractItemView, QApplication, QComboBox, QDialog, QFileDialog,
                             QFrame, QHBoxLayout, QHeaderView, QInputDialog, QLabel, QLineEdit,
                             QListWidget, QListWidgetItem, QMainWindow, QMenu, QMessageBox,
                             QPushButton, QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget)

from core import config, health, network, progressive, youtube
from core import playlists as pls
from core import home as home_data
from core import recommend
from core.cache import AudioCache
from core.history import History
from core.library import Library
from core.models import Track, fmt_time
from core.player import Player
from core.spotify import SpotifyClient
from core.system_media import SystemMedia
from core.workers import run_async
from ui import styles
from ui.colors import dominant_color
from ui.icons import icon
from ui.home_view import HomeView
from ui.mini_player import MiniPlayer
from ui.now_playing import NowPlayingView
from ui.playlist_ui import PlaylistDialog, render_cover, save_cover
from ui.settings_dialog import SettingsDialog
from ui.taskbar import TaskbarIntegration
from ui.thumbs import ThumbLoader
from ui.tray import TrayController
from ui.widgets import ClickableLabel, ClickSlider, set_elided

SEARCH_MODES = ["YouTube", "Spotify · Şarkı", "Spotify · Albüm", "Spotify · Çalma listesi (URL)"]
SORTS = [("manual", "Elle sıralı"), ("title", "Başlığa göre"),
         ("artist", "Sanatçıya göre"), ("added", "Eklenme sırası")]
REPEAT_TIPS = {"off": "Tekrar: Kapalı", "all": "Tekrar: Tüm liste", "one": "Tekrar: Tek parça"}


def _act(menu: QMenu, text: str, fn, enabled: bool = True) -> QAction:
    """Menüye, tıklanınca fn() çağıran bir eylem ekler."""
    a = QAction(text, menu)
    a.triggered.connect(lambda _=False: fn())
    a.setEnabled(enabled)
    menu.addAction(a)
    return a


def _safe_filename(name: str) -> str:
    return re.sub(r'[\\/:*?"<>|]+', "", name).strip() or "liste"


class MainWindow(QMainWindow):
    def __init__(self, cfg: dict):
        super().__init__()
        self.setWindowTitle("NightWave")
        self.resize(1180, 740)
        self.setMinimumSize(980, 600)

        self.cfg = cfg
        self.pal = styles.get_palette(cfg.get("theme"), cfg.get("accent"), cfg.get("custom_themes"))
        self.library = Library(config.LIBRARY_FILE, Path(cfg["download_dir"]))
        self.playlists = pls.PlaylistStore(config.PLAYLISTS_FILE, config.COVER_DIR)
        self.history = History(config.HISTORY_FILE)
        self.cache = AudioCache(config.CACHE_DIR, int(cfg.get("cache_mb", 500)))   # çalınan şarkıların ses önbelleği
        self.home_cache = home_data.HomeCache(config.HOME_CACHE_FILE)
        self.thumbs = ThumbLoader(config.THUMB_DIR)
        self.spotify: SpotifyClient | None = None

        self.player = Player(self)
        self.player.local_resolver = self.library.path_for
        self.player.set_volume(int(cfg.get("volume", 70)))
        self.player.set_modes(bool(cfg.get("shuffle")), cfg.get("repeat", "off"))
        self.player.tap.set_backend(bool(cfg.get("viz_real", True)))
        self.player.cache = self.cache
        self.player.play_mode = cfg.get("play_mode", "cache")
        self.player.prefetch = bool(cfg.get("prefetch", True))
        self.player.progressive = bool(cfg.get("progressive", True))
        self.player.raw_ok = bool(cfg.get("raw_ok", True))
        self.player.raw_failed.connect(self._on_raw_failed)
        youtube.configure(force_ipv4=bool(cfg.get("force_ipv4", False)))

        self.online = True
        self.force_offline = False
        self.view = "discover"            # discover | library | queue | playlist
        self.current_pl: str | None = None
        self.shown: list[Track] = []      # tabloda görünen parçalar
        self._last_results: list[Track] = []
        self._cover_pix: QPixmap | None = None
        self._seeking = False
        self._quitting = False
        self._tray_hint_shown = False
        self.sysmedia: SystemMedia | None = None
        self.taskbar: TaskbarIntegration | None = None
        self._taskbar_failed = False
        self._dyn_accent: str | None = None      # kapaktan çıkarılan vurgu rengi
        self._applied_key = None                  # son uygulanan tema (gereksiz yeniden çizimi önler)
        self._rec_tracks: list[Track] = []        # kişisel öneriler
        self._rec_reasons: dict[str, str] = {}
        self._rec_taste: list = []
        self._rec_loading = False
        self._rec_time = 0.0
        self._play_track: Track | None = None     # dinleme geçmişi için çalan parça takibi
        self._play_max_pos = 0
        self._play_dur = 0
        self._checks: list = []                   # sistem sağlık kontrolü sonuçları
        self._banner_fix = ""
        self._banner_dismissed = False
        self._discover_mode = "home"              # ana sayfa (öneri rafları) | results (arama sonuçları)
        self._prev_view = None                    # "Çalıyor" ekranından dönülecek görünüm
        self._home_pending = 0                    # devam eden ana sayfa yüklemeleri
        self._home_error = ""
        self._shelf_data: dict = {}               # raf anahtarı -> (başlık, parçalar)
        self._collection_title, self._collection_tracks = "", []
        self._last_off = False
        self._hover_track = None                  # üstüne gelinen parça: kısa beklemeden sonra önceden hazırlanır
        self._hover_timer = QTimer(self)
        self._hover_timer.setSingleShot(True)
        self._hover_timer.timeout.connect(self._hover_fire)

        self._queue_timer = QTimer(self)               # kuyruk görünümünü toplu yenile
        self._queue_timer.setSingleShot(True)
        self._queue_timer.setInterval(30)
        self._queue_timer.timeout.connect(self._refresh_queue_view)

        self._build_ui()
        self._wire_player()

        self.mini = MiniPlayer(self.player, self.pal, int(cfg.get("mini_opacity", 95)), cfg)
        self.mini.expand_requested.connect(self.switch_to_main)
        self.mini.moved.connect(lambda x, y: self.cfg.__setitem__("mini_pos", [x, y]))
        self.tray = TrayController(self, self.player)

        self.apply_theme()
        self._reload_playlist_list()
        self._setup_system_media()
        hints = QGuiApplication.styleHints()      # Windows açık/koyu tema değişince 'sistem temasını izle'
        if hasattr(hints, 'colorSchemeChanged'):
            hints.colorSchemeChanged.connect(lambda *_: self.apply_theme(force=True))
        self.show_discover()

        self._net_timer = QTimer(self)
        self._net_timer.timeout.connect(self._check_network)
        self._net_timer.start(8000)
        self._check_network()
        self._run_health_check()
        run_async(self._cache_maintenance)        # eski ham dosyaları temizle + sınırı uygula

    @property
    def is_offline(self) -> bool:
        return self.force_offline or not self.online

    # =====================================================================
    # Arayüz kurulumu
    # =====================================================================
    def _build_ui(self):
        root = QWidget()
        root.setObjectName("root")
        self.setCentralWidget(root)
        outer = QVBoxLayout(root)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        body = QHBoxLayout()
        body.setSpacing(0)
        body.addWidget(self._build_sidebar())
        body.addWidget(self._build_content(), 1)
        outer.addLayout(body, 1)
        outer.addWidget(self._build_player_bar())

    def _nav_button(self, text, slot) -> QPushButton:
        b = QPushButton(text)
        b.setObjectName("nav")
        b.setCheckable(True)
        b.setCursor(Qt.CursorShape.PointingHandCursor)
        b.clicked.connect(lambda _=False: slot())
        return b

    def _build_sidebar(self) -> QWidget:
        side = QWidget()
        self.sidebar = side
        side.setObjectName("sidebar")
        side.setFixedWidth(232)
        lay = QVBoxLayout(side)
        lay.setContentsMargins(14, 22, 14, 16)
        lay.setSpacing(4)

        logo = QLabel("NightWave")
        logo.setObjectName("logo")
        lay.addWidget(logo)
        lay.addSpacing(14)

        self.btn_discover = self._nav_button("Ana sayfa", self.show_discover)
        self.btn_library = self._nav_button("İndirilenler", self.show_library)
        self.btn_liked = self._nav_button("Beğenilenler", self.show_liked)
        self.btn_queue = self._nav_button("Kuyruk", self.show_queue)
        for b in (self.btn_discover, self.btn_library, self.btn_liked, self.btn_queue):
            lay.addWidget(b)
        lay.addSpacing(14)

        # Çalma listeleri başlığı + (＋) menüsü
        head = QHBoxLayout()
        section = QLabel("ÇALMA LİSTELERİ")
        section.setObjectName("section")
        self.btn_pl_add = QPushButton("＋")
        self.btn_pl_add.setObjectName("rowBtn")
        self.btn_pl_add.setFixedSize(28, 28)
        self.btn_pl_add.setToolTip("Yeni liste / içe aktar")
        self._add_menu = QMenu(self)
        _act(self._add_menu, "Yeni çalma listesi…", self._new_playlist)
        self._add_menu.addSeparator()
        _act(self._add_menu, "Paylaşım kodundan içe aktar…", self._import_code)
        _act(self._add_menu, "Dosyadan içe aktar (.nwpl)…", self._import_file)
        self.btn_pl_add.setMenu(self._add_menu)
        head.addWidget(section)
        head.addStretch(1)
        head.addWidget(self.btn_pl_add)
        lay.addLayout(head)

        self.pl_list = QListWidget()
        self.pl_list.setObjectName("plList")
        self.pl_list.setIconSize(QSize(28, 28))
        self.pl_list.setSpacing(2)
        self.pl_list.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.pl_list.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.pl_list.itemClicked.connect(self._on_pl_clicked)
        self.pl_list.customContextMenuRequested.connect(self._on_pl_menu)
        lay.addWidget(self.pl_list, 1)

        self.net_label = QLabel("● Çevrimiçi")
        self.net_label.setObjectName("netLabel")
        self.btn_offline = QPushButton("Çevrimdışı modu aç")
        self.btn_offline.setObjectName("nav")
        self.btn_offline.setCheckable(True)
        self.btn_offline.toggled.connect(self._toggle_force_offline)
        btn_settings = QPushButton("Ayarlar")
        btn_settings.setObjectName("nav")
        btn_settings.clicked.connect(lambda _=False: self.open_settings())
        lay.addWidget(self.net_label)
        lay.addWidget(self.btn_offline)
        lay.addWidget(btn_settings)
        return side

    def _build_content(self) -> QWidget:
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.setContentsMargins(28, 24, 28, 12)
        lay.setSpacing(14)

        self.pl_header = self._build_playlist_header()
        self.pl_header.setVisible(False)

        self.title_label = QLabel("Keşfet")
        self.title_label.setObjectName("h1")

        self.search_edit = QLineEdit()
        self.search_edit.returnPressed.connect(self.do_search)
        self.search_edit.textChanged.connect(self._on_search_text)
        self.mode_box = QComboBox()
        self.mode_box.addItems(SEARCH_MODES)
        self.search_btn = QPushButton("Ara")
        self.search_btn.setObjectName("primary")
        self.search_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.search_btn.clicked.connect(lambda _=False: self._on_search_button())

        self.btn_back_home = QPushButton("← Ana sayfa")
        self.btn_back_home.setObjectName("rowBtn")
        self.btn_back_home.setVisible(False)
        self.btn_back_home.clicked.connect(lambda: self.show_discover())
        top = QHBoxLayout()
        top.setSpacing(10)
        top.addWidget(self.btn_back_home)
        top.addWidget(self.search_edit, 1)
        top.addWidget(self.mode_box)
        top.addWidget(self.search_btn)

        self.status_label = QLabel("")
        self.status_label.setObjectName("muted")

        t = self.table = QTableWidget(0, 4)
        t.setHorizontalHeaderLabels(["Başlık", "Sanatçı / Kanal", "Süre", ""])
        t.verticalHeader().setVisible(False)
        t.setShowGrid(False)
        t.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        t.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        t.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        t.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        t.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        h = t.horizontalHeader()
        h.setHighlightSections(False)
        h.setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        h.setSectionResizeMode(1, QHeaderView.ResizeMode.Interactive)
        h.setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents)
        h.setSectionResizeMode(3, QHeaderView.ResizeMode.Fixed)
        t.setColumnWidth(1, 220)
        t.setColumnWidth(3, 130)
        t.cellClicked.connect(self._on_row_clicked)          # tek tıkla çal
        t.setMouseTracking(True)
        t.cellEntered.connect(self._on_row_hover)            # üstüne gelince önceden hazırla
        t.customContextMenuRequested.connect(self._on_table_menu)

        lay.addWidget(self._build_banner())
        lay.addWidget(self.pl_header)
        lay.addWidget(self.title_label)
        lay.addLayout(top)
        lay.addWidget(self.status_label)
        self.home_view = HomeView(self.thumbs, self.pal)
        self.home_view.play_requested.connect(self._on_home_play)
        self.home_view.context_requested.connect(self._on_card_menu)
        self.home_view.more_requested.connect(self._on_shelf_more)
        self.home_view.refresh_requested.connect(lambda: self._load_home(force=True))
        self.home_view.hover_requested.connect(self._on_hover_track)
        lay.addWidget(self.home_view, 1)
        lay.addWidget(t, 1)
        self.now_view = NowPlayingView(self.player, self.cfg, self.pal, self._save_cfg,
                                       self.toggle_fullscreen, self.close_now)
        self.now_view.setVisible(False)
        lay.addWidget(self.now_view, 1)
        return w

    def _build_banner(self) -> QWidget:
        """Eksik program (Deno / FFmpeg vb.) olduğunda içeriğin üstünde çıkan uyarı bandı."""
        self.banner = QFrame()
        self.banner.setObjectName("banner")
        self.banner.setVisible(False)
        row = QHBoxLayout(self.banner)
        row.setContentsMargins(14, 10, 10, 10)
        row.setSpacing(10)
        self.banner_text = QLabel()
        self.banner_text.setWordWrap(True)
        self.banner_copy = QPushButton("Komutu kopyala")
        self.banner_details = QPushButton("Ayrıntılar")
        self.banner_close = QPushButton("✕")
        for b in (self.banner_copy, self.banner_details, self.banner_close):
            b.setObjectName("rowBtn")
            b.setCursor(Qt.CursorShape.PointingHandCursor)
        self.banner_close.setFixedWidth(32)
        self.banner_copy.clicked.connect(lambda: QApplication.clipboard().setText(self._banner_fix))
        self.banner_details.clicked.connect(lambda: self.open_settings(tab=4))
        self.banner_close.clicked.connect(self._dismiss_banner)
        row.addWidget(self.banner_text, 1)
        row.addWidget(self.banner_copy)
        row.addWidget(self.banner_details)
        row.addWidget(self.banner_close)
        return self.banner

    def _run_health_check(self):
        self._banner_dismissed = False
        run_async(health.run_checks, on_result=self._on_health, on_error=lambda m: None)

    def _on_health(self, checks: list):
        self._checks = checks
        bad = health.problems(checks)
        if not bad or self._banner_dismissed:
            self.banner.setVisible(False)
            return
        first = bad[0]
        extra = f"  (+{len(bad) - 1} sorun daha)" if len(bad) > 1 else ""
        self.banner_text.setText(f"⚠ {first.title}: {first.detail}{extra}")
        self._banner_fix = first.fix
        self.banner_copy.setVisible(bool(first.fix))
        self.banner.setVisible(True)

    def _dismiss_banner(self):
        self._banner_dismissed = True
        self.banner.setVisible(False)

    def _build_playlist_header(self) -> QWidget:
        w = QWidget()
        lay = QHBoxLayout(w)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(22)

        self.pl_cover = QLabel()
        self.pl_cover.setFixedSize(150, 150)
        kicker = QLabel("ÇALMA LİSTESİ")
        kicker.setObjectName("section")
        self.pl_name = QLabel()
        self.pl_name.setObjectName("h1")
        self.pl_name.setWordWrap(True)
        self.pl_desc = QLabel()
        self.pl_desc.setObjectName("muted")
        self.pl_desc.setWordWrap(True)
        self.pl_meta = QLabel()
        self.pl_meta.setObjectName("muted")

        self.btn_pl_play = QPushButton("Çal")
        self.btn_pl_play.setObjectName("primary")
        self.btn_pl_shuffle = QPushButton("Karışık çal")
        self.btn_pl_share = QPushButton("Paylaş")
        self.btn_pl_edit = QPushButton("Özelleştir")
        self.btn_pl_delete = QPushButton("Sil")
        for b in (self.btn_pl_shuffle, self.btn_pl_share, self.btn_pl_edit, self.btn_pl_delete):
            b.setObjectName("rowBtn")
        self.btn_pl_play.clicked.connect(lambda: self._play_playlist(self.current_pl))
        self.btn_pl_shuffle.clicked.connect(lambda: self._play_playlist(self.current_pl, True))
        self.btn_pl_edit.clicked.connect(lambda: self._edit_playlist(self.current_pl))
        self.btn_pl_delete.clicked.connect(lambda: self._delete_playlist(self.current_pl))
        self._share_menu = QMenu(self)
        self._fill_share_menu(self._share_menu, lambda: self.current_pl)
        self.btn_pl_share.setMenu(self._share_menu)

        self.sort_box = QComboBox()
        for _k, label in SORTS:
            self.sort_box.addItem(label)
        self.sort_box.currentIndexChanged.connect(self._on_sort_changed)

        btns = QHBoxLayout()
        btns.setSpacing(8)
        for b in (self.btn_pl_play, self.btn_pl_shuffle, self.btn_pl_share,
                  self.btn_pl_edit, self.btn_pl_delete):
            btns.addWidget(b)
        btns.addStretch(1)
        btns.addWidget(self.sort_box)

        col = QVBoxLayout()
        col.setSpacing(4)
        col.addStretch(1)
        col.addWidget(kicker)
        col.addWidget(self.pl_name)
        col.addWidget(self.pl_desc)
        col.addWidget(self.pl_meta)
        col.addSpacing(8)
        col.addLayout(btns)
        col.addStretch(1)

        lay.addWidget(self.pl_cover)
        lay.addLayout(col, 1)
        return w

    def _ctl_button(self, size=36, obj="ctl") -> QPushButton:
        b = QPushButton()
        b.setObjectName(obj)
        b.setFixedSize(size, size)
        b.setIconSize(QSize(int(size * 0.55), int(size * 0.55)))
        b.setCursor(Qt.CursorShape.PointingHandCursor)
        return b

    def _build_player_bar(self) -> QWidget:
        bar = QWidget()
        bar.setObjectName("playerBar")
        bar.setFixedHeight(92)
        lay = QHBoxLayout(bar)
        lay.setContentsMargins(20, 10, 20, 10)
        lay.setSpacing(18)

        # Sol: kapak + başlık/sanatçı
        left = QWidget()
        left.setFixedWidth(290)
        ll = QHBoxLayout(left)
        ll.setContentsMargins(0, 0, 0, 0)
        ll.setSpacing(12)
        self.cover = ClickableLabel()
        self.cover.setToolTip("Çalıyor ekranını aç")
        self.cover.setObjectName("cover")
        self.cover.setFixedSize(60, 60)
        self.cover.setAlignment(Qt.AlignmentFlag.AlignCenter)
        info = QVBoxLayout()
        info.setSpacing(2)
        info.addStretch(1)
        self.np_title = ClickableLabel()
        self.np_title.setText("Çalan parça yok")
        self.np_title.setToolTip("Çalıyor ekranını aç")
        self.np_title.setObjectName("npTitle")
        self.np_title.setFixedWidth(210)
        self.np_artist = ClickableLabel()
        self.np_artist.setText("—")
        self.np_artist.setToolTip("Çalıyor ekranını aç")
        self.np_artist.setObjectName("muted")
        self.np_artist.setFixedWidth(210)
        info.addWidget(self.np_title)
        info.addWidget(self.np_artist)
        info.addStretch(1)
        ll.addWidget(self.cover)
        ll.addLayout(info)

        # Orta: kontroller + ilerleme çubuğu
        self.btn_shuffle = self._ctl_button(34)
        self.btn_prev = self._ctl_button(36)
        self.btn_play = self._ctl_button(44, "playBtn")
        self.btn_next = self._ctl_button(36)
        self.btn_repeat = self._ctl_button(34)
        ctrl = QHBoxLayout()
        ctrl.setSpacing(10)
        ctrl.addStretch(1)
        for b in (self.btn_shuffle, self.btn_prev, self.btn_play, self.btn_next, self.btn_repeat):
            ctrl.addWidget(b)
        ctrl.addStretch(1)

        self.time_cur = QLabel("0:00")
        self.time_cur.setObjectName("muted")
        self.time_total = QLabel("0:00")
        self.time_total.setObjectName("muted")
        self.seek = ClickSlider(Qt.Orientation.Horizontal)
        self.seek.setObjectName("seek")
        self.seek.setRange(0, 0)
        seek_row = QHBoxLayout()
        seek_row.setSpacing(10)
        seek_row.addWidget(self.time_cur)
        seek_row.addWidget(self.seek, 1)
        seek_row.addWidget(self.time_total)
        center = QVBoxLayout()
        center.setSpacing(4)
        center.addLayout(ctrl)
        center.addLayout(seek_row)

        # Sağ: mini oynatıcı düğmesi + ses seviyesi
        right = QWidget()
        right.setFixedWidth(290)
        rl = QHBoxLayout(right)
        rl.setContentsMargins(0, 0, 0, 0)
        rl.setSpacing(8)
        self.btn_expand = self._ctl_button(32)
        self.btn_expand.setToolTip("Çalıyor ekranı · görselleştirici")
        self.btn_like = self._ctl_button(32)
        self.btn_mini = self._ctl_button(32)
        self.btn_mini.setToolTip("Mini oynatıcıya geç")
        self.vol_icon = QLabel()
        self.vol_slider = ClickSlider(Qt.Orientation.Horizontal)
        self.vol_slider.setRange(0, 100)
        self.vol_slider.setValue(int(self.cfg.get("volume", 70)))
        rl.addWidget(self.btn_expand)
        rl.addWidget(self.btn_like)
        rl.addWidget(self.btn_mini)
        rl.addWidget(self.vol_icon)
        rl.addWidget(self.vol_slider, 1)

        lay.addWidget(left)
        lay.addLayout(center, 1)
        lay.addWidget(right)
        return bar

    def _wire_player(self):
        p = self.player
        p.track_changed.connect(self._on_track_changed)
        p.playing_changed.connect(self._on_playing_changed)
        p.position_changed.connect(self._on_position)
        p.duration_changed.connect(self._on_duration)
        p.modes_changed.connect(self._on_modes_changed)
        p.queue_changed.connect(self._on_queue_changed)
        p.status_message.connect(self._on_player_status)
        p.error.connect(lambda m: self.set_status("⚠ " + m))

        self.btn_play.clicked.connect(lambda: p.toggle())
        self.btn_prev.clicked.connect(lambda: p.prev())
        self.btn_next.clicked.connect(lambda: p.next())
        self.btn_shuffle.clicked.connect(lambda: p.toggle_shuffle())
        self.btn_repeat.clicked.connect(lambda: p.cycle_repeat())
        self.btn_mini.clicked.connect(lambda: self.switch_to_mini())
        self.cover.clicked.connect(self.toggle_now)
        self.np_title.clicked.connect(self.toggle_now)
        self.np_artist.clicked.connect(self.toggle_now)
        self.btn_expand.clicked.connect(lambda: self.toggle_now())
        self.btn_like.clicked.connect(lambda: self._toggle_like(self.player.current_track()))
        self.vol_slider.valueChanged.connect(self._on_volume)

        self.seek.sliderPressed.connect(lambda: setattr(self, "_seeking", True))
        self.seek.sliderMoved.connect(lambda v: self.time_cur.setText(fmt_time(v // 1000)))
        self.seek.sliderReleased.connect(self._on_seek_released)

    # =====================================================================
    # Tema
    # =====================================================================
    def apply_theme(self, force: bool = False):
        theme = self.cfg.get("theme", "midnight")
        custom = self.cfg.get("custom_themes") or {}
        accent = (self._dyn_accent if self.cfg.get("dynamic_accent") and self._dyn_accent
                  else self.cfg.get("accent"))
        h = int(self.cfg.get("row_height", 46))
        key = (theme, accent, h, json.dumps(custom, sort_keys=True),
               styles.system_prefers_light() if theme == "auto" else None)
        if key == self._applied_key and not force:
            return                              # değişen bir şey yok
        self._applied_key = key
        self.pal = styles.get_palette(theme, accent, custom)
        QApplication.instance().setStyleSheet(styles.build_qss(theme, accent, custom))
        self.table.verticalHeader().setDefaultSectionSize(h)
        for r in range(self.table.rowCount()):
            self.table.setRowHeight(r, h)
        self._refresh_icons()
        self.mini.apply_palette(self.pal)
        self.now_view.apply_palette(self.pal)
        if self.taskbar:
            self.taskbar.set_palette(self.pal)
        self._highlight_current()

    def _refresh_icons(self):
        c, m = self.pal["text"], self.pal["muted"]
        self.btn_prev.setIcon(icon("prev", c))
        self.btn_next.setIcon(icon("next", c))
        self.btn_mini.setIcon(icon("mini", m))
        self.vol_icon.setPixmap(icon("volume", m).pixmap(20, 20))
        self._on_playing_changed(self.player.is_playing)
        self._on_modes_changed(self.player.shuffle, self.player.repeat)
        self._update_like_icon()
        self._update_expand_icon()

    # =====================================================================
    # Görünümler
    # =====================================================================
    def _set_view(self, view: str, pid: str | None = None):
        self.view, self.current_pl = view, pid
        self._update_visibility()
        self.search_edit.blockSignals(True)
        self.search_edit.clear()
        self.search_edit.blockSignals(False)
        self.search_edit.setPlaceholderText({
            "discover": "Şarkı, sanatçı veya albüm ara…",
            "library": "İndirilenler içinde ara…",
            "queue": "Kuyrukta ara…",
            "playlist": "Bu listede ara…",
            "foryou": "Önerilerde ara…",
            "liked": "Beğenilenlerde ara…",
            "now": "",
            "collection": "Bu listede ara…",
        }[view])
        self._sync_nav()
        self._update_expand_icon()

    def _update_visibility(self):
        """Hangi içerik alanı görünür: ana sayfa rafları / tablo / Çalıyor ekranı."""
        view = self.view
        is_pl, is_now = view == "playlist", view == "now"
        home_mode = view == "discover" and self._discover_mode == "home"
        results_mode = view == "discover" and self._discover_mode == "results"
        self.pl_header.setVisible(is_pl)
        self.title_label.setVisible(not (is_pl or is_now or home_mode))
        self.table.setVisible(not (is_now or home_mode))
        self.home_view.setVisible(home_mode)
        self.now_view.setVisible(is_now)
        self.search_edit.setVisible(not is_now)
        # durum satırı HER görünümde açık kalır: hatalar her ekranda görünsün
        self.mode_box.setVisible(view == "discover")
        self.search_btn.setVisible(view in ("discover", "foryou"))
        self.search_btn.setText("Yenile" if view == "foryou" else "Ara")
        self.btn_back_home.setVisible(results_mode)

    def _update_expand_icon(self):
        self.btn_expand.setIcon(icon("chevron_down" if self.view == "now" else "chevron_up", self.pal["muted"]))

    def _sync_nav(self):
        self.btn_discover.setChecked(self.view == "discover")
        self.btn_library.setChecked(self.view == "library")
        self.btn_queue.setChecked(self.view == "queue")
        self.btn_liked.setChecked(self.view == "liked")
        self.pl_list.clearSelection()
        if self.view == "playlist":
            for i in range(self.pl_list.count()):
                it = self.pl_list.item(i)
                if it.data(Qt.ItemDataRole.UserRole) == self.current_pl:
                    it.setSelected(True)
                    break

    def show_discover(self, results: bool = False):
        """Ana sayfa: arama yapmadan da öneri rafları gelir. results=True: son arama sonuçlarına dön."""
        self._discover_mode = "results" if (results and self._last_results) else "home"
        self._set_view("discover")
        if self._discover_mode == "results":
            self.title_label.setText("Arama sonuçları")
            self.populate(self._last_results)
            self.set_status(f"{len(self._last_results)} sonuç")
        else:
            self.set_status("")
            self._load_home()

    def show_collection(self, title: str, tracks: list):
        """Bir rafın tüm parçaları (rafın başlığına tıklayınca)."""
        self._collection_title, self._collection_tracks = title, list(tracks)
        self._set_view("collection")
        self.title_label.setText(title)
        self._refresh_view()

    def show_library(self):
        self._set_view("library")
        self.title_label.setText("İndirilenler")
        self._refresh_view()

    def show_queue(self):
        self._set_view("queue")
        self.title_label.setText("Kuyruk")
        self._refresh_view()

    def show_foryou(self):
        if self.is_offline:
            self.show_library()
            return
        self._set_view("foryou")
        self.title_label.setText("Sana özel")
        self._refresh_view()
        stale = time.time() - self._rec_time > 6 * 3600
        if self.cfg.get("personalize", True) and (not self._rec_tracks or stale):
            self._load_recommendations()

    def show_now(self):
        if self.view != "now":
            self._prev_view = (self.view, self.current_pl, self._discover_mode)
        self._set_view("now")
        self.set_status("")                      # önceki görünümün "12 sonuç" gibi metni kalmasın
        cur = self.player.current_track()
        if cur:
            self.now_view.set_track(cur)
            if self._cover_pix is not None:
                self.now_view.set_cover(self._cover_pix)

    def toggle_fullscreen(self):
        on = not self.isFullScreen()
        self.showFullScreen() if on else self.showNormal()
        self.sidebar.setVisible(not on)
        self.now_view.set_fullscreen(on)
        if on:
            self.show_now()

    def close_now(self):
        """Çalıyor ekranını kapat, önceki görünüme dön."""
        view, pid, mode = self._prev_view or ("discover", None, "home")
        self._prev_view = None
        if self.isFullScreen():
            self.toggle_fullscreen()
        if view == "playlist" and pid:
            self.show_playlist(pid)
        elif view == "library":
            self.show_library()
        elif view == "queue":
            self.show_queue()
        elif view == "liked":
            self.show_liked()
        elif view == "foryou":
            self.show_foryou()
        elif view == "collection" and self._collection_tracks:
            self.show_collection(self._collection_title, self._collection_tracks)
        else:
            self.show_discover(results=(mode == "results"))

    def toggle_now(self):
        """Alttaki oynatıcı çubuğuna tıklayınca: Çalıyor (görselleştirici) aç/kapat."""
        if self.view == "now":
            self.close_now()
        else:
            self.show_now()

    def keyPressEvent(self, e):
        if e.key() == Qt.Key.Key_F11:
            self.toggle_fullscreen()
        elif e.key() == Qt.Key.Key_Escape and (self.isFullScreen() or self.view == "now"):
            if self.isFullScreen():
                self.toggle_fullscreen()
            else:
                self.close_now()
        else:
            super().keyPressEvent(e)

    def _save_cfg(self):
        config.save(self.cfg)

    def show_liked(self):
        self._set_view("liked")
        self.title_label.setText("Beğenilenler")
        self._refresh_view()

    def show_playlist(self, pid: str):
        pl = self.playlists.get(pid)
        if not pl:
            self.show_library()
            return
        self._set_view("playlist", pid)
        self._fill_playlist_header(pl)
        self._refresh_view()

    def _refresh_view(self, text: str = ""):
        """Kütüphane / kuyruk / çalma listesi görünümünü (filtreli) yeniden doldurur."""
        if self.view == "library":
            tracks = self.library.all()
            empty = "Henüz indirilen şarkı yok. Keşfet bölümünden “İndir”e basın."
            count = "{n} indirilen şarkı"
        elif self.view == "queue":
            tracks = self.player.queue_tracks()
            empty = "Kuyruk boş. Bir listeden çalmaya başlayın ya da parçaya sağ tıklayıp kuyruğa ekleyin."
            count = "{n} parça sırada (en üstteki şu an çalan)"
        elif self.view == "foryou":
            tracks = self._rec_tracks
            if not self.cfg.get("personalize", True):
                empty = "Kişisel öneriler kapalı. Ayarlar > Genel bölümünden açabilirsiniz."
            elif self._rec_loading:
                empty = "Zevk profilin çıkarılıyor, öneriler hazırlanıyor…"
            elif not recommend.enough_data(self.history.entries()):
                empty = "Sana özel öneriler için biraz müzik dinle ya da birkaç şarkıyı ♥ ile beğen."
            else:
                empty = "Öneri bulunamadı. “Yenile”ye basmayı dene."
            count = "{n} öneri"
        elif self.view == "collection":
            tracks = self._collection_tracks
            empty = "Liste boş."
            count = "{n} parça"
        elif self.view == "liked":
            tracks = self.history.liked_tracks()
            empty = "Henüz beğenilen şarkı yok. Çalan şarkının yanındaki ♥ simgesine bas."
            count = "{n} beğenilen şarkı"
        elif self.view == "playlist" and self.current_pl:
            tracks = self.playlists.tracks(self.current_pl)
            empty = "Bu liste boş. Herhangi bir parçaya sağ tıklayıp “Çalma listesine ekle”yi seçin."
            count = "{n} parça"
        else:
            return
        q = text.lower().strip()
        if q:
            tracks = [t for t in tracks if q in f"{t.artist} {t.title}".lower()]
        self.populate(tracks)
        self.set_status(count.format(n=len(tracks)) if tracks else empty)
        if self.view == "foryou" and tracks and self._rec_taste and not q:
            names = ", ".join(n for n, _ in self._rec_taste[:4])
            self.set_status(f"{len(tracks)} öneri · Zevk profilin: {names}")

    def _on_search_text(self, text: str):
        if self.view != "discover":      # diğer görünümlerde yazdıkça filtrele
            self._refresh_view(text)

    def _on_queue_changed(self):
        if self.view == "queue":
            self._queue_timer.start()    # art arda gelen sinyalleri tek yenilemede topla

    def _refresh_queue_view(self):
        if self.view == "queue":
            self._refresh_view(self.search_edit.text())

    # =====================================================================
    # Arama
    # =====================================================================
    def _sp(self) -> SpotifyClient:
        if self.spotify is None:
            cid, secret = self.cfg["spotify_client_id"], self.cfg["spotify_client_secret"]
            if not cid or not secret:
                raise RuntimeError("Spotify için önce Ayarlar > Spotify bölümüne Client ID ve Secret girin.")
            self.spotify = SpotifyClient(cid, secret)
        return self.spotify

    def do_search(self):
        q = self.search_edit.text().strip()
        if self.view != "discover":
            self._refresh_view(q)
            return
        if not q:
            if self._discover_mode == "results":
                self.show_discover()                  # boş arama: ana sayfaya dön
            return
        if self.is_offline:
            self.set_status("⚠ Çevrimdışıyken arama yapılamaz. İndirdiklerin İndirilenler bölümünde.")
            return
        if self.mode_box.currentIndex() != 3 and self.cfg.get("personalize", True):
            self.history.add_search(q)                # ana sayfa önerileri aramalarından beslenir
        self._discover_mode = "results"
        self._update_visibility()
        self.title_label.setText("Arama sonuçları")
        jobs = {
            0: lambda: youtube.search(q),
            1: lambda: self._sp().search_tracks(q),
            2: lambda: self._sp().search_album_tracks(q),
            3: lambda: self._sp().playlist_tracks(q),
        }
        self.search_btn.setEnabled(False)
        self.set_status("Aranıyor…")
        run_async(jobs[self.mode_box.currentIndex()],
                  on_result=self._on_results, on_error=self._on_search_error)

    def _on_results(self, tracks: list):
        self._last_results = tracks
        self.search_btn.setEnabled(True)
        if self.view == "discover" and self._discover_mode == "results":
            self.populate(tracks)
            self.set_status(f"{len(tracks)} sonuç" if tracks else "Sonuç bulunamadı.")

    def _on_search_error(self, msg: str):
        self.search_btn.setEnabled(True)
        self.set_status("⚠ " + msg)

    # =====================================================================
    # Tablo
    # =====================================================================
    def populate(self, tracks: list[Track]):
        self.shown = tracks
        self.table.setRowCount(0)
        self.table.setRowCount(len(tracks))
        for r, t in enumerate(tracks):
            title_item = QTableWidgetItem(t.title)
            if self.view == "foryou":
                title_item.setToolTip(self._rec_reasons.get(t.id, ""))
            self.table.setItem(r, 0, title_item)
            self.table.setItem(r, 1, QTableWidgetItem(t.artist))
            self.table.setItem(r, 2, QTableWidgetItem(fmt_time(t.duration) if t.duration else "—"))
            cell = self._action_cell(t)
            if cell:
                self.table.setCellWidget(r, 3, cell)
        self._highlight_current()

    def _action_cell(self, track: Track) -> QWidget | None:
        if self.view == "queue":
            return None
        btn = QPushButton()
        btn.setObjectName("rowBtn")
        btn.setCursor(Qt.CursorShape.PointingHandCursor)
        if self.view == "library":
            btn.setText("Sil")
            btn.clicked.connect(lambda: self.delete_track(track))
        elif self.view == "playlist":
            btn.setText("Kaldır")
            btn.clicked.connect(lambda: self._remove_from_playlist(track))
        elif self.library.is_downloaded(track.id):
            btn.setText("✓ İndirildi")
            btn.setEnabled(False)
        else:
            btn.setText("İndir")
            btn.clicked.connect(lambda: self.download_track(track, btn))
        cell = QWidget()
        lay = QHBoxLayout(cell)
        lay.setContentsMargins(0, 4, 8, 4)
        lay.addWidget(btn)
        return cell

    def _highlight_current(self):
        cur = self.player.current_track()
        for r, t in enumerate(self.shown):
            playing = cur is not None and t.id == cur.id
            color = QColor(self.pal["accent"] if playing else self.pal["text"])
            font = QFont(self.font())
            font.setBold(playing)
            for c in range(3):
                item = self.table.item(r, c)
                if item:
                    item.setForeground(color)
                    item.setFont(font)

    def _on_row_clicked(self, row: int, _col: int = 0):
        """Satıra tek tıkla çalar; çalan şarkıya tekrar tıklamak duraklatır/devam ettirir."""
        if not (0 <= row < len(self.shown)):
            return
        cur = self.player.current_track()
        if self.view != "queue" and cur is not None and cur.id == self.shown[row].id:
            self.player.toggle()
            return
        self._on_row_activated(row)

    def _on_row_activated(self, row: int, _col: int = 0):
        if not (0 <= row < len(self.shown)):
            return
        if self.view == "queue":
            self.player.jump(row)
        else:
            self.player.set_queue(self.shown, row)

    # ---- sağ tık menüsü -------------------------------------------------
    def _on_table_menu(self, pos):
        row = self.table.rowAt(pos.y())
        if not (0 <= row < len(self.shown)):
            return
        self._show_track_menu(self.shown[row], row, self.table.viewport().mapToGlobal(pos))

    def _on_card_menu(self, track: Track, global_pos):
        self._show_track_menu(track, -1, global_pos)

    def _show_track_menu(self, track: Track, row: int, global_pos):
        """Parça sağ tık menüsü (tablo satırı ya da ana sayfa kartı için ortak)."""
        menu = QMenu(self)
        _act(menu, "Çal", lambda: self._on_row_activated(row) if row >= 0 else self.player.set_queue([track], 0))
        _act(menu, "Sıradaki olarak çal", lambda: self._enqueue(track, True))
        _act(menu, "Kuyruğa ekle", lambda: self._enqueue(track, False))
        menu.addSeparator()
        liked = self.history.is_liked(track.id)
        _act(menu, "♥ Beğenmekten vazgeç" if liked else "♥ Beğen", lambda: self._toggle_like(track))
        _act(menu, "Benzer şarkıları çal (radyo)", lambda: self._start_radio(track),
             not self.is_offline and track.source != "local")
        menu.addSeparator()

        sub = menu.addMenu("Çalma listesine ekle")
        for pl in self.playlists.all():
            _act(sub, f"{pl.emoji}  {pl.name}",
                 lambda pid=pl.id: self._add_to_playlist(pid, [track]))
        if self.playlists.all():
            sub.addSeparator()
        _act(sub, "＋ Yeni çalma listesi…", lambda: self._new_playlist([track]))

        if self.view == "playlist" and self.current_pl and row >= 0:
            pl = self.playlists.get(self.current_pl)
            movable = bool(pl) and pl.sort == "manual" and not self.search_edit.text().strip()
            menu.addSeparator()
            _act(menu, "Yukarı taşı", lambda: self._move_in_playlist(row, -1), movable and row > 0)
            _act(menu, "Aşağı taşı", lambda: self._move_in_playlist(row, +1),
                 movable and row < len(self.shown) - 1)
            _act(menu, "Listeden kaldır", lambda: self._remove_from_playlist(track))

        menu.addSeparator()
        if track.source != "local" and not self.library.is_downloaded(track.id):
            _act(menu, "İndir", lambda: self.download_track(track), not self.is_offline)
        if track.url:
            _act(menu, "YouTube bağlantısını kopyala",
                 lambda: QApplication.clipboard().setText(track.url))
        if self.view == "library":
            _act(menu, "Cihazdan sil", lambda: self.delete_track(track))
        menu.exec(global_pos)

    def _enqueue(self, track: Track, play_next: bool):
        self.player.enqueue(track, play_next)
        self.set_status("Sıradaki olarak eklendi." if play_next else "Kuyruğa eklendi.")

    # =====================================================================
    # İndirme / silme
    # =====================================================================
    def download_track(self, track: Track, btn: QPushButton | None = None):
        if track.source == "local" or self.library.is_downloaded(track.id):
            return
        if self.is_offline:
            self.set_status("⚠ Çevrimdışıyken indirme yapılamaz.")
            return

        def safe(fn):  # tablo yenilenmişse düğme silinmiş olabilir
            if btn is None:
                return
            try:
                fn()
            except RuntimeError:
                pass

        safe(lambda: (btn.setEnabled(False), btn.setText("0%")))
        self.set_status(f"İndiriliyor: {track.title}")

        def on_progress(p):
            safe(lambda: btn.setText(f"{p}%"))

        def on_result(path):
            track.local_path = str(path)
            self.library.add(track)
            safe(lambda: btn.setText("✓ İndirildi"))
            self.tray.notify("İndirme tamamlandı", track.title)
            self.set_status(f"İndirildi: {track.title}")
            if self.view == "discover" and self._discover_mode == "home":
                self._update_local_home_shelves()

        def on_error(msg):
            safe(lambda: (btn.setText("İndir"), btn.setEnabled(True)))
            self.set_status("⚠ İndirme hatası: " + msg)

        run_async(youtube.download, track, Path(self.cfg["download_dir"]),
                  on_progress=on_progress, on_result=on_result, on_error=on_error)

    def delete_track(self, track: Track):
        answer = QMessageBox.question(self, "Sil", f"“{track.title}” cihazdan silinsin mi?")
        if answer != QMessageBox.StandardButton.Yes:
            return
        cur = self.player.current_track()
        if cur is not None and cur.id == track.id:
            self.player.stop()  # çalan dosya Windows'ta kilitli olur
        try:
            self.library.remove(track)
        except OSError as exc:
            self.set_status(f"⚠ Silinemedi: {exc}")
            return
        self._refresh_view(self.search_edit.text())

    # =====================================================================
    # Çalma listeleri
    # =====================================================================
    def _reload_playlist_list(self):
        self.pl_list.clear()
        for pl in self.playlists.all():
            it = QListWidgetItem(QIcon(render_cover(pl, 28)), pl.name)
            it.setData(Qt.ItemDataRole.UserRole, pl.id)
            it.setToolTip(f"{len(pl.tracks)} parça")
            self.pl_list.addItem(it)
        self._sync_nav()

    def _on_pl_clicked(self, item: QListWidgetItem):
        self.show_playlist(item.data(Qt.ItemDataRole.UserRole))

    def _on_pl_menu(self, pos):
        item = self.pl_list.itemAt(pos)
        if not item:
            return
        pid = item.data(Qt.ItemDataRole.UserRole)
        menu = QMenu(self)
        _act(menu, "Çal", lambda: self._play_playlist(pid))
        _act(menu, "Karışık çal", lambda: self._play_playlist(pid, True))
        menu.addSeparator()
        _act(menu, "Özelleştir…", lambda: self._edit_playlist(pid))
        self._fill_share_menu(menu.addMenu("Paylaş"), lambda: pid)
        menu.addSeparator()
        _act(menu, "Sil", lambda: self._delete_playlist(pid))
        menu.exec(self.pl_list.viewport().mapToGlobal(pos))

    def _fill_playlist_header(self, pl: pls.Playlist):
        self.pl_cover.setPixmap(render_cover(pl, 150))
        self.pl_name.setText(f"{pl.emoji}  {pl.name}" if pl.cover_path else pl.name)
        self.pl_desc.setText(pl.description)
        self.pl_desc.setVisible(bool(pl.description))
        total = sum(int(t.get("duration", 0) or 0) for t in pl.tracks)
        self.pl_meta.setText(f"{len(pl.tracks)} parça · {fmt_time(total)}")
        self.sort_box.blockSignals(True)
        self.sort_box.setCurrentIndex([k for k, _ in SORTS].index(pl.sort))
        self.sort_box.blockSignals(False)

    def _after_playlist_change(self, pid: str):
        self._reload_playlist_list()
        if self.view == "playlist" and self.current_pl == pid:
            pl = self.playlists.get(pid)
            if pl:
                self._fill_playlist_header(pl)
                self._refresh_view(self.search_edit.text())

    def _on_sort_changed(self, index: int):
        if self.view == "playlist" and self.current_pl:
            self.playlists.update(self.current_pl, sort=SORTS[index][0])
            self._refresh_view(self.search_edit.text())

    def _play_playlist(self, pid: str | None, shuffle: bool = False):
        tracks = self.playlists.tracks(pid) if pid else []
        if not tracks:
            self.set_status("Bu liste boş.")
            return
        if shuffle:
            self.player.play_shuffled(tracks)
        else:
            self.player.set_queue(tracks, 0, shuffle=False)

    def _apply_cover(self, pid: str, src: str | None):
        if src is None:        # değişmedi
            return
        dest = config.COVER_DIR / f"{pid}.png"
        if src == "":
            try:
                dest.unlink(missing_ok=True)
            except OSError:
                pass
            self.playlists.update(pid, cover_path="")
        elif save_cover(src, dest):
            self.playlists.update(pid, cover_path=str(dest))
        else:
            self.set_status("⚠ Görsel okunamadı.")

    def _new_playlist(self, tracks: list[Track] | None = None):
        dlg = PlaylistDialog(None, self)
        if dlg.exec() != QDialog.DialogCode.Accepted:
            return
        v = dlg.values()
        src = v.pop("cover_src")
        pl = self.playlists.create(v["name"], v["description"], v["color"], v["emoji"])
        self._apply_cover(pl.id, src)
        if tracks:
            self.playlists.add_tracks(pl.id, tracks)
        self._reload_playlist_list()
        self.show_playlist(pl.id)

    def _edit_playlist(self, pid: str | None):
        pl = self.playlists.get(pid) if pid else None
        if not pl:
            return
        dlg = PlaylistDialog(pl, self)
        if dlg.exec() != QDialog.DialogCode.Accepted:
            return
        v = dlg.values()
        src = v.pop("cover_src")
        self.playlists.update(pid, **v)
        self._apply_cover(pid, src)
        self._after_playlist_change(pid)

    def _delete_playlist(self, pid: str | None):
        pl = self.playlists.get(pid) if pid else None
        if not pl:
            return
        answer = QMessageBox.question(self, "Sil", f"“{pl.name}” listesi silinsin mi?\n"
                                      "(Şarkılar cihazdan silinmez.)")
        if answer != QMessageBox.StandardButton.Yes:
            return
        self.playlists.delete(pid)
        self._reload_playlist_list()
        if self.view == "playlist" and self.current_pl == pid:
            self.show_library()

    def _add_to_playlist(self, pid: str, tracks: list[Track]):
        pl = self.playlists.get(pid)
        if not pl:
            return
        n = self.playlists.add_tracks(pid, tracks)
        self.set_status(f"{n} parça “{pl.name}” listesine eklendi." if n
                        else f"Parça zaten “{pl.name}” listesinde.")
        self._after_playlist_change(pid)

    def _remove_from_playlist(self, track: Track):
        if self.current_pl:
            self.playlists.remove_track(self.current_pl, track.id)
            self._after_playlist_change(self.current_pl)

    def _move_in_playlist(self, row: int, delta: int):
        if self.current_pl:
            self.playlists.move_track(self.current_pl, row, delta)
            self._after_playlist_change(self.current_pl)
            self.table.selectRow(row + delta)

    # ---- paylaşım / içe aktarma ----------------------------------------
    def _fill_share_menu(self, menu: QMenu, get_pid):
        _act(menu, "Paylaşım kodunu kopyala", lambda: self._share_copy(get_pid()))
        _act(menu, "Dosya olarak dışa aktar (.nwpl)…", lambda: self._share_file(get_pid()))
        _act(menu, "M3U olarak dışa aktar (başka oynatıcılar için)…", lambda: self._share_m3u(get_pid()))

    def _share_copy(self, pid: str | None):
        pl = self.playlists.get(pid) if pid else None
        if not pl:
            return
        tracks = self.playlists.tracks(pid)
        code, skipped = pls.to_share_code(pl, tracks)
        shared = len(tracks) - skipped
        if shared == 0:
            self.set_status("⚠ Listede paylaşılabilir parça yok (yerel dosyalar paylaşılamaz).")
            return
        QApplication.clipboard().setText(code)
        msg = f"Paylaşım kodu panoya kopyalandı ({shared} parça)."
        if skipped:
            msg += f" {skipped} yerel dosya paylaşılamadığı için atlandı."
        self.set_status(msg)
        self.tray.notify("Paylaşım kodu kopyalandı",
                         "Arkadaşınıza gönderin: İçe aktar menüsünden yapıştırsın.")

    def _share_file(self, pid: str | None):
        pl = self.playlists.get(pid) if pid else None
        if not pl:
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Çalma listesini dışa aktar", f"{_safe_filename(pl.name)}.nwpl",
            "NightWave listesi (*.nwpl)")
        if not path:
            return
        try:
            skipped = pls.export_file(pl, self.playlists.tracks(pid), Path(path))
        except OSError as exc:
            self.set_status(f"⚠ Dosya yazılamadı: {exc}")
            return
        self.set_status("Dışa aktarıldı." + (f" {skipped} yerel dosya atlandı." if skipped else ""))

    def _share_m3u(self, pid: str | None):
        pl = self.playlists.get(pid) if pid else None
        if not pl:
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "M3U olarak dışa aktar", f"{_safe_filename(pl.name)}.m3u8", "M3U listesi (*.m3u8)")
        if not path:
            return
        tracks = self.playlists.tracks(pid)
        for t in tracks:                       # indirilenler için yerel yolu ekle
            t.local_path = self.library.path_for(t.id) or ""
        try:
            pls.export_m3u(pl, tracks, Path(path))
        except OSError as exc:
            self.set_status(f"⚠ Dosya yazılamadı: {exc}")
            return
        self.set_status("M3U listesi kaydedildi.")

    def _imported(self, pl: pls.Playlist):
        self.playlists.add(pl)
        self._reload_playlist_list()
        self.show_playlist(pl.id)
        self.set_status(f"“{pl.name}” içe aktarıldı ({len(pl.tracks)} parça).")

    def _import_code(self):
        clip = QApplication.clipboard().text().strip()
        prefill = clip if clip.startswith(pls.SHARE_PREFIX) else ""
        text, ok = QInputDialog.getMultiLineText(
            self, "İçe aktar", "Arkadaşınızdan aldığınız paylaşım kodunu yapıştırın:", prefill)
        if not ok or not text.strip():
            return
        try:
            self._imported(pls.from_share_code(text))
        except ValueError as exc:
            QMessageBox.warning(self, "İçe aktarılamadı", str(exc))

    def _import_file(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Çalma listesi dosyası seç", "",
            "NightWave listesi (*.nwpl *.json *.txt);;Tüm dosyalar (*)")
        if not path:
            return
        try:
            self._imported(pls.import_file(Path(path)))
        except (ValueError, OSError) as exc:
            QMessageBox.warning(self, "İçe aktarılamadı", str(exc))

    # =====================================================================
    # Ana sayfa: arama yapmadan da gelen öneri rafları
    # =====================================================================
    def _set_shelf(self, key: str, order: int, title: str, subtitle: str, tracks: list,
                   reasons: dict | None = None, more: bool = False):
        self._shelf_data[key] = (title, list(tracks))
        self.home_view.upsert(key, order, title, subtitle, tracks, reasons, more)

    def _set_foryou_shelf(self, tracks: list, reasons: dict):
        names = ", ".join(n for n, _ in self._rec_taste[:3])
        sub = f"Dinlediklerine göre · {names}" if names else "Dinlediklerine ve aramalarına göre"
        self._set_shelf("foryou", 10, "Sana özel", sub, tracks, reasons, more=True)

    def _update_local_home_shelves(self):
        """İnternet gerektirmeyen raflar: anında görünür."""
        personal = self.cfg.get("personalize", True)
        self._set_shelf("recent", 30, "Son dinlediklerin", "Kaldığın yerden devam et",
                        self.history.recent(15) if personal else [])
        self._set_shelf("liked", 31, "Beğendiklerin", "♥ ile işaretlediklerin",
                        self.history.liked_tracks()[:18])
        self._set_shelf("downloads", 32, "İndirdiklerin", "Çevrimdışı da çalar", self.library.all()[:18])

    def _cache_maintenance(self):
        """Arka plan: FFmpeg varsa ham (çalmayabilen) önbellek dosyalarını sil, boyut sınırını uygula."""
        if health.find_ffmpeg() and not (self.player.progressive and self.player.raw_ok):
            self.cache.purge_non_mp3()                # ham dosyalar yalnızca MP3'e geçildiyse temizlenir
        self.cache.trim()

    def _on_raw_failed(self):
        """Ham ses bu sistemde çalmadı: MP3'e geçildi. Kalıcı kaydet ki bir daha denenmesin."""
        self.cfg["raw_ok"] = False
        config.save(self.cfg)
        self.set_status("Bu sistemde ham ses çalmıyor: uyumlu biçime (MP3) geçildi. Ayar kaydedildi.")

    def _on_hover_track(self, track):
        """Karta/satıra fare gelince 0,45 sn sonra şarkıyı arka planda hazırla: tıklayınca anında başlasın."""
        self._hover_track = track
        if track is None:
            self._hover_timer.stop()
        else:
            self._hover_timer.start(450)

    def _on_row_hover(self, row: int, _col: int = 0):
        if 0 <= row < len(self.shown):
            self._on_hover_track(self.shown[row])

    def _hover_fire(self):
        if self._hover_track is not None and not self.is_offline:
            self.player.prefetch_track(self._hover_track)

    def _load_home(self, force: bool = False):
        """Önce önbellekteki/yerel rafları göster, sonra ağdan tazele (bayat olanları)."""
        self.home_view.set_greeting(home_data.greeting(time.localtime().tm_hour),
                                    "Senin için seçtiklerimiz")
        self._update_local_home_shelves()
        genres = home_data.valid_genres(self.cfg.get("home_genres"))
        for key in list(self.home_view.keys()):                       # artık seçili olmayan türleri kaldır
            if key.startswith("g:") and key[2:] not in genres:
                self.home_view.remove(key)
        personal = self.cfg.get("personalize", True)
        searches = self.history.recent_searches(2) if personal else []

        # 1) önbellek: internet beklemeden dolu görünsün
        for i, key in enumerate(genres):
            cached = self.home_cache.get("g:" + key)
            if cached and cached[0]:
                self._set_shelf("g:" + key, 40 + i, home_data.GENRE_MAP[key][0], "Senin için seçtik", cached[0])
        if personal:
            cached = self.home_cache.get("foryou")
            if cached and cached[0]:
                self._set_foryou_shelf(cached[0], {})
            for j, q in enumerate(searches):
                cached = self.home_cache.get("q:" + q.lower())
                if cached and cached[0]:
                    self._set_shelf(f"q{j}", 20 + j, f"“{q}” aramana göre", "Aramalarına göre", cached[0])

        if self.is_offline:
            self.home_view.set_message("" if self.home_view.keys() else
                                       "Çevrimdışısın. İnternet gelince öneriler burada görünür; "
                                       "indirdiklerin İndirilenler bölümünde.")
            return
        if self._home_pending > 0 and not force:
            return

        # 2) ağdan tazele
        jobs = []
        for i, key in enumerate(genres):
            if force or not self.home_cache.is_fresh("g:" + key):
                query = home_data.GENRE_MAP[key][1]
                jobs.append((youtube.search, (query, 30), lambda tr, k=key, i=i: self._on_home_genre(k, i, tr)))
        if personal:
            entries = self.history.entries()
            if recommend.enough_data(entries) and (force or not self.home_cache.is_fresh("foryou", 2 * 3600)):
                jobs.append((recommend.build, (entries,), self._on_home_foryou))
            for j, q in enumerate(searches):
                if force or not self.home_cache.is_fresh("q:" + q.lower(), 2 * 3600):
                    jobs.append((recommend.from_query, (q,), lambda res, q=q, j=j: self._on_home_query(j, q, res)))
        self._home_pending, self._home_error = len(jobs), ""
        if jobs and not self.home_view.keys():
            self.home_view.set_message("Öneriler yükleniyor…")
        elif not jobs and not self.home_view.keys():
            self.home_view.set_message("Henüz öneri yok. Bir şarkı ara ya da dinle; burası sana göre şekillenecek.")
        for fn, args, cb in jobs:
            run_async(fn, *args, on_result=cb, on_error=self._home_failed)

    def _home_finish(self, error: str = ""):
        self._home_pending = max(0, self._home_pending - 1)
        if error:
            self._home_error = error
        if self._home_pending == 0 and not self.home_view.keys():
            self.home_view.set_message(("Ana sayfa içeriği yüklenemedi: " + self._home_error) if self._home_error
                                       else "Henüz öneri yok. Bir şarkı ara ya da dinle.")

    def _home_failed(self, msg: str):
        self._home_finish(msg)

    def _on_home_genre(self, key: str, index: int, tracks: list):
        self._home_finish()
        if key not in home_data.valid_genres(self.cfg.get("home_genres")):
            return
        tracks = home_data.clean_shelf(tracks)
        if tracks:
            self.home_cache.put("g:" + key, tracks)
            self._set_shelf("g:" + key, 40 + index, home_data.GENRE_MAP[key][0], "Senin için seçtik", tracks)

    def _on_home_foryou(self, res: dict):
        self._home_finish()
        self._on_recs(res)                            # 'Sana özel' tam liste görünümünü de günceller
        tracks = res["tracks"][:18]
        if tracks:
            self.home_cache.put("foryou", tracks)
            self._set_foryou_shelf(tracks, res["reasons"])

    def _on_home_query(self, j: int, q: str, res: dict):
        self._home_finish()
        tracks = res["tracks"][:18]
        if tracks:
            self.home_cache.put("q:" + q.lower(), tracks)
            self._set_shelf(f"q{j}", 20 + j, f"“{q}” aramana göre", "Aramalarına göre", tracks, res["reasons"])

    def _on_home_play(self, tracks: list, index: int):
        """Karta tıklayınca: o rafı kuyruk yapıp çalar; çalan karta tekrar tıklamak duraklatır."""
        cur = self.player.current_track()
        if cur is not None and 0 <= index < len(tracks) and cur.id == tracks[index].id:
            self.player.toggle()
        else:
            self.player.set_queue(tracks, index)

    def _on_shelf_more(self, key: str):
        if key == "foryou":
            self.show_foryou()
            return
        title, tracks = self._shelf_data.get(key, ("", []))
        if tracks:
            self.show_collection(title, tracks)

    # =====================================================================
    # Kişisel öneriler, beğeniler, radyo
    # =====================================================================
    def _on_search_button(self):
        if self.view == "foryou":
            self._load_recommendations()          # "Yenile"
        else:
            self.do_search()

    def _load_recommendations(self):
        if self._rec_loading or not self.cfg.get("personalize", True):
            return
        entries = self.history.entries()
        if not recommend.enough_data(entries):
            self._refresh_view()
            return
        self._rec_loading = True
        self.search_btn.setEnabled(False)
        self.set_status("Sana özel öneriler hazırlanıyor…")
        run_async(recommend.build, entries, on_result=self._on_recs, on_error=self._on_recs_error)

    def _on_recs(self, res: dict):
        self._rec_loading = False
        self.search_btn.setEnabled(True)
        self._rec_tracks, self._rec_reasons = res["tracks"], res["reasons"]
        self._rec_taste, self._rec_time = res["taste"], time.time()
        if self.view == "foryou":
            self._refresh_view(self.search_edit.text())

    def _on_recs_error(self, msg: str):
        self._rec_loading = False
        self.search_btn.setEnabled(True)
        self.set_status("⚠ " + msg)

    def _toggle_like(self, track: Track | None):
        if track is None:
            return
        liked = self.history.toggle_like(track)
        self._update_like_icon()
        self.set_status("♥ Beğenilenlere eklendi." if liked else "Beğenilenlerden çıkarıldı.")
        if self.view == "discover" and self._discover_mode == "home":
            self._update_local_home_shelves()
        if self.view == "liked":
            self._refresh_view(self.search_edit.text())

    def _update_like_icon(self):
        cur = self.player.current_track()
        liked = cur is not None and self.history.is_liked(cur.id)
        self.btn_like.setIcon(icon("heart_fill" if liked else "heart",
                                   self.pal["accent"] if liked else self.pal["muted"]))
        self.btn_like.setToolTip("Beğenmekten vazgeç" if liked else "Beğen")

    def _start_radio(self, track: Track):
        """YouTube'un 'Mix' listesiyle bu şarkıya benzer parçaları kuyruğa alıp çalar."""
        if self.is_offline:
            self.set_status("⚠ Radyo için internet gerekir.")
            return
        self.set_status("Benzer şarkılar aranıyor…")

        def work():
            from core import youtube as yt
            return yt.related(recommend.youtube_id_for(track), 30)

        def done(similar):
            queue = [track] + [t for t in similar if t.id != track.id]
            self.player.set_queue(queue, 0, shuffle=False)
            self.set_status(f"Radyo: {len(queue) - 1} benzer şarkı kuyruğa alındı.")

        run_async(work, on_result=done, on_error=lambda m: self.set_status("⚠ " + m))

    def _finalize_play(self):
        """Biten/geçilen parçanın dinleme süresini geçmişe işler (kişisel öneriler için)."""
        t, self._play_track = self._play_track, None
        if t is None or not self.cfg.get("personalize", True):
            return
        self.history.record(t, self._play_max_pos, self._play_dur or t.duration * 1000)

    def _on_player_status(self, msg: str):
        self.set_status(msg)
        if self.taskbar:
            self.taskbar.set_loading(bool(msg))   # "Akış hazırlanıyor…" -> görev çubuğunda belirsiz animasyon

    # =====================================================================
    # Görev çubuğu
    # =====================================================================
    def _ensure_taskbar(self):
        want = sys.platform == "win32" and self.cfg.get("taskbar", True)
        if not want:
            if self.taskbar:
                self.taskbar.shutdown()
                self.taskbar.deleteLater()
                self.taskbar = None
            return
        if self.taskbar is None and not self._taskbar_failed and self.isVisible():
            tb = TaskbarIntegration(self, self.pal, self)
            if not tb.ok:
                self._taskbar_failed = True       # her gösterimde tekrar denemeyelim
                tb.deleteLater()
                return
            tb.prev_clicked.connect(lambda: self.player.prev())
            tb.toggle_clicked.connect(lambda: self.player.toggle())
            tb.next_clicked.connect(lambda: self.player.next())
            self.taskbar = tb
            if self.player.current_track():
                tb.set_playing(self.player.is_playing)

    def showEvent(self, event):
        super().showEvent(event)
        QTimer.singleShot(0, self._ensure_taskbar)

    # =====================================================================
    # Oynatıcı olayları
    # =====================================================================
    def _on_track_changed(self, track: Track):
        self._finalize_play()                    # biten parçayı dinleme geçmişine işle
        self._play_track, self._play_max_pos, self._play_dur = track, 0, track.duration * 1000
        set_elided(self.np_title, track.title)
        set_elided(self.np_artist, track.artist or "—")
        self.cover.clear()
        self._cover_pix = None
        self.now_view.set_track(track)
        self.time_cur.setText("0:00")
        self.seek.setValue(0)
        self.seek.setMaximum(track.duration * 1000)
        self.time_total.setText(fmt_time(track.duration))
        self._highlight_current()
        if self.sysmedia:
            self.sysmedia.set_track(track)
        self._update_like_icon()
        if self.taskbar:
            self.taskbar.new_track()
        if (self.cfg.get("dynamic_accent") and self._dyn_accent
                and not (track.thumbnail and not self.is_offline)):
            self._dyn_accent = None              # kapağı olmayan parça: sabit vurguya dön
            self.apply_theme()
        if track.thumbnail and not self.is_offline:
            run_async(network.fetch_bytes, track.thumbnail,
                      on_result=lambda data: self._set_cover(data, track.id))

    def _set_cover(self, data: bytes, track_id: str):
        cur = self.player.current_track()
        if cur is None or cur.id != track_id:
            return
        pix = QPixmap()
        if pix.loadFromData(data):
            self._cover_pix = pix
            self.cover.setPixmap(pix.scaled(
                60, 60, Qt.AspectRatioMode.KeepAspectRatioByExpanding,
                Qt.TransformationMode.SmoothTransformation))
            self.mini.set_cover(pix)
            self.now_view.set_cover(pix)
            if self.cfg.get("dynamic_accent"):
                color = dominant_color(pix)
                if color and color != self._dyn_accent:
                    self._dyn_accent = color
                    self.apply_theme()

    def _on_playing_changed(self, playing: bool):
        self.btn_play.setIcon(icon("pause" if playing else "play", self.pal["bg"]))
        if self.sysmedia:
            self.sysmedia.set_playing(playing)
        if self.taskbar:
            self.taskbar.set_playing(playing)

    def _on_modes_changed(self, shuffle: bool, repeat: str):
        on, off = self.pal["accent"], self.pal["muted"]
        self.btn_shuffle.setIcon(icon("shuffle", on if shuffle else off))
        self.btn_repeat.setIcon(icon("repeat1" if repeat == "one" else "repeat",
                                     on if repeat != "off" else off))
        self.btn_shuffle.setToolTip("Karışık çal: " + ("Açık" if shuffle else "Kapalı"))
        self.btn_repeat.setToolTip(REPEAT_TIPS.get(repeat, "Tekrar"))

    def _on_position(self, ms: int):
        self._play_max_pos = max(self._play_max_pos, ms)
        if self.taskbar:
            self.taskbar.set_progress(ms, self.seek.maximum())
        if not self._seeking:
            self.seek.setValue(ms)
            self.time_cur.setText(fmt_time(ms // 1000))

    def _on_duration(self, ms: int):
        if ms > 0:
            self._play_dur = ms
            self.seek.setMaximum(ms)
            self.time_total.setText(fmt_time(ms // 1000))
            if self.sysmedia:
                self.sysmedia.set_timeline(self.player.position(), ms)

    def _on_seek_released(self):
        self._seeking = False
        self.player.seek(self.seek.value())
        if self.sysmedia:
            self.sysmedia.set_timeline(self.seek.value(), self.seek.maximum())

    def _on_volume(self, value: int):
        self.player.set_volume(value)
        self.cfg["volume"] = value

    # =====================================================================
    # Medya tuşları / SMTC
    # =====================================================================
    def _setup_system_media(self):
        if self.sysmedia is not None:
            self.sysmedia.shutdown()
            self.sysmedia.deleteLater()
            self.sysmedia = None
        if not self.cfg.get("media_keys", True):
            return
        sm = SystemMedia(self)
        if sm.backend == "yok":
            sm.deleteLater()
            return
        sm.play_pressed.connect(self._sm_play)
        sm.pause_pressed.connect(self._sm_pause)
        sm.toggle_pressed.connect(lambda: self.player.toggle())
        sm.next_pressed.connect(lambda: self.player.next())
        sm.prev_pressed.connect(lambda: self.player.prev())
        sm.stop_pressed.connect(lambda: self.player.stop())
        sm.seek_requested.connect(lambda ms: self.player.seek(ms))
        self.sysmedia = sm
        cur = self.player.current_track()
        if cur:
            sm.set_track(cur)
            sm.set_playing(self.player.is_playing)

    def _sm_play(self):
        if not self.player.is_playing:
            self.player.toggle()

    def _sm_pause(self):
        if self.player.is_playing:
            self.player.toggle()

    # =====================================================================
    # Ağ / çevrimdışı mod
    # =====================================================================
    def _check_network(self):
        run_async(network.is_online, on_result=self._set_online)

    def _set_online(self, ok: bool):
        self.online = bool(ok)
        self._refresh_mode_ui()

    def _toggle_force_offline(self, checked: bool):
        self.force_offline = checked
        self._refresh_mode_ui()

    def _refresh_mode_ui(self):
        off = self.is_offline
        if self.force_offline:
            text = "● Çevrimdışı (manuel)"
        elif not self.online:
            text = "● Bağlantı yok · Çevrimdışı mod"
        else:
            text = "● Çevrimiçi"
        self.net_label.setText(text)
        self.net_label.setStyleSheet(f"color: {'#E0A458' if off else '#4ADE80'};")
        self.btn_offline.setText("Çevrimiçi moda dön" if self.force_offline else "Çevrimdışı modu aç")
        self.btn_discover.setEnabled(True)           # ana sayfa çevrimdışıyken de açılır (yerel raflar)
        self.mode_box.setEnabled(not off)
        if off != self._last_off:
            self._last_off = off
            if self.view == "discover" and self._discover_mode == "home":
                self._load_home()

    # =====================================================================
    # Mini oynatıcı ↔ ana pencere
    # =====================================================================
    def _place_mini(self):
        pos = self.cfg.get("mini_pos")
        if isinstance(pos, (list, tuple)) and len(pos) == 2:
            x, y = int(pos[0]), int(pos[1])
            if any(s.availableGeometry().contains(x + 20, y + 20) for s in QGuiApplication.screens()):
                self.mini.move(x, y)
                return
        geo = QGuiApplication.primaryScreen().availableGeometry()
        self.mini.move(geo.right() - self.mini.width() - 24, geo.bottom() - self.mini.height() - 24)

    def switch_to_mini(self):
        self.mini.apply_viz_settings(self.cfg)
        self._place_mini()
        self.mini.set_cover(self._cover_pix)
        self.mini.show()
        self.mini.raise_()
        self.hide()

    def switch_to_main(self):
        self.mini.hide()
        self.showNormal()
        self.raise_()
        self.activateWindow()

    def toggle_mini(self):
        if self.mini.isVisible():
            self.switch_to_main()
        else:
            self.switch_to_mini()

    # =====================================================================
    # Ayarlar, durum, kapanış
    # =====================================================================
    def open_settings(self, tab: int = 0):
        backend = self.sysmedia.backend if self.sysmedia else "kapalı"
        dlg = SettingsDialog(self.cfg, backend, bool(self.taskbar and self.taskbar.ok),
                             self.history.total_plays(), self._checks, tab, self,
                             cache_used_mb=int(self.cache.size() / 1048576))
        if dlg.exec() != QDialog.DialogCode.Accepted:
            return
        old_media, old_taskbar = self.cfg.get("media_keys"), self.cfg.get("taskbar")
        old_progressive = self.cfg.get("progressive")
        self.cfg.update(dlg.values())
        config.save(self.cfg)
        if dlg.clear_history_requested():
            self.history.clear()
            self._rec_tracks, self._rec_reasons, self._rec_taste = [], {}, []
            self.home_cache.clear()
        self.spotify = None                           # yeni anahtarlarla yeniden oluşturulsun
        self.cache.max_bytes = int(self.cfg.get("cache_mb", 500)) * 1024 * 1024
        self.player.play_mode = self.cfg.get("play_mode", "cache")
        self.player.prefetch = bool(self.cfg.get("prefetch", True))
        self.player.progressive = bool(self.cfg.get("progressive", True))
        if self.player.progressive and not old_progressive:
            self.cfg["raw_ok"] = True             # tekrar açılınca ham sesi yeniden dene
        self.player.raw_ok = bool(self.cfg.get("raw_ok", True))
        youtube.configure(force_ipv4=bool(self.cfg.get("force_ipv4", False)))
        self.mini.apply_viz_settings(self.cfg)
        if dlg.clear_cache_requested():
            self.cache.clear()
        else:
            run_async(self.cache.trim)
        if self.view == "discover" and self._discover_mode == "home":
            self._load_home()                         # tür seçimi değişmiş olabilir
        self.library.music_dir = Path(self.cfg["download_dir"])
        if not self.cfg.get("dynamic_accent"):
            self._dyn_accent = None
        self.player.tap.set_backend(bool(self.cfg.get("viz_real", True)))
        self.apply_theme(force=True)
        self.mini.setWindowOpacity(int(self.cfg["mini_opacity"]) / 100)
        self._reload_playlist_list()
        if self.cfg["media_keys"] != old_media:
            self._setup_system_media()
        if self.cfg.get("taskbar") != old_taskbar:
            self._taskbar_failed = False
            self._ensure_taskbar()
        if self.view in ("foryou", "liked"):
            self._refresh_view()
        self._run_health_check()                  # kullanıcı bir şey kurmuş olabilir
        self.set_status("Ayarlar kaydedildi.")

    def set_status(self, text: str):
        self.status_label.setText(text)
        # Hatalar (⚠ ile başlar) kırmızı görünsün; gözden kaçmasın
        self.status_label.setStyleSheet("color: #F87171;" if text.startswith("⚠") else "")

    def closeEvent(self, event):
        """X tuşu: Ayarlar'daki davranışa göre tepsiye iner / mini oynatıcıya geçer / kapanır."""
        if self._quitting:
            event.accept()
            return
        event.ignore()
        mode = self.cfg.get("close_to", "tray")
        if mode == "quit":
            self.quit_app()
        elif mode == "mini":
            self.switch_to_mini()
        else:
            self.hide()
            if not self._tray_hint_shown:
                self._tray_hint_shown = True
                self.tray.notify("NightWave arka planda çalışıyor",
                                 "Kapatmak için tepsi simgesine sağ tıklayın.")

    # İsterseniz "simge durumuna küçült" de tepsiye insin diye şunu açın:
    # def changeEvent(self, e):
    #     if e.type() == e.Type.WindowStateChange and self.isMinimized():
    #         QTimer.singleShot(0, self.hide)
    #     super().changeEvent(e)

    def quit_app(self):
        """Tepsi menüsündeki 'Uygulamayı kapat' ya da X (kapat modunda)."""
        self._quitting = True
        self._finalize_play()
        self.cfg["shuffle"] = self.player.shuffle
        self.cfg["repeat"] = self.player.repeat
        config.save(self.cfg)
        self.player.stop()
        if self.sysmedia:
            self.sysmedia.shutdown()
        if self.taskbar:
            self.taskbar.shutdown()
        self.mini.hide()
        self.tray.hide()
        progressive.server().shutdown()          # 'indirirken çal' yerel sunucusunu kapat
        QApplication.quit()
