"""Kapak görselinden baskın (canlı) renk çıkarma: "vurguyu kapaktan al" özelliği için."""
import colorsys


def dominant_from_pixels(pixels) -> str | None:
    """(r, g, b) piksellerinden en baskın CANLI rengi seçer. Gri/çok koyu/çok açık pikselleri yok sayar.

    Ton değerleri 24 kovaya ayrılır; her piksel doygunluk×parlaklık ağırlığıyla oy verir.
    Sonuç koyu arayüzde okunur olsun diye doygunluk/parlaklık güvenli aralığa çekilir.
    """
    bins: dict[int, list[float]] = {}
    for r, g, b in pixels:
        h, s, v = colorsys.rgb_to_hsv(r / 255, g / 255, b / 255)
        if s < 0.25 or v < 0.25 or v > 0.97:
            continue
        w = s * v
        acc = bins.setdefault(int(h * 24) % 24, [0.0, 0.0, 0.0, 0.0])
        acc[0] += w
        acc[1] += h * w
        acc[2] += s * w
        acc[3] += v * w
    if not bins:
        return None
    w, hw, sw, vw = max(bins.values(), key=lambda a: a[0])
    h, s, v = hw / w, sw / w, vw / w
    s = max(s, 0.55)
    v = min(max(v, 0.72), 0.95)
    r, g, b = colorsys.hsv_to_rgb(h, s, v)
    return "#%02X%02X%02X" % (round(r * 255), round(g * 255), round(b * 255))


def dominant_color(pixmap) -> str | None:
    """QPixmap -> '#RRGGBB' (bulunamazsa None)."""
    from PyQt6.QtCore import Qt
    img = pixmap.toImage().scaled(24, 24, Qt.AspectRatioMode.IgnoreAspectRatio,
                                  Qt.TransformationMode.SmoothTransformation)
    pixels = []
    for y in range(img.height()):
        for x in range(img.width()):
            c = img.pixelColor(x, y)
            pixels.append((c.red(), c.green(), c.blue()))
    return dominant_from_pixels(pixels)
