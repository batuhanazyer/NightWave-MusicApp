"""Windows sistem tepsisi (saatin yanındaki alan) simgesi ve sağ tık menüsü."""
from PyQt6.QtGui import QAction
from PyQt6.QtWidgets import QMenu, QSystemTrayIcon

from ui.icons import make_app_icon

REPEAT_LABELS = {"off": "Kapalı", "all": "Tüm liste", "one": "Tek parça"}


class TrayController:
    def __init__(self, window, player):
        self.window = window
        self.player = player

        self.tray = QSystemTrayIcon(make_app_icon(), window)
        self.tray.setToolTip("NightWave")

        self.menu = QMenu()
        self.act_show = QAction("Pencereyi göster", self.menu)
        self.act_mini = QAction("Mini oynatıcı", self.menu)
        self.act_play = QAction("Oynat", self.menu)
        self.act_prev = QAction("Önceki şarkı", self.menu)
        self.act_next = QAction("Sonraki şarkı", self.menu)
        self.act_shuffle = QAction("Karışık çal", self.menu)
        self.act_shuffle.setCheckable(True)
        self.act_repeat = QAction("Tekrar: Kapalı", self.menu)
        self.act_quit = QAction("Uygulamayı kapat", self.menu)

        for a in (self.act_show, self.act_mini, None, self.act_play, self.act_prev,
                  self.act_next, None, self.act_shuffle, self.act_repeat, None, self.act_quit):
            if a is None:
                self.menu.addSeparator()
            else:
                self.menu.addAction(a)
        self.tray.setContextMenu(self.menu)

        self.act_show.triggered.connect(self.show_window)
        self.act_mini.triggered.connect(lambda: window.toggle_mini())
        self.act_play.triggered.connect(lambda: player.toggle())
        self.act_prev.triggered.connect(lambda: player.prev())
        self.act_next.triggered.connect(lambda: player.next())
        self.act_shuffle.triggered.connect(lambda: player.toggle_shuffle())
        self.act_repeat.triggered.connect(lambda: player.cycle_repeat())
        self.act_quit.triggered.connect(lambda: window.quit_app())
        self.tray.activated.connect(self._on_activated)

        player.playing_changed.connect(self._on_playing)
        player.track_changed.connect(self._on_track)
        player.modes_changed.connect(self._on_modes)
        self._on_modes(player.shuffle, player.repeat)

        self.tray.show()

    # --- olaylar ---------------------------------------------------------
    def _on_activated(self, reason):
        # Sol tık / çift tık: pencereyi göster-gizle
        if reason in (QSystemTrayIcon.ActivationReason.Trigger,
                      QSystemTrayIcon.ActivationReason.DoubleClick):
            if self.window.isVisible() and not self.window.isMinimized():
                self.window.hide()
            else:
                self.show_window()

    def show_window(self):
        self.window.switch_to_main()

    def _on_playing(self, playing: bool):
        self.act_play.setText("Duraklat" if playing else "Oynat")

    def _on_track(self, track):
        text = f"{track.artist} – {track.title}" if track.artist else track.title
        self.tray.setToolTip(text[:120])  # Windows ipucu sınırı ~127 karakter

    def _on_modes(self, shuffle: bool, repeat: str):
        self.act_shuffle.setChecked(shuffle)
        self.act_repeat.setText(f"Tekrar: {REPEAT_LABELS.get(repeat, 'Kapalı')}")

    # --- dışarıya açık yardımcılar --------------------------------------
    def notify(self, title: str, message: str):
        if QSystemTrayIcon.supportsMessages():
            self.tray.showMessage(title, message, self.tray.icon(), 3000)

    def hide(self):
        self.tray.hide()  # çıkışta hayalet simge kalmasın
