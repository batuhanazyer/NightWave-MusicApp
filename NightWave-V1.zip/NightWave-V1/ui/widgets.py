"""Küçük, yeniden kullanılabilir arayüz parçaları."""
from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtGui import QColor
from PyQt6.QtWidgets import (QColorDialog, QHBoxLayout, QLabel, QPushButton, QSlider, QStyle,
                             QWidget)


class ClickSlider(QSlider):
    """Çubuğun herhangi bir yerine tıklayınca oraya atlayan kaydırıcı."""

    def mousePressEvent(self, e):
        if e.button() == Qt.MouseButton.LeftButton and self.width() > 0:
            value = QStyle.sliderValueFromPosition(
                self.minimum(), self.maximum(), int(e.position().x()), self.width()
            )
            self.setValue(value)
        super().mousePressEvent(e)


def set_elided(label: QLabel, text: str) -> None:
    """Uzun metni etiket genişliğine göre '…' ile kısaltır (etiketin sabit genişliği olmalı)."""
    label.setToolTip(text)
    label.setText(label.fontMetrics().elidedText(text, Qt.TextElideMode.ElideRight, label.width()))


class ColorPicker(QWidget):
    """Hazır renk daireleri + 'Özel…' ile istediğiniz rengi seçme."""
    changed = pyqtSignal(str)

    def __init__(self, presets, current: str, parent=None):
        super().__init__(parent)
        self._color = current
        lay = QHBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(8)
        self._buttons = []
        for c in presets:
            b = QPushButton()
            b.setFixedSize(26, 26)
            b.setCursor(Qt.CursorShape.PointingHandCursor)
            b.setToolTip(c)
            b.clicked.connect(lambda _=False, c=c: self.set_color(c))
            self._buttons.append((c, b))
            lay.addWidget(b)
        custom = QPushButton("Özel…")
        custom.setObjectName("rowBtn")
        custom.clicked.connect(self._pick_custom)
        lay.addWidget(custom)
        lay.addStretch(1)
        self._paint()

    def color(self) -> str:
        return self._color

    def set_color(self, c: str) -> None:
        self._color = c
        self._paint()
        self.changed.emit(c)

    def _paint(self):
        for c, b in self._buttons:
            selected = c.lower() == self._color.lower()
            border = "#FFFFFF" if selected else "transparent"
            b.setStyleSheet(
                f"QPushButton {{ background: {c}; border-radius: 13px; border: 2px solid {border}; padding: 0; }}")

    def _pick_custom(self):
        col = QColorDialog.getColor(QColor(self._color), self, "Renk seç")
        if col.isValid():
            self.set_color(col.name())


class ClickableLabel(QLabel):
    """Tıklanınca `clicked` sinyali gönderen etiket (ör. alt çubuktaki kapak)."""
    clicked = pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setCursor(Qt.CursorShape.PointingHandCursor)

    def mouseReleaseEvent(self, e):
        if e.button() == Qt.MouseButton.LeftButton:
            self.clicked.emit()
        super().mouseReleaseEvent(e)
