"""Çalma listesi arayüz parçaları: kapak çizimi ve oluştur/özelleştir penceresi."""
import os

from PyQt6.QtCore import QRectF, Qt
from PyQt6.QtGui import (QBrush, QColor, QFont, QImage, QLinearGradient, QPainter, QPainterPath,
                         QPixmap)
from PyQt6.QtWidgets import (QDialog, QDialogButtonBox, QFileDialog, QFormLayout, QGridLayout,
                             QHBoxLayout, QLabel, QLineEdit, QPlainTextEdit, QPushButton,
                             QVBoxLayout)

from core.playlists import Playlist
from ui.styles import ACCENT_PRESETS
from ui.widgets import ColorPicker

EMOJI_PRESETS = ["🎵", "🎧", "🔥", "🌙", "☕", "🚗", "💪", "🎸", "💜", "🌴", "✨", "🎹",
                 "🏃", "📚", "🎉", "😌", "🌧️", "❤️", "🎤", "🌅"]


def render_cover(pl: Playlist, size: int) -> QPixmap:
    """Listenin kapağını çizer: kendi görseliniz varsa onu, yoksa renk geçişi + emoji."""
    pix = QPixmap(size, size)
    pix.fill(Qt.GlobalColor.transparent)
    p = QPainter(pix)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)

    clip = QPainterPath()
    clip.addRoundedRect(QRectF(0, 0, size, size), size * 0.14, size * 0.14)
    p.setClipPath(clip)

    img = QImage(pl.cover_path) if pl.cover_path and os.path.exists(pl.cover_path) else QImage()
    if not img.isNull():
        scaled = img.scaled(size, size, Qt.AspectRatioMode.KeepAspectRatioByExpanding,
                            Qt.TransformationMode.SmoothTransformation)
        p.drawImage(-(scaled.width() - size) // 2, -(scaled.height() - size) // 2, scaled)
    else:
        base = QColor(pl.color)
        grad = QLinearGradient(0, 0, size, size)
        grad.setColorAt(0, base.lighter(125))
        grad.setColorAt(1, base.darker(170))
        p.fillRect(QRectF(0, 0, size, size), QBrush(grad))
        font = QFont("Segoe UI Emoji")
        font.setPixelSize(int(size * 0.46))
        p.setFont(font)
        p.setPen(QColor("white"))
        p.drawText(QRectF(0, 0, size, size), Qt.AlignmentFlag.AlignCenter, pl.emoji or "🎵")
    p.end()
    return pix


def save_cover(src: str, dest) -> bool:
    """Seçilen görseli ortadan kare kırpıp 512px PNG olarak kaydeder."""
    img = QImage(src)
    if img.isNull():
        return False
    side = min(img.width(), img.height())
    crop = img.copy((img.width() - side) // 2, (img.height() - side) // 2, side, side)
    crop = crop.scaled(512, 512, Qt.AspectRatioMode.IgnoreAspectRatio,
                       Qt.TransformationMode.SmoothTransformation)
    return crop.save(str(dest), "PNG")


class PlaylistDialog(QDialog):
    """Yeni liste oluşturma ve var olanı özelleştirme."""

    def __init__(self, pl: Playlist | None = None, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Çalma listesini özelleştir" if pl else "Yeni çalma listesi")
        self.setMinimumWidth(520)
        self._cover_src: str | None = None      # None: değişmedi | "": kaldır | yol: yeni görsel
        self._existing_cover = pl.cover_path if pl else ""

        self.name = QLineEdit(pl.name if pl else "")
        self.name.setPlaceholderText("Liste adı")
        self.name.setMaxLength(80)
        self.desc = QPlainTextEdit(pl.description if pl else "")
        self.desc.setPlaceholderText("İsteğe bağlı açıklama")
        self.desc.setFixedHeight(64)
        self.emoji = QLineEdit(pl.emoji if pl else "🎵")
        self.emoji.setMaxLength(8)
        self.emoji.setFixedWidth(70)
        self.emoji.textChanged.connect(self._update_preview)
        self.color = ColorPicker(ACCENT_PRESETS, pl.color if pl else ACCENT_PRESETS[0])
        self.color.changed.connect(self._update_preview)

        # Emoji ızgarası
        grid = QGridLayout()
        grid.setSpacing(4)
        for i, e in enumerate(EMOJI_PRESETS):
            b = QPushButton(e)
            b.setObjectName("rowBtn")
            b.setFixedSize(34, 30)
            b.clicked.connect(lambda _=False, e=e: self.emoji.setText(e))
            grid.addWidget(b, i // 10, i % 10)
        emoji_box = QVBoxLayout()
        emoji_row = QHBoxLayout()
        emoji_row.addWidget(self.emoji)
        emoji_row.addStretch(1)
        emoji_box.addLayout(emoji_row)
        emoji_box.addLayout(grid)

        # Kapak görseli
        pick = QPushButton("Görsel seç…")
        pick.setObjectName("rowBtn")
        pick.clicked.connect(self._pick_cover)
        clear = QPushButton("Görseli kaldır")
        clear.setObjectName("rowBtn")
        clear.clicked.connect(self._clear_cover)
        cover_row = QHBoxLayout()
        cover_row.addWidget(pick)
        cover_row.addWidget(clear)
        cover_row.addStretch(1)

        form = QFormLayout()
        form.setSpacing(12)
        form.addRow("Ad", self.name)
        form.addRow("Açıklama", self.desc)
        form.addRow("Simge", emoji_box)
        form.addRow("Renk", self.color)
        form.addRow("Kapak", cover_row)

        self.preview = QLabel()
        self.preview.setFixedSize(130, 130)
        side = QVBoxLayout()
        side.addWidget(self.preview)
        side.addStretch(1)

        body = QHBoxLayout()
        body.setSpacing(20)
        body.addLayout(form, 1)
        body.addLayout(side)

        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Save |
                                   QDialogButtonBox.StandardButton.Cancel)
        buttons.button(QDialogButtonBox.StandardButton.Save).setText("Kaydet")
        buttons.button(QDialogButtonBox.StandardButton.Cancel).setText("İptal")
        buttons.accepted.connect(self._accept)
        buttons.rejected.connect(self.reject)

        lay = QVBoxLayout(self)
        lay.setContentsMargins(24, 24, 24, 20)
        lay.setSpacing(16)
        lay.addLayout(body)
        lay.addWidget(buttons)
        self._update_preview()

    # --- olaylar ---------------------------------------------------------
    def _pick_cover(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Kapak görseli seç", "", "Görseller (*.png *.jpg *.jpeg *.webp *.bmp)")
        if path:
            self._cover_src = path
            self._update_preview()

    def _clear_cover(self):
        self._cover_src = ""
        self._update_preview()

    def _current_cover(self) -> str:
        if self._cover_src is None:
            return self._existing_cover
        return self._cover_src

    def _update_preview(self, *_):
        tmp = Playlist(id="preview", name="", color=self.color.color(),
                       emoji=self.emoji.text().strip() or "🎵", cover_path=self._current_cover())
        self.preview.setPixmap(render_cover(tmp, 130))

    def _accept(self):
        if not self.name.text().strip():
            self.name.setFocus()
            self.name.setPlaceholderText("Lütfen bir ad girin")
            return
        self.accept()

    def values(self) -> dict:
        return {
            "name": self.name.text().strip(),
            "description": self.desc.toPlainText().strip(),
            "emoji": self.emoji.text().strip() or "🎵",
            "color": self.color.color(),
            "cover_src": self._cover_src,
        }
