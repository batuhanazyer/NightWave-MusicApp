"""Özel tema oluşturucu: 3 ana renk seçin, gerisini (kenarlık, vurgu zemini, soluk metin) uygulama türetir."""
from PyQt6.QtWidgets import (QDialog, QDialogButtonBox, QFormLayout, QFrame, QHBoxLayout, QLabel,
                             QLineEdit, QVBoxLayout)

from ui import styles
from ui.widgets import ColorPicker

BG_PRESETS = ["#0E0E13", "#000000", "#0A1118", "#0C120F", "#140D12", "#121315", "#F4F4F8"]
PANEL_PRESETS = ["#12121A", "#070709", "#0E1822", "#101A15", "#1A1118", "#17181B", "#FFFFFF"]
TEXT_PRESETS = ["#E8E8F0", "#FFFFFF", "#C9D1D9", "#FFE9D6", "#1C1C24"]


class ThemeDialog(QDialog):
    def __init__(self, base: dict, accent: str, existing: dict | None = None, parent=None):
        """base: başlangıç renkleri için mevcut palet; existing: düzenlenen özel tema (varsa)."""
        super().__init__(parent)
        self.setWindowTitle("Özel temayı düzenle" if existing else "Yeni özel tema")
        self.setMinimumWidth(520)
        self._accent = accent
        src = existing or base

        self.name = QLineEdit(existing["name"] if existing else "Benim temam")
        self.name.setMaxLength(40)
        self.bg = ColorPicker(BG_PRESETS, src["bg"])
        self.panel = ColorPicker(PANEL_PRESETS, src["panel"])
        self.text = ColorPicker(TEXT_PRESETS, src["text"])
        for picker in (self.bg, self.panel, self.text):
            picker.changed.connect(self._update_preview)

        form = QFormLayout()
        form.setSpacing(12)
        form.addRow("Ad", self.name)
        form.addRow("Arka plan", self.bg)
        form.addRow("Paneller", self.panel)
        form.addRow("Metin", self.text)

        # Canlı önizleme
        self.preview = QFrame()
        self.preview.setFixedHeight(96)
        pl = QVBoxLayout(self.preview)
        pl.setContentsMargins(16, 12, 16, 12)
        self.p_title = QLabel("NightWave")
        self.p_sub = QLabel("Çalan şarkı · Sanatçı")
        self.p_btn = QLabel("  Çal  ")
        row = QHBoxLayout()
        row.addWidget(self.p_sub)
        row.addStretch(1)
        row.addWidget(self.p_btn)
        pl.addWidget(self.p_title)
        pl.addLayout(row)

        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Save |
                                   QDialogButtonBox.StandardButton.Cancel)
        buttons.button(QDialogButtonBox.StandardButton.Save).setText("Kaydet")
        buttons.button(QDialogButtonBox.StandardButton.Cancel).setText("İptal")
        buttons.accepted.connect(self._accept)
        buttons.rejected.connect(self.reject)

        lay = QVBoxLayout(self)
        lay.setContentsMargins(24, 24, 24, 20)
        lay.setSpacing(16)
        lay.addLayout(form)
        lay.addWidget(self.preview)
        lay.addWidget(buttons)
        self._update_preview()

    def _update_preview(self, *_):
        pal = styles.get_palette("custom:x", self._accent, {"custom:x": self.values()})
        self.preview.setStyleSheet(
            f"QFrame {{ background: {pal['bg']}; border: 1px solid {pal['border']}; border-radius: 12px; }}")
        self.p_title.setStyleSheet(
            f"background: transparent; border: none; color: {pal['text']}; font-size: 16px; font-weight: 700;")
        self.p_sub.setStyleSheet(f"background: transparent; border: none; color: {pal['muted']};")
        self.p_btn.setStyleSheet(
            f"background: {pal['accent']}; color: {pal['on_accent']}; border: none; "
            "border-radius: 10px; padding: 6px 10px; font-weight: 600;")

    def _accept(self):
        if not self.name.text().strip():
            self.name.setFocus()
            return
        self.accept()

    def values(self) -> dict:
        return {"name": self.name.text().strip() or "Özel tema",
                "bg": self.bg.color(), "panel": self.panel.color(), "text": self.text.color()}
