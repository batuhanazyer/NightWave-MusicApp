"""Müzik görselleştirici bileşeni: 5 stil, 2 renk modu, vuruşa tepki, yumuşak hareket.

Yalnızca ekranda görünürken çalışır (gizliyken zamanlayıcı ve ses yakalama durur, CPU harcamaz).
"""
import math
import time

import numpy as np
from PyQt6.QtCore import QPointF, QRectF, Qt, QTimer, pyqtSignal
from PyQt6.QtGui import QBrush, QColor, QLinearGradient, QPainter, QPainterPath, QPen, QPixmap
from PyQt6.QtWidgets import QWidget

from core.analyzer import WAVE_POINTS, VizEngine

STYLES = [("bars", "Çubuklar"), ("mirror", "Aynalı"), ("blocks", "Bloklar"),
          ("wave", "Dalga"), ("circle", "Dairesel")]
COLOR_MODES = [("accent", "Vurgu rengi"), ("rainbow", "Gökkuşağı")]
BAR_CHOICES = [32, 48, 64, 96]


class VisualizerWidget(QWidget):
    kind_changed = pyqtSignal(str)          # "real" | "sim": gerçek ses analizi mi, simülasyon mu

    def __init__(self, player, pal: dict, parent=None):
        super().__init__(parent)
        self.player = player
        self.pal = pal
        self.engine = VizEngine(getattr(player, "tap", None), 64)
        self.viz_style = "bars"
        self.color_mode = "accent"
        self.gain = 1.0
        self.kind = "sim"
        self._levels = np.zeros(64, np.float32)
        self._peaks = np.zeros(64, np.float32)
        self._wave = np.zeros(WAVE_POINTS, np.float32)
        self._beat = 0.0
        self._angle = 0.0
        self._hue = 0.0
        self._idle = False
        self._cover: QPixmap | None = None
        self._cover_cache = None            # (çap, ölçeklenmiş pixmap)
        self._last = time.monotonic()
        self.setMinimumHeight(180)
        self._timer = QTimer(self)
        self._timer.setInterval(16)         # ~60 kare/sn
        self._timer.timeout.connect(self._tick)

    # ---- ayarlar -----------------------------------------------------------
    def set_style(self, style: str) -> None:
        self.viz_style = style if style in dict(STYLES) else "bars"
        self.update()

    def set_color_mode(self, mode: str) -> None:
        self.color_mode = mode if mode in dict(COLOR_MODES) else "accent"
        self.update()

    def set_gain(self, percent: int) -> None:
        self.gain = max(0.3, min(3.0, percent / 100.0))

    def set_bars(self, n: int) -> None:
        n = n if n in BAR_CHOICES else 64
        self.engine.set_bands(n)
        self._levels = np.zeros(n, np.float32)
        self._peaks = np.zeros(n, np.float32)

    def set_cover(self, pix: QPixmap | None) -> None:
        self._cover = pix
        self._cover_cache = None

    def apply_palette(self, pal: dict) -> None:
        self.pal = pal
        self.update()

    # ---- yaşam döngüsü: sadece görünürken çalış ---------------------------------
    def showEvent(self, e):
        super().showEvent(e)
        tap = getattr(self.player, "tap", None)
        if tap is not None:
            tap.set_enabled(True)
        self._last = time.monotonic()
        self._timer.start()

    def hideEvent(self, e):
        super().hideEvent(e)
        self._timer.stop()
        tap = getattr(self.player, "tap", None)
        if tap is not None:
            tap.set_enabled(False)

    # ---- her kare ------------------------------------------------------------------
    def _tick(self):
        now = time.monotonic()
        dt = min(0.05, now - self._last)
        self._last = now
        track = self.player.current_track()
        frame = self.engine.frame(self.player.position(), self.player.is_playing,
                                  track.id if track else "")
        if frame.kind != self.kind:
            self.kind = frame.kind
            self.kind_changed.emit(self.kind)

        n = len(self._levels)
        target = np.clip(frame.bands[:n] * self.gain, 0.0, 1.0)
        rate = np.where(target > self._levels, 1 - math.exp(-dt * 28), 1 - math.exp(-dt * 7))
        self._levels += (target - self._levels) * rate                 # hızlı yüksel, yavaş düş
        self._peaks = np.maximum(self._levels, self._peaks - dt * 0.45)
        self._wave = frame.wave
        self._beat = frame.beat
        self._angle += dt * (0.25 + frame.beat * 0.8)
        self._hue = (self._hue + dt * 0.03) % 1.0

        idle = (not self.player.is_playing) and float(self._levels.max()) < 0.004
        if idle and self._idle:
            return                                                     # sessiz ve çizilmiş: CPU harcama
        self._idle = idle
        self.update()

    # ---- renkler -------------------------------------------------------------
    def _color(self, frac: float) -> QColor:
        if self.color_mode == "rainbow":
            return QColor.fromHslF((frac * 0.85 + self._hue) % 1.0, 0.72, 0.58)
        return QColor(self.pal["accent"])

    # ---- çizim ---------------------------------------------------------------
    def paintEvent(self, _e):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        w, h = float(self.width()), float(self.height())
        getattr(self, "_draw_" + self.viz_style, self._draw_bars)(p, w, h)
        p.end()

    @staticmethod
    def _fade(c: QColor, alpha: int) -> QColor:
        return QColor(c.red(), c.green(), c.blue(), alpha)

    def _draw_bars(self, p, w, h):
        lv, pk = self._levels.tolist(), self._peaks.tolist()
        n = len(lv)
        gap = max(2.0, w * 0.0035)
        bw = max(1.0, (w - gap * (n - 1)) / n)
        base, span = h - 10.0, h - 18.0
        r = min(bw / 2, 5.0)
        p.setPen(Qt.PenStyle.NoPen)
        for i in range(n):
            c = self._color(i / max(1, n - 1))
            bh = max(3.0, lv[i] * span)
            x = i * (bw + gap)
            g = QLinearGradient(0, base, 0, base - bh)
            g.setColorAt(0, self._fade(c, 140))
            g.setColorAt(1, c.lighter(125))
            p.setBrush(QBrush(g))
            p.drawRoundedRect(QRectF(x, base - bh, bw, bh), r, r)
            if pk[i] > lv[i] + 0.03:                                   # tepe çizgisi
                p.setBrush(c.lighter(165))
                p.drawRoundedRect(QRectF(x, base - pk[i] * span - 6, bw, 3), 1.5, 1.5)

    def _draw_mirror(self, p, w, h):
        lv = self._levels.tolist()
        n = len(lv)
        gap = max(2.0, w * 0.0035)
        bw = max(1.0, (w - gap * (n - 1)) / n)
        mid, span = h / 2, h / 2 - 8.0
        r = min(bw / 2, 5.0)
        p.setPen(Qt.PenStyle.NoPen)
        for i in range(n):
            c = self._color(i / max(1, n - 1))
            bh = max(2.0, lv[i] * span)
            x = i * (bw + gap)
            g = QLinearGradient(0, mid, 0, mid - bh)
            g.setColorAt(0, self._fade(c, 170))
            g.setColorAt(1, c.lighter(125))
            p.setBrush(QBrush(g))
            p.drawRoundedRect(QRectF(x, mid - bh, bw, bh), r, r)
            g2 = QLinearGradient(0, mid, 0, mid + bh * 0.65)           # alt yarı: soluk yansıma
            g2.setColorAt(0, self._fade(c, 90))
            g2.setColorAt(1, self._fade(c, 0))
            p.setBrush(QBrush(g2))
            p.drawRoundedRect(QRectF(x, mid + 2, bw, bh * 0.65), r, r)

    def _draw_blocks(self, p, w, h):
        lv = self._levels
        if len(lv) >= 8:                                               # çizim sayısını yarıya indir
            m = len(lv) // 2 * 2
            lv = (lv[0:m:2] + lv[1:m:2]) / 2
            pk = (self._peaks[0:m:2] + self._peaks[1:m:2]) / 2
        else:
            pk = self._peaks
        lv, pk = lv.tolist(), pk.tolist()
        n, segs = len(lv), 20
        gap = max(3.0, w * 0.006)
        bw = max(2.0, (w - gap * (n - 1)) / n)
        sgap = 3.0
        sh = max(2.0, (h - 16 - sgap * (segs - 1)) / segs)
        p.setPen(Qt.PenStyle.NoPen)
        for i in range(n):
            base = self._color(i / max(1, n - 1))
            lit = int(lv[i] * segs + 0.5)
            peak_seg = min(segs - 1, int(pk[i] * segs))
            x = i * (bw + gap)
            for s in range(segs):
                y = h - 8 - (s + 1) * sh - s * sgap
                c = base.lighter(100 + int(70 * s / segs))
                if s < lit:
                    c.setAlpha(255)
                elif s == peak_seg and pk[i] > 0.04:
                    c.setAlpha(210)
                else:
                    c.setAlpha(26)                                     # sönük (yanmayan) blok
                p.setBrush(c)
                p.drawRoundedRect(QRectF(x, y, bw, sh), 2.5, 2.5)

    def _draw_wave(self, p, w, h):
        wv = self._wave.tolist()
        n = len(wv)
        amp = h * 0.40
        path = QPainterPath()
        for i, v in enumerate(wv):
            v = max(-1.0, min(1.0, v * self.gain * 1.6))
            pt = QPointF(w * i / (n - 1), h / 2 - v * amp)
            path.moveTo(pt) if i == 0 else path.lineTo(pt)
        if self.color_mode == "rainbow":
            g = QLinearGradient(0, 0, w, 0)
            for k in range(7):
                g.setColorAt(k / 6, QColor.fromHslF((k / 6 * 0.85 + self._hue) % 1.0, 0.72, 0.6))
            glow, main = QBrush(g), QBrush(g)
        else:
            c = QColor(self.pal["accent"])
            glow, main = QBrush(self._fade(c, 45)), QBrush(c.lighter(115))
        p.setBrush(Qt.BrushStyle.NoBrush)
        for brush, width, alpha in ((glow, 14.0, 0.35), (glow, 8.0, 0.5), (main, 3.0, 1.0)):
            pen = QPen(brush, width)
            pen.setCapStyle(Qt.PenCapStyle.RoundCap)
            pen.setJoinStyle(Qt.PenJoinStyle.RoundJoin)
            p.setOpacity(alpha)
            p.setPen(pen)
            p.drawPath(path)
        p.setOpacity(1.0)

    def _draw_circle(self, p, w, h):
        lv = self._levels.tolist()
        spokes = lv + lv[::-1]                                         # simetrik halka
        n = len(spokes)
        cx, cy = w / 2, h / 2
        side = min(w, h)
        r0 = side * 0.22 * (1.0 + self._beat * 0.07)
        max_len = side * 0.27
        pen_w = max(2.0, 2 * math.pi * r0 / n * 0.62)
        for i, v in enumerate(spokes):
            a = self._angle + i * 2 * math.pi / n
            c = self._color(i / n)
            pen = QPen(c.lighter(115), pen_w)
            pen.setCapStyle(Qt.PenCapStyle.RoundCap)
            p.setPen(pen)
            ln = 3.0 + v * max_len
            ca, sa = math.cos(a), math.sin(a)
            p.drawLine(QPointF(cx + ca * r0 * 1.04, cy + sa * r0 * 1.04),
                       QPointF(cx + ca * (r0 * 1.04 + ln), cy + sa * (r0 * 1.04 + ln)))
        # Ortada: kapak (varsa) ya da düz daire
        d = int(r0 * 2 * 0.94)
        circle = QPainterPath()
        circle.addEllipse(QPointF(cx, cy), d / 2, d / 2)
        p.save()
        p.setClipPath(circle)
        if self._cover is not None and not self._cover.isNull() and d > 8:
            if self._cover_cache is None or self._cover_cache[0] != d:
                scaled = self._cover.scaled(d, d, Qt.AspectRatioMode.KeepAspectRatioByExpanding,
                                            Qt.TransformationMode.SmoothTransformation)
                self._cover_cache = (d, scaled)
            pm = self._cover_cache[1]
            p.drawPixmap(QPointF(cx - pm.width() / 2, cy - pm.height() / 2), pm)
        else:
            p.fillPath(circle, QColor(self.pal["surface"]))
        p.restore()
        ring = QPen(self._fade(QColor(self.pal["accent"]), 160), 2.0)
        p.setPen(ring)
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawEllipse(QPointF(cx, cy), d / 2, d / 2)
