"""Mini oynatıcı: çerçevesiz, her zaman üstte, sürüklenebilir küçük pencere.

- Her yerinden sürükleyerek taşıyın (konum hatırlanır).
- Çift tıklayınca ana pencereye döner.
- Ana pencereyle aynı Player'ı kullanır; ikisi birbirinden bağımsız çalışmaz.
"""
from PyQt6.QtCore import QSize, Qt, pyqtSignal
from PyQt6.QtWidgets import QFrame, QHBoxLayout, QLabel, QPushButton, QVBoxLayout, QWidget

from core.models import fmt_time
from ui.icons import icon
from ui.visualizer import VisualizerWidget
from ui.widgets import ClickSlider, set_elided


class MiniPlayer(QWidget):
    expand_requested = pyqtSignal()
    moved = pyqtSignal(int, int)

    def __init__(self, player, pal: dict, opacity: int = 95, cfg: dict | None = None):
        super().__init__(None, Qt.WindowType.Tool | Qt.WindowType.FramelessWindowHint |
                         Qt.WindowType.WindowStaysOnTopHint)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setWindowTitle("NightWave Mini")
        self.setFixedSize(380, 210)
        self.setWindowOpacity(max(40, min(100, opacity)) / 100)

        self.player = player
        self.pal = pal
        self._seeking = False

        outer = QVBoxLayout(self)
        outer.setContentsMargins(6, 6, 6, 6)
        card = QFrame()
        card.setObjectName("miniCard")
        outer.addWidget(card)
        lay = QVBoxLayout(card)
        lay.setContentsMargins(14, 12, 14, 12)
        lay.setSpacing(6)

        # --- üst: kapak + başlık + pencere düğmeleri ---
        self.cover = QLabel()
        self.cover.setObjectName("cover")
        self.cover.setFixedSize(54, 54)
        self.cover.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.title = QLabel("Çalan parça yok")
        self.title.setObjectName("npTitle")
        self.title.setFixedWidth(220)
        self.artist = QLabel("—")
        self.artist.setObjectName("muted")
        self.artist.setFixedWidth(220)
        info = QVBoxLayout()
        info.setSpacing(1)
        info.addStretch(1)
        info.addWidget(self.title)
        info.addWidget(self.artist)
        info.addStretch(1)

        self.btn_expand = self._small_button("expand", "Ana pencereye dön")
        self.btn_close = self._small_button("close", "Mini oynatıcıyı gizle")
        self.btn_expand.clicked.connect(lambda: self.expand_requested.emit())
        self.btn_close.clicked.connect(self.hide)

        top = QHBoxLayout()
        top.setSpacing(10)
        top.addWidget(self.cover)
        top.addLayout(info, 1)
        top.addWidget(self.btn_expand, 0, Qt.AlignmentFlag.AlignTop)
        top.addWidget(self.btn_close, 0, Qt.AlignmentFlag.AlignTop)

        # --- orta: kontroller ---
        self.btn_shuffle = self._small_button("shuffle", "Karışık çal")
        self.btn_prev = self._small_button("prev", "Önceki")
        self.btn_play = QPushButton()
        self.btn_play.setObjectName("playBtn")
        self.btn_play.setFixedSize(40, 40)
        self.btn_play.setIconSize(QSize(22, 22))
        self.btn_play.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_next = self._small_button("next", "Sonraki")
        self.btn_repeat = self._small_button("repeat", "Tekrar")

        ctrl = QHBoxLayout()
        ctrl.setSpacing(8)
        ctrl.addStretch(1)
        for b in (self.btn_shuffle, self.btn_prev, self.btn_play, self.btn_next, self.btn_repeat):
            ctrl.addWidget(b)
        ctrl.addStretch(1)

        # --- alt: ilerleme çubuğu ---
        self.time_cur = QLabel("0:00")
        self.time_cur.setObjectName("muted")
        self.time_total = QLabel("0:00")
        self.time_total.setObjectName("muted")
        self.seek = ClickSlider(Qt.Orientation.Horizontal)
        self.seek.setObjectName("seek")
        self.seek.setRange(0, 0)
        seek_row = QHBoxLayout()
        seek_row.setSpacing(8)
        seek_row.addWidget(self.time_cur)
        seek_row.addWidget(self.seek, 1)
        seek_row.addWidget(self.time_total)

        # --- görselleştirici şeridi (ana ekrandakiyle aynı motor) ---
        self.viz = VisualizerWidget(player, pal)
        self.viz.setMinimumHeight(0)
        self.viz.setFixedHeight(44)
        self.viz.set_bars(32)
        self.apply_viz_settings(cfg or {})

        lay.addLayout(top)
        lay.addLayout(ctrl)
        lay.addWidget(self.viz)
        lay.addLayout(seek_row)

        # --- bağlantılar ---
        p = player
        self.btn_play.clicked.connect(lambda: p.toggle())
        self.btn_prev.clicked.connect(lambda: p.prev())
        self.btn_next.clicked.connect(lambda: p.next())
        self.btn_shuffle.clicked.connect(lambda: p.toggle_shuffle())
        self.btn_repeat.clicked.connect(lambda: p.cycle_repeat())
        p.track_changed.connect(self._on_track)
        p.playing_changed.connect(self._on_playing)
        p.position_changed.connect(self._on_position)
        p.duration_changed.connect(self._on_duration)
        p.modes_changed.connect(self._on_modes)
        self.seek.sliderPressed.connect(lambda: setattr(self, "_seeking", True))
        self.seek.sliderMoved.connect(lambda v: self.time_cur.setText(fmt_time(v // 1000)))
        self.seek.sliderReleased.connect(self._on_seek_released)

        self._playing = False
        self.apply_palette(pal)
        self._on_modes(p.shuffle, p.repeat)
        cur = p.current_track()
        if cur:
            self._on_track(cur)

    # --- yardımcılar -----------------------------------------------------
    def _small_button(self, name: str, tip: str) -> QPushButton:
        b = QPushButton()
        b.setObjectName("ctl")
        b.setFixedSize(32, 32)
        b.setIconSize(QSize(18, 18))
        b.setToolTip(tip)
        b.setCursor(Qt.CursorShape.PointingHandCursor)
        b.setProperty("icon_name", name)
        return b

    def apply_viz_settings(self, cfg: dict) -> None:
        """Çalıyor ekranındaki stil/renk/duyarlılık seçimlerini küçük ekrana da uygula (daire stili yerine çubuk)."""
        style = cfg.get("viz_style", "bars")
        self.viz.set_style("bars" if style == "circle" else style)
        self.viz.set_color_mode(cfg.get("viz_color", "accent"))
        self.viz.set_gain(int(cfg.get("viz_gain", 100)))

    def apply_palette(self, pal: dict) -> None:
        self.pal = pal
        self.viz.apply_palette(pal)
        for b in (self.btn_prev, self.btn_next, self.btn_expand, self.btn_close):
            b.setIcon(icon(b.property("icon_name"), pal["text"]))
        self._on_playing(self._playing)
        self._on_modes(self.player.shuffle, self.player.repeat)

    def set_cover(self, pix) -> None:
        if pix is None or pix.isNull():
            self.cover.clear()
            return
        self.cover.setPixmap(pix.scaled(54, 54, Qt.AspectRatioMode.KeepAspectRatioByExpanding,
                                        Qt.TransformationMode.SmoothTransformation))

    # --- oynatıcı olayları -----------------------------------------------
    def _on_track(self, track) -> None:
        set_elided(self.title, track.title)
        set_elided(self.artist, track.artist or "—")
        self.cover.clear()
        self.seek.setValue(0)
        self.seek.setMaximum(track.duration * 1000)
        self.time_cur.setText("0:00")
        self.time_total.setText(fmt_time(track.duration))

    def _on_playing(self, playing: bool) -> None:
        self._playing = playing
        self.btn_play.setIcon(icon("pause" if playing else "play", self.pal["bg"]))

    def _on_position(self, ms: int) -> None:
        if not self._seeking:
            self.seek.setValue(ms)
            self.time_cur.setText(fmt_time(ms // 1000))

    def _on_duration(self, ms: int) -> None:
        if ms > 0:
            self.seek.setMaximum(ms)
            self.time_total.setText(fmt_time(ms // 1000))

    def _on_seek_released(self) -> None:
        self._seeking = False
        self.player.seek(self.seek.value())

    def _on_modes(self, shuffle: bool, repeat: str) -> None:
        on, off = self.pal["accent"], self.pal["muted"]
        self.btn_shuffle.setIcon(icon("shuffle", on if shuffle else off))
        self.btn_repeat.setIcon(icon("repeat1" if repeat == "one" else "repeat",
                                     on if repeat != "off" else off))

    # --- pencere davranışı -----------------------------------------------
    def mousePressEvent(self, e):
        if e.button() == Qt.MouseButton.LeftButton and self.windowHandle():
            self.windowHandle().startSystemMove()     # her yerinden sürüklenebilir
        super().mousePressEvent(e)

    def mouseDoubleClickEvent(self, e):
        self.expand_requested.emit()

    def moveEvent(self, e):
        super().moveEvent(e)
        self.moved.emit(self.x(), self.y())
