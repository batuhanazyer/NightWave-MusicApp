"""Küçük kapak görselleri: bellek + disk önbelleği, arka planda indirme (kartlar için)."""
import hashlib
from pathlib import Path
from urllib.parse import urlparse

from PyQt6.QtGui import QPixmap

from core import network
from core.workers import run_async

ALLOWED_HOSTS = ("ytimg.com", "ggpht.com", "googleusercontent.com", "scdn.co")


def allowed(url: str) -> bool:
    """Yalnızca bilinen görsel sunucuları (rastgele adrese istek atmayalım)."""
    try:
        u = urlparse(url)
    except ValueError:
        return False
    host = (u.hostname or "").lower()
    return u.scheme == "https" and any(host == h or host.endswith("." + h) for h in ALLOWED_HOSTS)


class ThumbLoader:
    def __init__(self, directory: Path, max_memory: int = 400, max_files: int = 1500):
        self.dir = Path(directory)
        self.dir.mkdir(parents=True, exist_ok=True)
        self._mem: dict[str, QPixmap] = {}
        self._pending: dict[str, list] = {}
        self._max = max_memory
        self._trim_disk(max_files)

    def _path(self, url: str) -> Path:
        return self.dir / (hashlib.sha1(url.encode()).hexdigest() + ".img")

    def _trim_disk(self, max_files: int) -> None:
        try:
            files = sorted((p for p in self.dir.iterdir() if p.is_file()), key=lambda p: p.stat().st_mtime)
            for p in files[:max(0, len(files) - max_files)]:
                p.unlink(missing_ok=True)
        except OSError:
            pass

    def load(self, url: str, callback) -> None:
        """Görsel hazır olunca callback(QPixmap) çağrılır (bellekteyse hemen)."""
        if not url or not allowed(url):
            return
        pix = self._mem.get(url)
        if pix is not None:
            callback(pix)
            return
        path = self._path(url)
        if path.exists():
            pix = QPixmap(str(path))
            if not pix.isNull():
                self._remember(url, pix)
                callback(pix)
                return
        if url in self._pending:
            self._pending[url].append(callback)
            return
        self._pending[url] = [callback]
        run_async(self._fetch, url,
                  on_result=lambda data, u=url: self._done(u, data),
                  on_error=lambda _m, u=url: self._pending.pop(u, None))

    def _fetch(self, url: str) -> bytes:                 # arka plan iş parçacığı
        data = network.fetch_bytes(url)
        try:
            self._path(url).write_bytes(data)
        except OSError:
            pass
        return data

    def _done(self, url: str, data: bytes) -> None:      # ana iş parçacığı
        callbacks = self._pending.pop(url, [])
        pix = QPixmap()
        if not pix.loadFromData(data):
            return
        self._remember(url, pix)
        for cb in callbacks:
            try:
                cb(pix)
            except RuntimeError:                          # kart bu arada silinmiş olabilir
                pass

    def _remember(self, url: str, pix: QPixmap) -> None:
        self._mem[url] = pix
        while len(self._mem) > self._max:
            self._mem.pop(next(iter(self._mem)))
