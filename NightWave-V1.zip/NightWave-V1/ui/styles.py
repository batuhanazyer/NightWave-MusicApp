"""Tema sistemi: hazır temalar, özel temalar, sistem temasını izleme, paylaşım kodu.

build_qss(tema, vurgu, özel)   -> uygulamanın tüm QSS metni
get_palette(tema, vurgu, özel) -> renk sözlüğü (ikonlar vb. için)

Tema anahtarları: hazır ("midnight", "light"…), "auto" (Windows temasını izler) ya da
"custom:<id>" (kullanıcının oluşturduğu; `özel` sözlüğünde saklanır).
"""
import base64
import json
import re
import sys
import zlib

THEMES = {
    "midnight": {"name": "Gece Yarısı", "bg": "#0E0E13", "panel": "#12121A", "surface": "#171720",
                 "border": "#23232F", "hover": "#1A1A24", "text": "#E8E8F0", "muted": "#8A8A9A"},
    "amoled":   {"name": "AMOLED Siyah", "bg": "#000000", "panel": "#070709", "surface": "#0F0F12",
                 "border": "#1A1A1F", "hover": "#121216", "text": "#F2F2F7", "muted": "#8A8A93"},
    "ocean":    {"name": "Okyanus", "bg": "#0A1118", "panel": "#0E1822", "surface": "#13212D",
                 "border": "#1C3040", "hover": "#12202C", "text": "#E6EEF5", "muted": "#7F95A8"},
    "forest":   {"name": "Orman", "bg": "#0C120F", "panel": "#101A15", "surface": "#16231C",
                 "border": "#203329", "hover": "#15221B", "text": "#E7F0EA", "muted": "#82988A"},
    "rose":     {"name": "Gül", "bg": "#140D12", "panel": "#1A1118", "surface": "#22161F",
                 "border": "#352230", "hover": "#20141D", "text": "#F4E9EF", "muted": "#A08592"},
    "slate":    {"name": "Kömür", "bg": "#121315", "panel": "#17181B", "surface": "#1E2024",
                 "border": "#2B2D33", "hover": "#1C1E22", "text": "#E9EAEC", "muted": "#8D9096"},
    "light":    {"name": "Gün Işığı", "bg": "#F4F4F8", "panel": "#FFFFFF", "surface": "#F0F0F5",
                 "border": "#DEDEE8", "hover": "#EAEAF2", "text": "#1C1C24", "muted": "#6B6B7A"},
}
DEFAULT_THEME = "midnight"
DEFAULT_ACCENT = "#8B7CFF"
ACCENT_PRESETS = ["#8B7CFF", "#5EA8FF", "#2DD4BF", "#4ADE80",
                  "#FACC15", "#FB923C", "#F43F5E", "#F472B6"]

_HEX = re.compile(r"^#[0-9A-Fa-f]{6}$")


def _rgb(h):
    return tuple(int(h[i:i + 2], 16) for i in (1, 3, 5))


def _hex(rgb):
    return "#%02X%02X%02X" % tuple(max(0, min(255, round(c))) for c in rgb)


def _mix(a, b, t):
    """a ile b'yi karıştırır (t=0 -> a, t=1 -> b)."""
    ra, rb = _rgb(a), _rgb(b)
    return _hex([ra[i] * (1 - t) + rb[i] * t for i in range(3)])


def _luma(h):
    r, g, b = _rgb(h)
    return (0.299 * r + 0.587 * g + 0.114 * b) / 255


def system_prefers_light() -> bool:
    """Windows uygulama teması açık mı? (Windows dışında False)"""
    if sys.platform != "win32":
        return False
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER,
                            r"Software\Microsoft\Windows\CurrentVersion\Themes\Personalize") as k:
            return winreg.QueryValueEx(k, "AppsUseLightTheme")[0] == 1
    except OSError:
        return False


def derive_theme(name: str, bg: str, panel: str, text: str) -> dict:
    """3 ana renkten (arka plan, panel, metin) tüm temayı türetir."""
    return {"name": name, "bg": bg, "panel": panel, "text": text,
            "surface": _mix(panel, text, 0.05), "border": _mix(panel, text, 0.12),
            "hover": _mix(panel, text, 0.07), "muted": _mix(text, panel, 0.45)}


def valid_custom(c) -> bool:
    return isinstance(c, dict) and all(_HEX.match(str(c.get(k, ""))) for k in ("bg", "panel", "text"))


def resolve_theme(theme_key: str, custom: dict | None = None) -> dict:
    if theme_key == "auto":
        theme_key = "light" if system_prefers_light() else DEFAULT_THEME
    if custom and theme_key in custom and valid_custom(custom[theme_key]):
        c = custom[theme_key]
        return derive_theme(str(c.get("name") or "Özel tema")[:40], c["bg"], c["panel"], c["text"])
    return THEMES.get(theme_key, THEMES[DEFAULT_THEME])


def get_palette(theme_key: str, accent: str, custom: dict | None = None) -> dict:
    pal = dict(resolve_theme(theme_key, custom))
    accent = accent if _HEX.match(str(accent)) else DEFAULT_ACCENT
    pal["accent"] = accent
    pal["accent_hover"] = _mix(accent, "#FFFFFF", 0.22)
    pal["accent_soft"] = _mix(pal["panel"], accent, 0.18)       # seçili öğe arka planı
    pal["on_accent"] = "#0E0E13" if _luma(accent) > 0.55 else "#FFFFFF"
    pal["disabled"] = _mix(pal["muted"], pal["bg"], 0.55)
    return pal


# ---- Tema paylaşımı: "NWT1:..." kodu ---------------------------------------
THEME_PREFIX = "NWT1:"


def theme_to_code(name: str, bg: str, panel: str, text: str, accent: str) -> str:
    raw = json.dumps({"name": name, "bg": bg, "panel": panel, "text": text, "accent": accent},
                     ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    return THEME_PREFIX + base64.urlsafe_b64encode(zlib.compress(raw, 9)).decode("ascii")


def theme_from_code(code: str) -> dict:
    """Paylaşım kodunu doğrulayarak çözer. Geçersizse ValueError fırlatır."""
    code = "".join(code.split())
    if code.startswith(THEME_PREFIX):
        code = code[len(THEME_PREFIX):]
    try:
        raw = base64.urlsafe_b64decode(code + "=" * (-len(code) % 4))
        dec = zlib.decompressobj()
        data = dec.decompress(raw, 4096)
        if dec.unconsumed_tail:
            raise ValueError
        obj = json.loads(data.decode("utf-8"))
    except (ValueError, zlib.error, UnicodeDecodeError) as exc:
        raise ValueError("Tema kodu geçersiz ya da bozuk.") from exc
    if not isinstance(obj, dict) or not valid_custom(obj):
        raise ValueError("Tema kodu geçersiz renkler içeriyor.")
    accent = obj.get("accent")
    return {"name": str(obj.get("name") or "İçe aktarılan tema")[:40],
            "bg": obj["bg"], "panel": obj["panel"], "text": obj["text"],
            "accent": accent if _HEX.match(str(accent)) else DEFAULT_ACCENT}


_TEMPLATE = """
* { font-family: "Segoe UI Variable", "Segoe UI"; font-size: 13px; color: %TEXT%; outline: 0; }
QMainWindow, #root, QDialog { background: %BG%; }
QToolTip { background: %SURFACE%; color: %TEXT%; border: 1px solid %BORDER%; padding: 4px 8px; }

/* Kenar çubuğu */
#sidebar { background: %PANEL%; border-right: 1px solid %BORDER%; }
#logo { font-size: 20px; font-weight: 700; }
#section { color: %MUTED%; font-size: 11px; font-weight: 600; letter-spacing: 1px; }
QPushButton#nav { text-align: left; padding: 9px 14px; border: none; border-radius: 10px;
                  background: transparent; color: %MUTED%; font-weight: 500; }
QPushButton#nav:hover { background: %HOVER%; color: %TEXT%; }
QPushButton#nav:checked { background: %ACCENT_SOFT%; color: %ACCENT%; }
QPushButton#nav:disabled { color: %DISABLED%; }
QPushButton::menu-indicator { image: none; width: 0; }
#netLabel { padding-left: 4px; font-size: 12px; }

QListWidget#plList { background: transparent; border: none; }
QListWidget#plList::item { padding: 5px 8px; border-radius: 8px; color: %MUTED%; }
QListWidget#plList::item:hover { background: %HOVER%; color: %TEXT%; }
QListWidget#plList::item:selected { background: %ACCENT_SOFT%; color: %ACCENT%; }

/* Başlıklar */
#h1 { font-size: 24px; font-weight: 700; }
#muted { color: %MUTED%; }

/* Girdi alanları */
QLineEdit, QPlainTextEdit, QSpinBox { background: %SURFACE%; border: 1px solid %BORDER%;
            border-radius: 10px; padding: 9px 14px; selection-background-color: %ACCENT%;
            selection-color: %ON_ACCENT%; }
QLineEdit:focus, QPlainTextEdit:focus { border: 1px solid %ACCENT%; }
QComboBox { background: %SURFACE%; border: 1px solid %BORDER%; border-radius: 10px; padding: 8px 14px; }
QComboBox:disabled { color: %DISABLED%; }
QComboBox::drop-down { border: none; width: 22px; }
QComboBox QAbstractItemView { background: %SURFACE%; border: 1px solid %BORDER%;
                              selection-background-color: %ACCENT_SOFT%; outline: 0; }
QCheckBox { spacing: 10px; }
QCheckBox::indicator { width: 18px; height: 18px; border-radius: 5px;
                       border: 1px solid %BORDER%; background: %SURFACE%; }
QCheckBox::indicator:checked { background: %ACCENT%; border-color: %ACCENT%; }

/* Sekmeler */
QTabWidget::pane { border: none; }
QTabBar::tab { background: transparent; padding: 9px 18px; color: %MUTED%;
               border-bottom: 2px solid transparent; }
QTabBar::tab:selected { color: %TEXT%; border-bottom: 2px solid %ACCENT%; }
QTabBar::tab:hover { color: %TEXT%; }

/* Butonlar */
QPushButton { background: %SURFACE%; border: 1px solid %BORDER%; border-radius: 10px; padding: 8px 16px; }
QPushButton:hover { border-color: %ACCENT%; }
QPushButton#primary { background: %ACCENT%; color: %ON_ACCENT%; border: none; padding: 10px 20px;
                      font-weight: 600; }
QPushButton#primary:hover { background: %ACCENT_HOVER%; }
QPushButton#primary:disabled { background: %BORDER%; color: %DISABLED%; }
QPushButton#rowBtn { background: transparent; border: 1px solid %BORDER%; border-radius: 8px;
                     padding: 5px 12px; color: %TEXT%; }
QPushButton#rowBtn:hover { border-color: %ACCENT%; color: %ACCENT%; }
QPushButton#rowBtn:disabled { border-color: transparent; color: %DISABLED%; }

/* Tablo */
QTableWidget { background: transparent; border: none; gridline-color: transparent;
               selection-background-color: %HOVER%; }
QTableWidget::item { padding-left: 8px; border-bottom: 1px solid %HOVER%; }
QTableWidget::item:selected { background: %HOVER%; }
QHeaderView::section { background: transparent; border: none; border-bottom: 1px solid %BORDER%;
                       color: %MUTED%; padding: 6px 8px; text-align: left; font-weight: 500; }
QTableCornerButton::section { background: transparent; border: none; }

/* Kaydırma çubuğu */
QScrollBar:vertical { background: transparent; width: 10px; margin: 0; }
QScrollBar::handle:vertical { background: %BORDER%; border-radius: 5px; min-height: 30px; }
QScrollBar::handle:vertical:hover { background: %DISABLED%; }
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }
QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical { background: transparent; }

/* Alt oynatıcı çubuğu */
#playerBar { background: %PANEL%; border-top: 1px solid %BORDER%; }
#cover { background: %SURFACE%; border-radius: 10px; }
#npTitle { font-size: 14px; font-weight: 600; }
QPushButton#ctl { background: transparent; border: none; border-radius: 18px; padding: 0; }
QPushButton#ctl:hover { background: %HOVER%; }
QPushButton#playBtn { background: %TEXT%; border: none; border-radius: 22px; padding: 0; }
QPushButton#playBtn:hover { background: %ACCENT_HOVER%; }

QSlider::groove:horizontal { height: 4px; background: %BORDER%; border-radius: 2px; }
QSlider::sub-page:horizontal { background: %TEXT%; border-radius: 2px; }
QSlider::handle:horizontal { background: %TEXT%; width: 12px; height: 12px; margin: -4px 0;
                             border-radius: 6px; }
QSlider#seek::sub-page:horizontal { background: %ACCENT%; }
QSlider#seek::handle:horizontal { background: %ACCENT%; }

/* Ana sayfa: raflar ve kartlar */
QScrollArea { background: transparent; border: none; }
QScrollArea > QWidget > QWidget { background: transparent; }
QFrame#card { background: transparent; border-radius: 12px; }
QFrame#card:hover { background: %HOVER%; }
#cardTitle { font-weight: 600; }
QPushButton#shelfTitle { background: transparent; border: none; padding: 0; font-size: 18px;
                         font-weight: 700; text-align: left; color: %TEXT%; }
QPushButton#shelfTitle:hover:enabled { color: %ACCENT%; }
QPushButton#shelfTitle:disabled { color: %TEXT%; }

/* Sistem uyarı bandı (eksik program vb.) */
#banner { background: rgba(224, 164, 88, 40); border: 1px solid #E0A458; border-radius: 10px; }
#banner QLabel { background: transparent; }

/* Mini oynatıcı */
#miniCard { background: %PANEL%; border: 1px solid %BORDER%; border-radius: 16px; }

/* Menüler (sistem tepsisi ve sağ tık menüleri dahil) */
QMenu { background: %SURFACE%; border: 1px solid %BORDER%; padding: 6px; border-radius: 8px; }
QMenu::item { padding: 8px 22px; border-radius: 6px; }
QMenu::item:selected { background: %ACCENT_SOFT%; }
QMenu::item:disabled { color: %DISABLED%; }
QMenu::separator { height: 1px; background: %BORDER%; margin: 6px 8px; }
QMessageBox, QInputDialog { background: %BG%; }
"""


def build_qss(theme_key: str = DEFAULT_THEME, accent: str = DEFAULT_ACCENT,
              custom: dict | None = None) -> str:
    pal = get_palette(theme_key, accent, custom)
    qss = _TEMPLATE
    for key, value in pal.items():
        qss = qss.replace(f"%{key.upper()}%", value)
    return qss
