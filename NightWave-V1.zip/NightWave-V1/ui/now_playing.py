"""'Çalıyor' ekranı: büyük kapak, parça bilgisi ve müzik görselleştirici + özelleştirme düğmeleri."""
from PyQt6.QtCore import QSize, Qt
from PyQt6.QtGui import QPixmap
from PyQt6.QtWidgets import (QComboBox, QHBoxLayout, QLabel, QPushButton, QSlider, QVBoxLayout,
                             QWidget)

from ui.icons import icon
from ui.visualizer import BAR_CHOICES, COLOR_MODES, STYLES, VisualizerWidget


class NowPlayingView(QWidget):
    def __init__(self, player, cfg: dict, pal: dict, save_cb, fullscreen_cb, close_cb=None, parent=None):
        super().__init__(parent)
        self.cfg, self._save, self._fullscreen_cb = cfg, save_cb, fullscreen_cb
        self._close_cb = close_cb
        self.pal = pal
        self.player = player

        self.cover = QLabel()
        self.cover.setObjectName("cover")
        self.cover.setFixedSize(200, 200)
        self.cover.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.title = QLabel("Çalan parça yok")
        self.title.setObjectName("h1")
        self.title.setWordWrap(True)
        self.artist = QLabel("Bir şarkı çalmaya başlayın")
        self.artist.setObjectName("muted")
        self.kind_label = QLabel("")
        self.kind_label.setObjectName("muted")

        info = QVBoxLayout()
        info.setSpacing(6)
        info.addStretch(1)
        info.addWidget(self.title)
        info.addWidget(self.artist)
        info.addWidget(self.kind_label)
        info.addStretch(1)
        top = QHBoxLayout()
        top.setSpacing(24)
        top.addWidget(self.cover)
        top.addLayout(info, 1)

        self.back_btn = QPushButton("  Küçült")
        self.back_btn.setObjectName("rowBtn")
        self.back_btn.setIcon(icon("chevron_down", pal["text"]))
        self.back_btn.setIconSize(QSize(16, 16))
        self.back_btn.setToolTip("Kapat (Esc)")
        self.back_btn.clicked.connect(lambda: self._close_cb() if self._close_cb else None)
        header = QHBoxLayout()
        header.addWidget(self.back_btn)
        header.addStretch(1)

        self.viz = VisualizerWidget(player, pal)
        self.viz.kind_changed.connect(self._on_kind)

        self.style_box = self._combo(STYLES, cfg.get("viz_style", "bars"))
        self.color_box = self._combo(COLOR_MODES, cfg.get("viz_color", "accent"))
        self.bars_box = QComboBox()
        for n in BAR_CHOICES:
            self.bars_box.addItem(f"{n} çubuk", n)
        i = self.bars_box.findData(int(cfg.get("viz_bars", 64)))
        self.bars_box.setCurrentIndex(i if i >= 0 else 2)
        self.gain = QSlider(Qt.Orientation.Horizontal)
        self.gain.setRange(40, 250)
        self.gain.setValue(int(cfg.get("viz_gain", 100)))
        self.gain.setFixedWidth(130)
        self.gain.setToolTip("Duyarlılık")
        self.fs_btn = QPushButton("Tam ekran")
        self.fs_btn.setObjectName("rowBtn")
        self.fs_btn.setToolTip("F11 · çıkmak için Esc")

        ctrl = QHBoxLayout()
        ctrl.setSpacing(10)
        ctrl.addWidget(self.style_box)
        ctrl.addWidget(self.color_box)
        ctrl.addWidget(self.bars_box)
        gl = QLabel("Duyarlılık")
        gl.setObjectName("muted")
        ctrl.addWidget(gl)
        ctrl.addWidget(self.gain)
        ctrl.addStretch(1)
        ctrl.addWidget(self.fs_btn)

        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(14)
        lay.addLayout(header)
        lay.addLayout(top)
        lay.addWidget(self.viz, 1)
        lay.addLayout(ctrl)

        self.style_box.currentIndexChanged.connect(self._on_style)
        self.color_box.currentIndexChanged.connect(self._on_color)
        self.bars_box.currentIndexChanged.connect(self._on_bars)
        self.gain.valueChanged.connect(lambda v: self.viz.set_gain(v))
        self.gain.sliderReleased.connect(self._on_gain_released)
        self.fs_btn.clicked.connect(lambda: self._fullscreen_cb())

        # kayıtlı ayarları uygula
        self.viz.set_style(self.style_box.currentData())
        self.viz.set_color_mode(self.color_box.currentData())
        self.viz.set_bars(self.bars_box.currentData())
        self.viz.set_gain(self.gain.value())
        self._sync_cover_visibility()

    @staticmethod
    def _combo(choices, current) -> QComboBox:
        box = QComboBox()
        for key, label in choices:
            box.addItem(label, key)
        i = box.findData(current)
        box.setCurrentIndex(i if i >= 0 else 0)
        return box

    # ---- ayar değişimleri --------------------------------------------------
    def _on_style(self, *_):
        self.cfg["viz_style"] = self.style_box.currentData()
        self.viz.set_style(self.cfg["viz_style"])
        self._sync_cover_visibility()
        self._save()

    def _on_color(self, *_):
        self.cfg["viz_color"] = self.color_box.currentData()
        self.viz.set_color_mode(self.cfg["viz_color"])
        self._save()

    def _on_bars(self, *_):
        self.cfg["viz_bars"] = self.bars_box.currentData()
        self.viz.set_bars(self.cfg["viz_bars"])
        self._save()

    def _on_gain_released(self):
        self.cfg["viz_gain"] = self.gain.value()
        self._save()

    def _sync_cover_visibility(self):
        # Dairesel stilde kapak halkanın ortasında çizilir; yanındaki büyük kapağı gizle
        self.cover.setVisible(self.style_box.currentData() != "circle")

    def _on_kind(self, kind: str):
        self.kind_label.setText("🎧 Gerçek ses analizi" if kind == "real"
                                else "✨ Müziğe uyumlu simülasyon (ses verisi alınamıyor)")

    # ---- dışarıdan çağrılanlar ---------------------------------------------
    def set_track(self, track) -> None:
        self.title.setText(track.title)
        self.artist.setText(track.artist or "—")
        self.cover.clear()
        self.viz.set_cover(None)

    def set_cover(self, pix: QPixmap) -> None:
        self.viz.set_cover(pix)
        self.cover.setPixmap(pix.scaled(200, 200, Qt.AspectRatioMode.KeepAspectRatioByExpanding,
                                        Qt.TransformationMode.SmoothTransformation))

    def apply_palette(self, pal: dict) -> None:
        self.pal = pal
        self.back_btn.setIcon(icon("chevron_down", pal["text"]))
        self.viz.apply_palette(pal)

    def set_fullscreen(self, on: bool) -> None:
        self.fs_btn.setText("Tam ekrandan çık" if on else "Tam ekran")
