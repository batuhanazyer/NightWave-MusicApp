"""Windows görev çubuğu entegrasyonu.

Qt 6'da QWinTaskbarButton / QWinThumbnailToolBar kaldırıldı, bu yüzden Windows'un
ITaskbarList3 COM arayüzünü doğrudan ctypes ile çağırıyoruz (ek paket gerekmez).

  - Görev çubuğu simgesinin üstüne gelince çıkan önizlemede  ⏮  ⏯  ⏭  düğmeleri
  - Görev çubuğu simgesinin altında çalma ilerleme çubuğu (duraklatınca sarı,
    akış hazırlanırken "belirsiz" animasyon)
  - Simgenin köşesinde küçük ▶ / ⏸ durum rozeti

Hata olursa sessizce devre dışı kalır (ok=False); uygulamanın geri kalanı etkilenmez.
"""
import ctypes
import sys
import uuid
from ctypes import wintypes

from PyQt6.QtCore import QAbstractNativeEventFilter, QCoreApplication, QObject, QTimer, pyqtSignal

from core import config
from ui import styles
from ui.icons import icon

WM_COMMAND = 0x0111
THBN_CLICKED = 0x1800
THB_ICON, THB_TOOLTIP, THB_FLAGS = 0x2, 0x4, 0x8
THBF_ENABLED = 0x0
TBPF_NOPROGRESS, TBPF_INDETERMINATE, TBPF_NORMAL, TBPF_PAUSED = 0x0, 0x1, 0x2, 0x8
ID_PREV, ID_PLAY, ID_NEXT = 100, 101, 102

CLSID_TASKBAR_LIST = "{56FDF344-FD6D-11d0-958A-006097C9A090}"
IID_ITASKBAR_LIST3 = "{EA1AFB91-9E28-4B86-90E9-9E9F8A5EEFAF}"

# ITaskbarList3 vtable sırası (IUnknown 0-2, ITaskbarList 3-7, ITaskbarList2 8, ITaskbarList3 9+)
VT_RELEASE, VT_HRINIT = 2, 3
VT_PROGRESS_VALUE, VT_PROGRESS_STATE = 9, 10
VT_THUMB_ADD, VT_THUMB_UPDATE, VT_OVERLAY = 15, 16, 18


class _GUID(ctypes.Structure):
    _fields_ = [("Data1", wintypes.DWORD), ("Data2", wintypes.WORD),
                ("Data3", wintypes.WORD), ("Data4", ctypes.c_ubyte * 8)]

    def __init__(self, text: str):
        u = uuid.UUID(text)
        super().__init__(u.time_low, u.time_mid, u.time_hi_version,
                         (ctypes.c_ubyte * 8)(*u.bytes[8:]))


class _THUMBBUTTON(ctypes.Structure):
    _fields_ = [("dwMask", wintypes.DWORD), ("iId", wintypes.UINT), ("iBitmap", wintypes.UINT),
                ("hIcon", ctypes.c_void_p), ("szTip", ctypes.c_wchar * 260),
                ("dwFlags", wintypes.DWORD)]


class _TaskbarList:
    """ITaskbarList3'ün ince ctypes sarmalayıcısı."""

    def __init__(self):
        ole32 = ctypes.windll.ole32
        ole32.CoInitialize(None)                 # Qt zaten başlatmışsa zararsız (S_FALSE)
        clsid, iid = _GUID(CLSID_TASKBAR_LIST), _GUID(IID_ITASKBAR_LIST3)
        ptr = ctypes.c_void_p()
        hr = ole32.CoCreateInstance(ctypes.byref(clsid), None, 1, ctypes.byref(iid),
                                    ctypes.byref(ptr))
        if hr != 0 or not ptr:
            raise OSError(f"CoCreateInstance başarısız: 0x{hr & 0xFFFFFFFF:08X}")
        self._ptr = ptr
        self._vtbl = ctypes.cast(ptr, ctypes.POINTER(ctypes.POINTER(ctypes.c_void_p))).contents
        self._fn(VT_HRINIT)(self._ptr)

    def _fn(self, index, *argtypes):
        proto = ctypes.WINFUNCTYPE(ctypes.HRESULT, ctypes.c_void_p, *argtypes)
        return proto(self._vtbl[index])

    def progress_value(self, hwnd, done, total):
        self._fn(VT_PROGRESS_VALUE, ctypes.c_void_p, ctypes.c_ulonglong,
                 ctypes.c_ulonglong)(self._ptr, hwnd, int(done), int(total))

    def progress_state(self, hwnd, flag):
        self._fn(VT_PROGRESS_STATE, ctypes.c_void_p, ctypes.c_int)(self._ptr, hwnd, flag)

    def thumb_buttons(self, hwnd, buttons, update=False):
        arr = (_THUMBBUTTON * len(buttons))(*buttons)
        self._fn(VT_THUMB_UPDATE if update else VT_THUMB_ADD, ctypes.c_void_p, ctypes.c_uint,
                 ctypes.c_void_p)(self._ptr, hwnd, len(arr), ctypes.addressof(arr))

    def overlay(self, hwnd, hicon, description):
        self._fn(VT_OVERLAY, ctypes.c_void_p, ctypes.c_void_p,
                 ctypes.c_wchar_p)(self._ptr, hwnd, hicon, description)

    def release(self):
        self._fn(VT_RELEASE)(self._ptr)


class _Filter(QAbstractNativeEventFilter):
    def __init__(self, callback):
        super().__init__()
        self._callback = callback

    def nativeEventFilter(self, event_type, message):
        if bytes(event_type) in (b"windows_generic_MSG", b"windows_dispatcher_MSG"):
            msg = wintypes.MSG.from_address(int(message))
            if self._callback(msg):
                return True, 0
        return False, 0


class TaskbarIntegration(QObject):
    prev_clicked = pyqtSignal()
    toggle_clicked = pyqtSignal()
    next_clicked = pyqtSignal()

    def __init__(self, window, pal: dict, parent=None):
        super().__init__(parent)
        self.ok = False
        self._window = window
        self._pal = pal
        self._hwnd = 0
        self._tl = None
        self._filter = None
        self._playing = False
        self._active = False          # bir parça yüklü mü (ilerleme çubuğu gösterilsin mi)
        self._loading = False
        self._buttons_added = False
        self._last_sec = -1
        self._hicons: dict[tuple, int] = {}
        if sys.platform != "win32":
            return
        try:
            self._tl = _TaskbarList()
            self._hwnd = int(window.winId())
            self._created_msg = ctypes.windll.user32.RegisterWindowMessageW("TaskbarButtonCreated")
            self._dir = config.APP_DIR / "taskbar"
            self._dir.mkdir(parents=True, exist_ok=True)
            self._filter = _Filter(self._on_native)
            QCoreApplication.instance().installNativeEventFilter(self._filter)
            self.ok = True
            QTimer.singleShot(300, self._add_buttons)   # düğme zaten oluşmuş olabilir
        except Exception as exc:  # noqa: BLE001
            print(f"[NightWave] Görev çubuğu entegrasyonu başlatılamadı: {exc!r}")

    # ---- simgeler ---------------------------------------------------------
    def _hicon(self, name: str, color: str) -> int:
        """QIcon'u geçici .ico dosyasına yazıp HICON olarak yükler (önbellekli)."""
        key = (name, color)
        if key in self._hicons:
            return self._hicons[key]
        user32 = ctypes.windll.user32
        size = user32.GetSystemMetrics(49) or 16               # SM_CXSMICON
        path = self._dir / f"{name}_{color.lstrip('#')}.ico"
        if not path.exists():
            icon(name, color, 64).pixmap(size * 2, size * 2).save(str(path), "ICO")
        user32.LoadImageW.restype = ctypes.c_void_p
        user32.LoadImageW.argtypes = [ctypes.c_void_p, ctypes.c_wchar_p, ctypes.c_uint,
                                      ctypes.c_int, ctypes.c_int, ctypes.c_uint]
        handle = user32.LoadImageW(None, str(path), 1, size, size, 0x10) or 0   # IMAGE_ICON, LR_LOADFROMFILE
        self._hicons[key] = handle
        return handle

    def _thumb_fg(self) -> str:
        return "#202020" if styles.system_prefers_light() else "#FFFFFF"

    def _button(self, bid: int, name: str, tip: str) -> _THUMBBUTTON:
        b = _THUMBBUTTON()
        b.dwMask = THB_ICON | THB_TOOLTIP | THB_FLAGS
        b.iId = bid
        b.hIcon = self._hicon(name, self._thumb_fg())
        b.szTip = tip
        b.dwFlags = THBF_ENABLED
        return b

    def _play_button(self) -> _THUMBBUTTON:
        return self._button(ID_PLAY, "pause" if self._playing else "play",
                            "Duraklat" if self._playing else "Oynat")

    # ---- düğmeler ---------------------------------------------------------
    def _add_buttons(self):
        if not self.ok or self._buttons_added:
            return
        try:
            self._tl.thumb_buttons(self._hwnd, [self._button(ID_PREV, "prev", "Önceki"),
                                                self._play_button(),
                                                self._button(ID_NEXT, "next", "Sonraki")])
            self._buttons_added = True
        except OSError:
            return                       # taskbar düğmesi henüz yok; TaskbarButtonCreated gelince denenir
        self._apply_state()

    def _on_native(self, msg) -> bool:
        if msg.message == self._created_msg:          # görev çubuğu düğmesi (yeniden) oluşturuldu
            self._hwnd = int(self._window.winId())
            self._buttons_added = False
            QTimer.singleShot(0, self._add_buttons)
            return False
        if msg.message == WM_COMMAND and (msg.wParam >> 16) & 0xFFFF == THBN_CLICKED \
                and msg.hWnd == self._hwnd:
            bid = msg.wParam & 0xFFFF
            {ID_PREV: self.prev_clicked, ID_PLAY: self.toggle_clicked,
             ID_NEXT: self.next_clicked}.get(bid, self.toggle_clicked).emit()
            return True
        return False

    # ---- durum bildirimi (uygulamadan göreve çubuğuna) ---------------------
    def _safe(self, fn, *args):
        if not self.ok:
            return
        try:
            fn(*args)
        except OSError:
            pass

    def _apply_state(self):
        """Rozet + ilerleme çubuğu durumunu mevcut oynatma durumuna göre ayarlar."""
        if not self._active:
            self._safe(self._tl.progress_state, self._hwnd, TBPF_NOPROGRESS)
            self._safe(self._tl.overlay, self._hwnd, None, "")
            return
        if self._loading:
            flag = TBPF_INDETERMINATE
        else:
            flag = TBPF_NORMAL if self._playing else TBPF_PAUSED
        self._safe(self._tl.progress_state, self._hwnd, flag)
        badge = self._hicon("pause" if not self._playing else "play", self._pal["accent"])
        self._safe(self._tl.overlay, self._hwnd, badge, "Çalıyor" if self._playing else "Duraklatıldı")

    def set_playing(self, playing: bool):
        self._playing = playing
        if playing:
            self._active = True
        if self._buttons_added:
            self._safe(self._tl.thumb_buttons, self._hwnd, [self._play_button()], True)
        self._apply_state()

    def set_progress(self, pos_ms: int, dur_ms: int):
        if not self.ok or dur_ms <= 0 or self._loading:
            return
        sec = pos_ms // 1000
        if sec == self._last_sec:
            return                       # saniyede en fazla bir kez güncelle
        self._last_sec = sec
        self._safe(self._tl.progress_value, self._hwnd, min(pos_ms, dur_ms), dur_ms)

    def set_loading(self, loading: bool):
        if loading != self._loading:
            self._loading = loading
            if loading:
                self._active = True
            self._apply_state()

    def new_track(self):
        self._last_sec = -1
        self._safe(self._tl.progress_value, self._hwnd, 0, 1)

    def set_palette(self, pal: dict):
        self._pal = pal
        self._apply_state()

    def shutdown(self):
        if not self.ok:
            return
        try:
            self._active = False
            self._apply_state()
            QCoreApplication.instance().removeNativeEventFilter(self._filter)
            self._tl.release()
        except Exception:  # noqa: BLE001
            pass
        self.ok = False
