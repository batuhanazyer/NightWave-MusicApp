"""Dosya gerektirmeyen, kodla çizilen simgeler (uygulama simgesi + kontrol butonları)."""
from PyQt6.QtCore import QPointF, QRectF, Qt
from PyQt6.QtGui import (QBrush, QColor, QFont, QIcon, QLinearGradient, QPainter, QPainterPath,
                         QPen, QPixmap, QPolygonF)


def _pts(size, *points) -> QPolygonF:
    return QPolygonF([QPointF(x * size, y * size) for x, y in points])


def icon(name: str, color: str = "#E8E8F0", size: int = 64) -> QIcon:
    """name: play | pause | next | prev | volume | shuffle | repeat | repeat1 | mini | expand | close | heart | heart_fill | chevron_up | chevron_down"""
    pix = QPixmap(size, size)
    pix.fill(Qt.GlobalColor.transparent)
    p = QPainter(pix)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    p.setPen(Qt.PenStyle.NoPen)
    p.setBrush(QColor(color))
    s = size

    if name == "play":
        p.drawPolygon(_pts(s, (0.32, 0.18), (0.82, 0.5), (0.32, 0.82)))
    elif name == "pause":
        p.drawRoundedRect(QRectF(s * 0.24, s * 0.18, s * 0.18, s * 0.64), 3, 3)
        p.drawRoundedRect(QRectF(s * 0.58, s * 0.18, s * 0.18, s * 0.64), 3, 3)
    elif name == "next":
        p.drawPolygon(_pts(s, (0.18, 0.2), (0.66, 0.5), (0.18, 0.8)))
        p.drawRoundedRect(QRectF(s * 0.72, s * 0.2, s * 0.1, s * 0.6), 2, 2)
    elif name == "prev":
        p.drawPolygon(_pts(s, (0.82, 0.2), (0.34, 0.5), (0.82, 0.8)))
        p.drawRoundedRect(QRectF(s * 0.18, s * 0.2, s * 0.1, s * 0.6), 2, 2)
    elif name == "volume":
        p.drawPolygon(_pts(s, (0.12, 0.38), (0.28, 0.38), (0.48, 0.2),
                           (0.48, 0.8), (0.28, 0.62), (0.12, 0.62)))
        pen = QPen(QColor(color), s * 0.07)
        pen.setCapStyle(Qt.PenCapStyle.RoundCap)
        p.setPen(pen)
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawArc(QRectF(s * 0.5, s * 0.3, s * 0.3, s * 0.4), -60 * 16, 120 * 16)

    elif name in ("heart", "heart_fill"):
        path = QPainterPath()
        path.moveTo(s * 0.5, s * 0.84)
        path.cubicTo(s * 0.10, s * 0.58, s * 0.10, s * 0.20, s * 0.30, s * 0.20)
        path.cubicTo(s * 0.42, s * 0.20, s * 0.50, s * 0.30, s * 0.50, s * 0.36)
        path.cubicTo(s * 0.50, s * 0.30, s * 0.58, s * 0.20, s * 0.70, s * 0.20)
        path.cubicTo(s * 0.90, s * 0.20, s * 0.90, s * 0.58, s * 0.50, s * 0.84)
        path.closeSubpath()
        if name == "heart_fill":
            p.drawPath(path)
        else:
            pen = QPen(QColor(color), s * 0.07)
            pen.setJoinStyle(Qt.PenJoinStyle.RoundJoin)
            p.setPen(pen)
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.drawPath(path)
    elif name in ("shuffle", "repeat", "repeat1", "mini", "expand", "close", "chevron_up", "chevron_down"):
        pen = QPen(QColor(color), s * 0.075)
        pen.setCapStyle(Qt.PenCapStyle.RoundCap)
        pen.setJoinStyle(Qt.PenJoinStyle.RoundJoin)
        p.setPen(pen)
        p.setBrush(Qt.BrushStyle.NoBrush)

        def line(*pts):
            p.drawPolyline(_pts(s, *pts))

        def head(x, y, direction):   # dolu ok başı
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(QColor(color))
            p.drawPolygon(_pts(s, (x, y - 0.13), (x + 0.15 * direction, y), (x, y + 0.13)))
            p.setPen(pen)
            p.setBrush(Qt.BrushStyle.NoBrush)

        if name == "shuffle":
            line((0.14, 0.30), (0.34, 0.30), (0.60, 0.70), (0.72, 0.70))
            line((0.14, 0.70), (0.34, 0.70), (0.60, 0.30), (0.72, 0.30))
            head(0.72, 0.70, 1)
            head(0.72, 0.30, 1)
        elif name in ("repeat", "repeat1"):
            line((0.20, 0.56), (0.20, 0.40), (0.28, 0.32), (0.66, 0.32))
            head(0.66, 0.32, 1)
            line((0.80, 0.44), (0.80, 0.60), (0.72, 0.68), (0.34, 0.68))
            head(0.34, 0.68, -1)
            if name == "repeat1":
                f = QFont("Segoe UI")
                f.setBold(True)
                f.setPixelSize(int(s * 0.34))
                p.setFont(f)
                p.setPen(QColor(color))
                p.drawText(QRectF(0, 0, s, s), Qt.AlignmentFlag.AlignCenter, "1")
        elif name == "mini":      # iç içe iki pencere
            p.drawRoundedRect(QRectF(s * 0.14, s * 0.2, s * 0.72, s * 0.6), 5, 5)
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(QColor(color))
            p.drawRoundedRect(QRectF(s * 0.5, s * 0.5, s * 0.28, s * 0.22), 3, 3)
        elif name == "expand":    # çapraz ok: pencereyi büyüt
            line((0.58, 0.20), (0.80, 0.20), (0.80, 0.42))
            line((0.80, 0.20), (0.50, 0.50))
            line((0.42, 0.80), (0.20, 0.80), (0.20, 0.58))
            line((0.20, 0.80), (0.50, 0.50))
        elif name == "close":
            line((0.26, 0.26), (0.74, 0.74))
            line((0.74, 0.26), (0.26, 0.74))
        elif name == "chevron_up":
            line((0.22, 0.62), (0.5, 0.34), (0.78, 0.62))
        elif name == "chevron_down":
            line((0.22, 0.38), (0.5, 0.66), (0.78, 0.38))

    p.end()
    return QIcon(pix)


def make_app_icon() -> QIcon:
    """Mor degradeli yuvarlak kare + ekolayzer çubukları."""
    size = 256
    pix = QPixmap(size, size)
    pix.fill(Qt.GlobalColor.transparent)
    p = QPainter(pix)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)

    grad = QLinearGradient(0, 0, size, size)
    grad.setColorAt(0, QColor("#8B7CFF"))
    grad.setColorAt(1, QColor("#5B3FD9"))
    p.setPen(Qt.PenStyle.NoPen)
    p.setBrush(QBrush(grad))
    p.drawRoundedRect(QRectF(8, 8, size - 16, size - 16), 56, 56)

    p.setBrush(QColor("white"))
    heights = [80, 150, 110, 130]
    bar_w, gap = 28, 16
    x0 = (size - (len(heights) * bar_w + (len(heights) - 1) * gap)) / 2
    for i, h in enumerate(heights):
        p.drawRoundedRect(QRectF(x0 + i * (bar_w + gap), (size - h) / 2, bar_w, h), 14, 14)

    p.end()
    return QIcon(pix)
