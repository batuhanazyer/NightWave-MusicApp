"""NightWave tanı aracı: müzik çalmıyor / indirmiyorsa nedenini adım adım bulur.

Çalıştırma:  python diagnose.py
Çıktının tamamını bana yapıştırabilirsiniz.
"""
import platform
import sys

sys.path.insert(0, ".")

from core import errors, health  # noqa: E402

OK, BAD, WARN = "[ OK ]", "[HATA]", "[UYARI]"


def qt_probe(source: str, seconds: float = 10.0):
    """Qt'nin ses motoruyla GERÇEKTEN çalmayı dener (sessiz). Döner: (başarılı mı | None, ayrıntı)."""
    import time
    try:
        from PyQt6.QtCore import QEventLoop, QTimer, QUrl
        from PyQt6.QtGui import QGuiApplication
        from PyQt6.QtMultimedia import QAudioOutput, QMediaPlayer
    except Exception as exc:  # noqa: BLE001
        return None, f"PyQt6 yüklenemedi: {exc}"
    QGuiApplication.instance() or QGuiApplication(sys.argv)
    player, audio = QMediaPlayer(), QAudioOutput()
    audio.setVolume(0.0)                                  # sessiz: sadece çözülüp çözülmediğine bakıyoruz
    player.setAudioOutput(audio)
    state = {"err": "", "pos": 0, "status": ""}
    player.errorOccurred.connect(lambda e, m: state.update(err=m or str(e)))
    player.mediaStatusChanged.connect(lambda st: state.update(status=st.name))
    player.positionChanged.connect(lambda p: state.update(pos=max(state["pos"], int(p))))
    player.setSource(QUrl(source) if source.startswith("http") else QUrl.fromLocalFile(source))
    player.play()
    loop, poll, deadline = QEventLoop(), QTimer(), time.time() + seconds

    def check():
        if state["err"] or state["pos"] >= 800 or time.time() > deadline:
            loop.quit()

    poll.timeout.connect(check)
    poll.start(100)
    loop.exec()
    poll.stop()
    player.stop()
    if state["pos"] >= 800:
        return True, f"{state['pos']} ms çalındı"
    if state["err"]:
        return False, state["err"]
    return False, f"{seconds:.0f} sn içinde çalmaya başlamadı (durum: {state['status'] or 'bilinmiyor'})"


def main():
    print(f"Python {platform.python_version()} · {platform.system()} {platform.release()}\n")

    print("1) Gerekli programlar")
    checks = health.run_checks()
    for c in checks:
        tag = OK if c.ok else (BAD if c.severity == "error" else WARN if c.severity == "warn" else "[BİLGİ]")
        print(f"  {tag} {c.title}: {c.detail}")
    todo = [f"{c.title}:  {c.fix}" for c in health.problems(checks) if c.fix]

    print("\n2) YouTube araması")
    results = []
    try:
        from core import youtube
        results = youtube.search("daft punk one more time", limit=3)
        print(f"  {OK} Arama çalışıyor ({len(results)} sonuç): {results[0].title if results else '-'}")
    except Exception as exc:  # noqa: BLE001
        print(f"  {BAD} Arama başarısız: {errors.friendly_error(exc)}")

    if results:
        print("\n3) HIZLI BAŞLAT: indirirken çal (uygulamanın varsayılan yöntemi)")
        try:
            import tempfile
            import threading
            import time
            from pathlib import Path

            from core.cache import AudioCache
            pcache = AudioCache(Path(tempfile.mkdtemp()), 50)
            st = {"url": None, "t": None, "err": None}
            t0 = time.time()

            def on_ready(url):
                st["url"], st["t"] = url, time.time() - t0

            def run():
                try:
                    st["path"] = youtube.fetch_progressive(results[0], pcache, on_ready)
                except Exception as exc:  # noqa: BLE001
                    st["err"] = exc

            th = threading.Thread(target=run, daemon=True)
            th.start()
            while th.is_alive() and st["url"] is None and time.time() - t0 < 120:
                time.sleep(0.2)
            if st["url"]:
                print(f"  {OK} İlk {youtube.PROGRESSIVE_START_BYTES // 1000} KB {st['t']:.1f} sn'de geldi: çalma bu kadar sürede başlar")
                ok, detail = qt_probe(st["url"])
                if ok is None:
                    print(f"  {WARN} Qt testi yapılamadı: {detail}")
                elif ok:
                    print(f"  {OK} Qt indirilirken çalabiliyor: {detail}")
                else:
                    print(f"  {WARN} Qt indirirken-çalmayı çalamadı: {detail}")
                    print("       Sorun değil: uygulama otomatik olarak tamamı inince çalmaya (ve gerekirse MP3'e) geçer.")
            th.join(timeout=180)
            if st.get("err"):
                print(f"  {BAD} {errors.friendly_error(st['err'])}")
            elif st.get("path"):
                print(f"       Tamamı {time.time() - t0:.1f} sn'de indi ({st['path'].stat().st_size / 1048576:.1f} MB). "
                      "Çalma bunu beklemeden başlar.")
        except Exception as exc:  # noqa: BLE001
            print(f"  {BAD} {errors.friendly_error(exc)}")

        print("\n3b) Önbelleğe indirip çalma (uygulamanın varsayılan çalma yöntemi)")
        try:
            import tempfile
            import time
            from pathlib import Path

            from core.cache import AudioCache
            cache = AudioCache(Path(tempfile.mkdtemp()), 50)
            t0 = time.time()
            path = youtube.fetch_audio(results[0], cache, progress=None)
            print(f"  {OK} İndirildi: {path.name}  ({path.stat().st_size / 1048576:.1f} MB, {time.time() - t0:.1f} sn)")
            print(f"       Uygulamada bir şarkıya tıkladığınızda bu kadar beklersiniz; sıradaki şarkı arka planda hazırlanır.")
            ok, detail = qt_probe(str(path))
            if ok is None:
                print(f"  {WARN} Qt çalma testi yapılamadı: {detail}")
            elif ok:
                print(f"  {OK} Qt bu dosyayı ({path.suffix}) ÇALABİLİYOR: {detail}")
            else:
                print(f"  {BAD} Qt bu dosyayı ({path.suffix}) ÇALAMIYOR: {detail}")
                todo.append("Qt ses motoru dosyayı çözemiyor: pip install -U PyQt6  (ve FFmpeg kurulu olsun)")
        except Exception as exc:  # noqa: BLE001
            print(f"  {BAD} {errors.friendly_error(exc)}")
            print(f"       (ham hata: {errors.clean(exc)[:300]})")

        print("\n4) Doğrudan akış adresi (yalnızca Ayarlar > Müzik'te 'Doğrudan akış' seçiliyse kullanılır)")
        try:
            url = youtube.resolve_stream(results[0])
            print(f"  {OK} Akış adresi alındı: {url[:70]}…")
            ok, detail = qt_probe(url)
            if ok is None:
                print(f"  {WARN} Qt akış testi yapılamadı: {detail}")
            elif ok:
                print(f"  {OK} Qt akışı da çalabiliyor: {detail}  (Ayarlar > Müzik'ten 'Doğrudan akış' seçebilirsiniz)")
            else:
                print(f"  {WARN} Qt doğrudan akışı ÇALAMIYOR: {detail}")
                print("       Bu beklenen bir durum: uygulama bu yüzden önbellek yöntemini kullanıyor. Sorun değil.")
        except Exception as exc:  # noqa: BLE001
            print(f"  {BAD} {errors.friendly_error(exc)}")

    print("\n" + "=" * 64)
    if todo:
        print("YAPILMASI GEREKENLER (PowerShell'e yapıştırın):")
        for i, t in enumerate(todo, 1):
            print(f"  {i}. {t}")
        print("\nKurulumdan sonra PowerShell'i KAPATIP yeniden açın, sonra bu aracı tekrar çalıştırın.")
    else:
        print("Gerekli programlar tamam. Sorun sürüyorsa yukarıdaki çıktıyı gönderin.")


if __name__ == "__main__":
    main()
